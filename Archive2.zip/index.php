<?php
header("location:https://demo.txcode.site/alb/public/");
?>