<?php

namespace Database\Seeders;

use App\Models\PesananPembelian;
use Illuminate\Database\Seeder;

class PesananPembelianSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // PesananPembelian::create([

        // ]);
    }
}
