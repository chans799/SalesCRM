<?php

use App\Http\Controllers\Akun\ProfileController;
use App\Http\Controllers\{DashboardController,TestController};
use App\Http\Controllers\HistoryController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LocalizationController;
use App\Http\Controllers\MasterData\{
    AreaController,
    BankController,
    BarangController,
    GudangController,
    KategoriController,
    MatauangController,
    PelangganController,
    RateMataUangController,
    RekeningBankController,
    SalesmanController,
    SupplierController,
    SatuanBarangController
};

use App\Http\Controllers\Inventory\{
    AdjustmentMinusController,
    AdjustmentPlusController,
    PerakitanPaketController
};

use App\Http\Controllers\Pembelian\{
    PembelianController,
    ReturPembelianController,
    PesananPembelianController
};

use App\Http\Controllers\Penjualan\{
    DirectPenjualanController,
    PenjualanController,
    PesananPenjualanController,
    ReturPenjualanController
};

use App\Http\Controllers\Setting\{
    TokoController,
    UserController
};

use App\Http\Controllers\Keuangan\{
    BiayaController,
    CekGiroCairController,
    CekGiroTolakController,
    PelunasanHutangController,
    PelunasanPiutangController
};

use App\Http\Controllers\Laporan\{
    AdjustmentMinusReportController,
    AdjustmentPlusReportController,
    BiayaReportController,
    CekGiroReportController,
    GrossProfitReportController,
    KomisiReportController,
    NettProfitReportController,
    PelunasanHutangReportController,
    PelunasanPiutangReportController,
    PembelianReportController,
    PenjualanReportController,
    PesananPembelianReportController,
    PesananPenjualanReportController,
    ReturPembelianReportController,
    ReturPenjualanReportController,
    SaldoHutangReportController,
    SaldoPiutangReportController,
    StokBarangReportController,
    StockReportController,
    PembelianPerBarangController,
    PembelianSortController,
    PenjualanPerBarangController,
    PenjualanSortController,
    PenjualanBySalesController,
    PenjualanByWilayahController,
    PenjualanByPembayaranController,
    PiutangJatuhTempoController,
    HutangJatuhTempoController,
    TandaTerimaTagihanController,
    StockOpnameController
};

use Illuminate\Support\Facades\Auth;

Route::get('/', [DashboardController::class, 'index']);
Route::get('/history', [HistoryController::class, 'index'] )->name('history');

//route switch bahasa
Route::get('/localization/{language}', [LocalizationController::class, 'switch'])->name('localization.switch');

// untuk false atw nonaktifkan route register
Auth::routes(['register' => false]);

Route::group(['prefix' => 'dashboard', 'middleware' => ['web', 'auth']], function () {
    //Route Dashboard
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard.index');
});

// group master data
Route::group(['prefix' => 'masterdata', 'middleware' => ['web', 'auth']], function () {
    Route::resource('/matauang', MatauangController::class)->except('show');
    Route::resource('/rate-matauang', RateMataUangController::class)->except('show');
    Route::resource('/bank', BankController::class)->except('show');
    Route::resource('/rekening-bank', RekeningBankController::class)->except('show');
    Route::resource('/supplier', SupplierController::class)->except('show');
    Route::resource('/area', AreaController::class)->except('show');
    Route::resource('/satuan-barang', SatuanBarangController::class)->except('show');
    Route::resource('/pelanggan', PelangganController::class)->except('show');
    Route::resource('/salesman', SalesmanController::class)->except('show');
    Route::resource('/gudang', GudangController::class)->except('show');
    Route::resource('/kategori', KategoriController::class)->except('show');
    Route::resource('/barang', BarangController::class)->except('show');

    Route::get('/barang/cek-stok/{id}', [BarangController::class, 'cekStok']);
});

// Inventory
Route::group(['prefix' => 'inventory', 'middleware' => ['web', 'auth']], function () {
    // Adjustment Plus
    Route::post('/adjustment-plus/store', [AdjustmentPlusController::class, 'store'])->name('adjustment-plus.store');
    Route::put('/adjustment-plus/update/{id}', [AdjustmentPlusController::class, 'update'])->name('adjustment-plus.update');
    Route::get('/adjustment-plus/generate-kode/{tanggal}', [AdjustmentPlusController::class, 'generateKode'])->name('adjustment-plus.generateKode');
    Route::resource('/adjustment-plus', AdjustmentPlusController::class)->except('store', 'update');
    Route::get('/adjustment-plus/print/detail/{id}', [AdjustmentPlusController::class, 'print'])->name('adjustment-plus.print.detail');

    // Adjustment Minus
    Route::post('/adjustment-minus/store', [AdjustmentMinusController::class, 'store'])->name('adjustment-minus.store');
    Route::put('/adjustment-minus/update/{id}', [AdjustmentMinusController::class, 'update'])->name('adjustment-minus.update');
    Route::get('/adjustment-minus/generate-kode/{tanggal}', [AdjustmentMinusController::class, 'generateKode'])->name('adjustment-minus.generateKode');
    Route::resource('/adjustment-minus', AdjustmentMinusController::class)->except('store', 'update');
    Route::get('/adjustment-minus/print/detail/{id}', [AdjustmentMinusController::class, 'print'])->name('adjustment-minus.print.detail');

    // Perakitan Paket
    Route::post('/perakitan-paket/store', [PerakitanPaketController::class, 'store'])->name('perakitan-paket.store');
    Route::put('/perakitan-paket/update/{id}', [PerakitanPaketController::class, 'update'])->name('perakitan-paket.update');
    Route::get('/perakitan-paket/generate-kode/{tanggal}', [PerakitanPaketController::class, 'generateKode'])->name('perakitan-paket.generateKode');
    Route::resource('/perakitan-paket', PerakitanPaketController::class)->except('store', 'update');
    Route::get('/perakitan-paket/print/detail/{id}', [PerakitanPaketController::class, 'print'])->name('perakitan-paket.print.detail');
});

// Pembelian
Route::group(['prefix' => 'beli', 'middleware' => ['web', 'auth']], function () {
    // Pesanan Pembelian
    Route::post('/pesanan-pembelian/store', [PesananPembelianController::class, 'store'])->name('pesanan-pembelian.store');
    Route::put('/pesanan-pembelian/update/{PesananPembelian}', [PesananPembelianController::class, 'update'])->name('pesanan-pembelian.update');
    Route::get('/pesanan-pembelian/generate-kode/{tanggal}', [PesananPembelianController::class, 'generateKode'])->name('pesanan-pembelian.generateKode');
    Route::resource('/pesanan-pembelian', PesananPembelianController::class)->except('store', 'update');
    Route::get('/pesanan-pembelian/print/detail/{id}', [PesananPembelianController::class, 'print'])->name('pesanan-pembelian.print.detail');

    // Pembelian
    Route::post('/pembelian/store', [PembelianController::class, 'store'])->name('pembelian.store');
    Route::put('/pembelian/update/{PesananPembelian}', [PembelianController::class, 'update'])->name('pembelian.update');
    Route::get('/pembelian/generate-kode/{tanggal}', [PembelianController::class, 'generateKode'])->name('pembelian.generateKode');
    Route::get('/pembelian/get-rekening/{id}', [PembelianController::class, 'getRekeningByBankId'])->name('pembelian.getRekeningByBankId');
    Route::get('/pembelian/get-data-po/{id}', [PembelianController::class, 'getDataPO'])->name('pembelian.getDataPO');
    Route::resource('/pembelian', PembelianController::class)->except('store', 'update');
    Route::get('/pembelian/print/detail/{id}', [PembelianController::class, 'print'])->name('pembelian.print.detail');

    // Retur
    Route::post('/retur-pembelian/store', [ReturPembelianController::class, 'store'])->name('retur-pembelian.store');
    Route::put('/retur-pembelian/update/{pembelian_id}', [ReturPembelianController::class, 'update'])->name('retur-pembelian.update');
    Route::get('/retur-pembelian/generate-kode/{tanggal}', [ReturPembelianController::class, 'generateKode'])->name('retur-pembelian.generateKode');
    Route::get('/retur-pembelian/get-pembelian/{id}', [ReturPembelianController::class, 'getPembelianById'])->name('retur-pembelian.getPembelianById');
    Route::resource('/retur-pembelian', ReturPembelianController::class)->except('store', 'update');
    Route::get('/retur-pembelian/print/detail/{id}', [ReturPembelianController::class, 'print'])->name('retur-pembelian.print.detail');
});

// Setting
Route::group(['prefix' => 'setting', 'middleware' => ['web', 'auth']], function () {
    // Route::get('/toko', [TokoController::class, 'index'])->name('toko.index')->middleware('permission:toko');
    // Route::put('/toko/{toko:id}', [TokoController::class, 'update'])->name('toko.update')->middleware('permission:toko');

    Route::resource('/toko', TokoController::class)->except('show');
    Route::resource('/user', UserController::class)->except('show');
});

// Profile
Route::group(['prefix' => 'akun', 'middleware' => ['web', 'auth']], function () {
    Route::get('/profile', [ProfileController::class, 'index'])->name('profile.index');

    Route::post('/profile', [ProfileController::class, 'store'])->name('profile.store');
});

// Penjualan
Route::group(['prefix' => 'jual', 'middleware' => ['web', 'auth']], function () {
    // Penjualan
    Route::post('/penjualan/store', [PenjualanController::class, 'store'])->name('penjualan.store');
    Route::put('/penjualan/update/{penjualan:id}', [PenjualanController::class, 'update'])->name('penjualan.update');
    Route::put('/penjualan/update-status', [PenjualanController::class, 'ubah_status'])->name('penjualan.ubah_status');
    Route::get('/penjualan/generate-kode/{tanggal}', [PenjualanController::class, 'generateKode'])->name('penjualan.generateKode');
    Route::get('/penjualan/get-rekening/{id}', [PenjualanController::class, 'getRekeningByBankId'])->name('penjualan.getRekeningByBankId');
    Route::get('/penjualan/cek-barang-pesanan/{id}', [PenjualanController::class, 'cekBarangPesananPenjualan'])->name('penjualan.cekBarangPesananPenjualan');
    Route::get('/penjualan/get-barang-partial/{id}', [PenjualanController::class, 'getBarangPartial'])->name('penjualan.getBarangPartial');
    Route::get('/penjualan/get-alamat/{tanggal}', [PenjualanController::class, 'getAlamatPelanggan'])->name('penjualan.getAlamatPelanggan');
    Route::resource('/penjualan', PenjualanController::class)->except('store', 'update');
    Route::get('/penjualan/pdf/detail/{id}', [PenjualanController::class, 'pdfDetail'])->name('penjualan.pdf.detail');
    Route::get('/penjualan/pdf/last', [PenjualanController::class, 'previewPdf'])->name('penjualan.pdf.last');
    Route::get('/penjualan/pdf/kurir/{id}', [PenjualanController::class, 'pdfKurir'])->name('penjualan.pdf.kurir');
    Route::get('/penjualan/print/detail/{id}', [PenjualanController::class, 'print'])->name('penjualan.print.detail');
    Route::get('/penjualan/print/kurir/{id}', [PenjualanController::class, 'surat_jalan'])->name('penjualan.print.kurir');
    Route::get('/penjualan/print/last', [PenjualanController::class, 'previewPrint'])->name('penjualan.print.last');
    Route::post('/penjualan/cek-password', [PenjualanController::class, 'cekpass'])->name('penjualan.cekpass');
    // Retur Penjualan
    Route::post('/retur-penjualan/store', [ReturPenjualanController::class, 'store'])->name('retur-penjualan.store');
    Route::put('/retur-penjualan/update/{returPenjualan:id}', [ReturPenjualanController::class, 'update'])->name('retur-penjualan.update');
    Route::get('/retur-penjualan/generate-kode/{tanggal}', [ReturPenjualanController::class, 'generateKode']);
    Route::get('/retur-penjualan/get-penjualan/{penjualan:id}', [ReturPenjualanController::class, 'getPenjualanById']);
    Route::get('/retur-penjualan/print/detail/{id}', [ReturPenjualanController::class, 'print'])->name('retur-penjualan.print.detail');
    Route::resource('/retur-penjualan', ReturPenjualanController::class)->except('store', 'update');

    // Pesanan Penjualan
    Route::get('/penjualan/get-data-so/{id}', [PenjualanController::class, 'getDataSO'])->name('penjualan.getDataSO');
    Route::post('/pesanan-penjualan/store', [PesananPenjualanController::class, 'store'])->name('pesanan-penjualan.store');
    Route::put('/pesanan-penjualan/update/{id}', [PesananPenjualanController::class, 'update'])->name('pesanan-penjualan.update');
    Route::get('/pesanan-penjualan/generate-kode/{tanggal}', [PesananPenjualanController::class, 'generateKode'])->name('pesanan-penjualan.generateKode');
    Route::get('/pesanan-penjualan/get-rekening/{id}', [PesananPenjualanController::class, 'getRekeningByBankId'])->name('pesanan-penjualan.getRekeningByBankId');
    Route::get('/pesanan-penjualan/get-alamat/{tanggal}', [PesananPenjualanController::class, 'getAlamatPelanggan'])->name('pesanan-penjualan.getAlamatPelanggan');
    Route::get('/pesanan-penjualan/cek-pesanan/{id}', [PesananPenjualanController::class, 'cekPesananPelanggan'])->name('pesanan-penjualan.cekPesananPelanggan');
    Route::get('/pesanan-penjualan/cek-pesanan-no-lunas/{id}', [PesananPenjualanController::class, 'cekPesananBelumLunas'])->name('pesanan-penjualan.cekPesananBelumLunas');
    Route::get('/pesanan-penjualan/cek-pembayaran-pesanan/{id}', [PesananPenjualanController::class, 'cekPembayaranPesanan'])->name('pesanan-penjualan.cekPembayaranPesanan');
    Route::resource('/pesanan-penjualan', PesananPenjualanController::class)->except('store', 'update');
    Route::get('/pesanan-penjualan/pdf/detail/{id}', [PesananPenjualanController::class, 'pdfDetail'])->name('pesanan-penjualan.pdf.detail');
    Route::get('/pesanan-penjualan/print/detail/{id}', [PesananPenjualanController::class, 'print'])->name('pesanan-penjualan.print.detail');

    // Direct Sales
    Route::get('/direct-penjualan/get-barang-by-matauang', [DirectPenjualanController::class, 'getBarangByMatauang']);
    Route::resource('/direct-penjualan', DirectPenjualanController::class)->only('create', 'store');
});

// Keuangan
Route::group(['prefix' => 'keuangan', 'middleware' => ['web', 'auth']], function () {
    // Pelunasan Hutang
    Route::post('/pelunasan-hutang/store', [PelunasanHutangController::class, 'store'])->name('pelunasan-hutang.store');
    Route::get('/pelunasan-hutang/get-pembelian-belum-lunas/{id}', [PelunasanHutangController::class, 'getPembelianYgBelumLunas']);
    Route::get('/pelunasan-hutang/generate-kode/{tanggal}', [PelunasanHutangController::class, 'generateKode']);
    Route::resource('/pelunasan-hutang', PelunasanHutangController::class);
    Route::post('/pelunasan-hutang', [PelunasanHutangController::class, 'index'])->name('pelunasan-hutang.action');    
    Route::get('/pelunasan-hutang/print/detail/{id}', [PelunasanHutangController::class, 'print'])->name('pelunasan-hutang.print');

    // Pelunasan Piutang
    Route::post('/pelunasan-piutang/store', [PelunasanPiutangController::class, 'store'])->name('pelunasan-piutang.store');
    Route::get('/pelunasan-piutang/get-penjualan-belum-lunas/{id}', [PelunasanPiutangController::class, 'getPenjualanYgBelumLunas']);
    Route::get('/pelunasan-piutang/generate-kode/{tanggal}', [PelunasanPiutangController::class, 'generateKode']);
    Route::resource('/pelunasan-piutang', PelunasanPiutangController::class);
    Route::post('/pelunasan-piutang', [PelunasanPiutangController::class, 'index'])->name('pelunasan-piutang.action');  
    Route::get('/pelunasan-piutang/print/detail/{id}', [PelunasanPiutangController::class, 'print'])->name('pelunasan-piutang.print');

    // Giro Cair
    Route::get('/cek-giro-cair/generate-kode/{tanggal}', [CekGiroCairController::class, 'generateKode']);
    Route::get('/cek-giro-cair/get-cek-giro-by-id/{id}', [CekGiroCairController::class, 'getCekGiroById']);
    Route::resource('/cek-giro-cair', CekGiroCairController::class);  
    Route::get('/cek-giro-cair/print/detail/{id}', [CekGiroCairController::class, 'print'])->name('cek-giro-cair.print');

    // Giro Tolak
    Route::get('/cek-giro-tolak/generate-kode/{tanggal}', [CekGiroTolakController::class, 'generateKode']);
    Route::get('/cek-giro-tolak/get-cek-giro-by-id/{id}', [CekGiroTolakController::class, 'getCekGiroById']);
    Route::resource('/cek-giro-tolak', CekGiroTolakController::class);  
    Route::get('/cek-giro-tolak/print/detail/{id}', [CekGiroTolakController::class, 'print'])->name('cek-giro-tolak.print');

    // Biaya
    Route::get('/biaya/generate-kode/{tanggal}', [BiayaController::class, 'generateKode']);
    Route::resource('/biaya', BiayaController::class);  
    Route::get('/biaya/print/detail/{id}', [BiayaController::class, 'print'])->name('biaya.print');
});

// Laporan
Route::group(['prefix' => 'laporan', 'middleware' => ['web', 'auth']], function () {
    Route::group(['prefix' => 'persediaan'], function () {
        // Stok Barang
        Route::get('/stok-barang/pdf', [StokBarangReportController::class, 'pdf'])->name('stok-barang.pdf');
        Route::get('/stok-barang', [StokBarangReportController::class, 'index'])->name('stok-barang.laporan');
        Route::post('/stok-barang', [StokBarangReportController::class, 'index'])->name('stok-barang.laporan');
        Route::get('/stock-barang/cetak', [StokBarangReportController::class, 'cetak'])->name('stok-barang.cetak');

        // Kartu Stok
        Route::get('/stock', [StockReportController::class, 'index'])->name('stock.laporan');
        Route::get('/stock/pdf', [StockReportController::class, 'pdf'])->name('stock.pdf');
        Route::get('/stock/cetak', [StockReportController::class, 'cetak'])->name('stock.cetak');
        Route::get('/stock/delete', [StockReportController::class, 'delete'])->name('stock.delete');
        
        // Adjustment Plus
        Route::get('/adjusment-plus/pdf', [AdjustmentPlusReportController::class, 'pdf'])->name('adjustment-plus.pdf');
        Route::get('/adjusment-plus/singlepdf/{id}', [AdjustmentPlusReportController::class, 'singlepdf'])->name('adjustment-plus-single.pdf');
        Route::get('/adjusment-plus', [AdjustmentPlusReportController::class, 'index'])->name('adjustment-plus.laporan');
        Route::get('/adjusment-plus/cetak', [AdjustmentPlusReportController::class, 'cetak'])->name('adjustment-plus.cetak');

        // Adjustment Minus
        Route::get('/adjusment-minus/pdf', [AdjustmentMinusReportController::class, 'pdf'])->name('adjustment-minus.pdf');
        Route::get('/adjusment-minus/singlepdf/{id}', [AdjustmentMinusReportController::class, 'singlepdf'])->name('adjustment-minus-single.pdf');
        Route::get('/adjusment-minus', [AdjustmentMinusReportController::class, 'index'])->name('adjustment-minus.laporan');
        Route::get('/adjusment-minus/cetak', [AdjustmentMinusReportController::class, 'cetak'])->name('adjustment-minus.cetak');

        // Penjualan Sort By Qty & Value
        Route::get('/stock-opname',  [StockOpnameController::class, 'index'])->name('stok-opname.laporan');
        Route::post('/stock-opname',  [StockOpnameController::class, 'index'])->name('stok-opname.laporan');
        Route::get('/stock-opname/cetak',  [StockOpnameController::class, 'cetak'])->name('stok-opname.cetak');
        Route::post('/stock-opname', [StockOpnameController::class, 'index'])->name('stok-opname.laporan');

    });

    Route::group(['prefix' => 'pembelian'], function () {
        // Pembelian
        Route::get('/pembelian/pdf', [PembelianReportController::class, 'pdf'])->name('pembelian.pdf');
        Route::get('/pembelian/cetak', [PembelianReportController::class, 'cetak'])->name('pembelian.cetak');
        Route::get('/pembelian', [PembelianReportController::class, 'index'])->name('pembelian.laporan');

        // Pembelian Perbarang
        Route::get('/pembelian-per-barang',  [PembelianPerBarangController::class, 'index'])->name('pembelian-per-barang.laporan');
        Route::get('/pembelian-per-barang/cetak', [PembelianPerBarangController::class, 'cetak'])->name('pembelian-per-barang.cetak');
        Route::post('/pembelian-per-barang', [PembelianPerBarangController::class, 'index'])->name('pembelian-per-barang.laporan');

        // Pembelian Sort By Qty & Value
        Route::get('/pembelian-sort',  [PembelianSortController::class, 'index'])->name('pembelian-sort.laporan');
        Route::get('/pembelian-sort/cetak',  [PembelianSortController::class, 'cetak'])->name('pembelian-sort.cetak');
        Route::post('/pembelian-sort', [PembelianSortController::class, 'index'])->name('pembelian-sort.laporan');

        // Pesanan Pembelian
        Route::get('/pesanan-pembelian/pdf', [PesananPembelianReportController::class, 'pdf'])->name('pesanan-pembelian.pdf');
        Route::get('/pesanan-pembelian/cetak', [PesananPembelianReportController::class, 'cetak'])->name('pesanan-pembelian.cetak');
        Route::get('/pesanan-pembelian', [PesananPembelianReportController::class, 'index'])->name('pesanan-pembelian.laporan');

        // Pembelian Retur
        Route::get('/retur-pembelian/pdf', [ReturPembelianReportController::class, 'pdf'])->name('retur-pembelian.pdf');
        Route::get('/retur-pembelian/cetak', [ReturPembelianReportController::class, 'cetak'])->name('retur-pembelian.cetak');
        Route::get('/retur-pembelian', [ReturPembelianReportController::class, 'index'])->name('retur-pembelian.laporan');
    });

    Route::group(['prefix' => 'penjualan'], function () {
        // Penjualan
        Route::get('/penjualan/pdf', [PenjualanReportController::class, 'pdf'])->name('penjualan.pdf');
        Route::get('/penjualan/cetak', [PenjualanReportController::class, 'cetak'])->name('penjualan.cetak');
        Route::get('/penjualan', [PenjualanReportController::class, 'index'])->name('penjualan.laporan');

        // Penjualan Perbarang
        Route::get('/penjualan-per-barang',  [PenjualanPerBarangController::class, 'index'])->name('penjualan-per-barang.laporan');
        Route::get('/penjualan-per-barang/cetak',  [PenjualanPerBarangController::class, 'cetak'])->name('penjualan-per-barang.cetak');
        Route::post('/penjualan-per-barang', [PenjualanPerBarangController::class, 'index'])->name('penjualan-per-barang.laporan');

        // Penjualan Sort By Qty & Value
        Route::get('/penjualan-by-sales',  [PenjualanBySalesController::class, 'index'])->name('penjualan-by-sales.laporan');
        Route::get('/penjualan-by-sales/cetak',  [PenjualanBySalesController::class, 'cetak'])->name('penjualan-by-sales.cetak');
        Route::post('/penjualan-by-sales', [PenjualanBySalesController::class, 'index'])->name('penjualan-by-sales.laporan');

        // Penjualan Sort By Qty & Value
        Route::get('/penjualan-by-wilayah',  [PenjualanByWilayahController::class, 'index'])->name('penjualan-by-wilayah.laporan');
        Route::get('/penjualan-by-wilayah/cetak',  [PenjualanByWilayahController::class, 'cetak'])->name('penjualan-by-wilayah.cetak');
        Route::post('/penjualan-by-wilayah', [PenjualanByWilayahController::class, 'index'])->name('penjualan-by-wilayah.laporan');

        // Penjualan Sort By Qty & Value
        Route::get('/penjualan-by-pembayaran',  [PenjualanByPembayaranController::class, 'index'])->name('penjualan-by-pembayaran.laporan');
        Route::get('/penjualan-by-pembayaran/cetak',  [PenjualanByPembayaranController::class, 'cetak'])->name('penjualan-by-pembayaran.cetak');
        Route::post('/penjualan-by-pembayaran', [PenjualanByPembayaranController::class, 'index'])->name('penjualan-by-pembayaran.laporan');

        // Penjualan Sort By Qty & Value
        Route::get('/penjualan-sort',  [PenjualanSortController::class, 'index'])->name('penjualan-sort.laporan');
        Route::get('/penjualan-sort/cetak',  [PenjualanSortController::class, 'cetak'])->name('penjualan-sort.cetak');
        Route::post('/penjualan-sort', [PenjualanSortController::class, 'index'])->name('penjualan-sort.laporan');

        // Penjualan
        Route::get('/pesanan-penjualan/pdf', [PesananPenjualanReportController::class, 'pdf'])->name('pesanan-penjualan.pdf');
        Route::get('/pesanan-penjualan/cetak', [PesananPenjualanReportController::class, 'cetak'])->name('pesanan-penjualan.cetak');
        Route::get('/pesanan-penjualan', [PesananPenjualanReportController::class, 'index'])->name('pesanan-penjualan.laporan');

        // Penjualan Retur
        Route::get('/retur-penjualan/pdf', [ReturPenjualanReportController::class, 'pdf'])->name('retur-penjualan.pdf');
        Route::get('/retur-penjualan/cetak', [ReturPenjualanReportController::class, 'cetak'])->name('retur-penjualan.cetak');
        Route::get('/retur-penjualan', [ReturPenjualanReportController::class, 'index'])->name('retur-penjualan.laporan');

        // Tanda Terima Tagihan
        Route::get('/tanda-terima-tagihan',  [TandaTerimaTagihanController::class, 'index'])->name('tanda-terima-tagihan.laporan');
        Route::get('/tanda-terima-tagihan/cetak',  [TandaTerimaTagihanController::class, 'cetak'])->name('tanda-terima-tagihan.cetak');
        Route::get('/tanda-terima-tagihan/print',  [TandaTerimaTagihanController::class, 'print'])->name('tanda-terima-tagihan.print');
        Route::post('/tanda-terima-tagihan', [TandaTerimaTagihanController::class, 'index'])->name('tanda-terima-tagihan.laporan');     
    });

    Route::group(['prefix' => 'keuangan'], function () {
        // Saldo Hutang
        Route::get('/saldo-hutang/cetak', [SaldoHutangReportController::class, 'cetak'])->name('saldo-hutang.cetak');
        Route::get('/saldo-hutang/pdf', [SaldoHutangReportController::class, 'pdf'])->name('saldo-hutang.pdf');
        Route::get('/saldo-hutang', [SaldoHutangReportController::class, 'index'])->name('saldo-hutang.laporan');

        // Pelunasan Hutang
        Route::get('/pelunasan-hutang/cetak', [PelunasanHutangReportController::class, 'cetak'])->name('pelunasan-hutang.cetak');
        Route::get('/pelunasan-hutang/pdf', [PelunasanHutangReportController::class, 'pdf'])->name('pelunasan-hutang.pdf');
        Route::get('/pelunasan-hutang', [PelunasanHutangReportController::class, 'index'])->name('pelunasan-hutang.laporan');

        // Saldo Piutang
        Route::get('/saldo-piutang/cetak', [SaldoPiutangReportController::class, 'cetak'])->name('saldo-piutang.cetak');
        Route::get('/saldo-piutang/pdf', [SaldoPiutangReportController::class, 'pdf'])->name('saldo-piutang.pdf');
        Route::get('/saldo-piutang', [SaldoPiutangReportController::class, 'index'])->name('saldo-piutang.laporan');

        // Pelunasan Piutang
        Route::get('/pelunasan-piutang/cetak', [PelunasanPiutangReportController::class, 'cetak'])->name('pelunasan-piutang.cetak');
        Route::get('/pelunasan-piutang/pdf', [PelunasanPiutangReportController::class, 'pdf'])->name('pelunasan-piutang.pdf');
        Route::get('/pelunasan-piutang', [PelunasanPiutangReportController::class, 'index'])->name('pelunasan-piutang.laporan');

        // Piutang Jatuh Tempo
        Route::get('/piutang-jatuh-tempo/cetak',  [PiutangJatuhTempoController::class, 'cetak'])->name('piutang-jatuh-tempo.cetak');
        Route::get('/piutang-jatuh-tempo',  [PiutangJatuhTempoController::class, 'index'])->name('piutang-jatuh-tempo.laporan');
        Route::post('/piutang-jatuh-tempo', [PiutangJatuhTempoController::class, 'index'])->name('piutang-jatuh-tempo.laporan');

        // Hutang Jatuh Tempo
        Route::get('/hutang-jatuh-tempo/cetak',  [HutangJatuhTempoController::class, 'cetak'])->name('hutang-jatuh-tempo.cetak');
        Route::get('/hutang-jatuh-tempo',  [HutangJatuhTempoController::class, 'index'])->name('hutang-jatuh-tempo.laporan');
        Route::post('/hutang-jatuh-tempo', [HutangJatuhTempoController::class, 'index'])->name('hutang-jatuh-tempo.laporan');

        // Biaya
        Route::get('/biaya/cetak', [BiayaReportController::class, 'cetak'])->name('biaya.cetak');
        Route::get('/biaya/pdf', [BiayaReportController::class, 'pdf'])->name('biaya.pdf');
        Route::get('/biaya', [BiayaReportController::class, 'index'])->name('biaya.laporan');

        // Cek/Giro
        Route::get('/cek-giro/cetak', [CekGiroReportController::class, 'cetak'])->name('cek-giro.cetak');
        Route::get('/cek-giro/pdf', [CekGiroReportController::class, 'pdf'])->name('cek-giro.pdf');
        Route::get('/cek-giro', [CekGiroReportController::class, 'index'])->name('cek-giro.laporan');    
    });

    Route::group(['prefix' => 'internal'], function () {
        // Komisi Salesman
        Route::get('/komisi-salesman/cetak', [KomisiReportController::class, 'cetak'])->name('komisi-salesman.cetak');
        Route::get('/komisi-salesman/pdf', [KomisiReportController::class, 'pdf'])->name('komisi-salesman.pdf');
        Route::get('/komisi-salesman', [KomisiReportController::class, 'index'])->name('komisi-salesman.laporan');
        Route::post('/komisi-salesman', [KomisiReportController::class, 'index'])->name('komisi-salesman.laporan');


        // Gross Profit
        Route::get('/gross-profit/cetak', [GrossProfitReportController::class, 'cetak'])->name('gross-profit.cetak');
        Route::get('/gross-profit/pdf', [GrossProfitReportController::class, 'pdf'])->name('gross-profit.pdf');
        Route::get('/gross-profit', [GrossProfitReportController::class, 'index'])->name('gross-profit.laporan');

        // nett Profit
        Route::get('/nett-profit/cetak', [NettProfitReportController::class, 'cetak'])->name('nett-profit.cetak');
        Route::get('/nett-profit/pdf', [NettProfitReportController::class, 'pdf'])->name('nett-profit.pdf');
        Route::get('/nett-profit', [NettProfitReportController::class, 'index'])->name('nett-profit.laporan');
    });


});

Route::get('/test', [TestController::class, 'test']);
