@extends('layouts.cetak2')
@section('title', 'Laporan Gross Profit')

@section('content')
  <main>
    <h3>{{ $toko->nama }}</h3>
    <center><strong style="text-transform: uppercase;">Laporan Gross Profit</strong></center><br/>
    <table style="margin-bottom: 0;">
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Tanggal</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ date('d-M-Y', strtotime($param['dari_tanggal'])) }} - {{ date('d-M-Y', strtotime($param['sampai_tanggal'])) }}</td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Gudang</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['gudang'] ? $param['gudang']->nama : 'Semua Gudang' }}</td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Barang</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['barang'] ? $param['barang']->nama : 'Semua Barang' }}</td>
      </tr>
    </table>
    <br/>
    <table class="main" cellspacing="0" cellpadding="0" border="1">
        <thead>
            <tr>
              <th>Tanggal</th>
              <th>Transaksi</th>
              <th>Nomor</th>
              <th>Sales</th>
              <th>Jenis Barang</th>
              <th>Kode Barang</th>
              <th>Nama Barang</th>
              <th>Qty</th>
              <th>Harga Jual</th>
              <th>Harga Beli</th>
              <th>Total Harga Jual</th>
              <th>Total Harga Beli</th>
              <th>Gross Profit</th>
              <th>Persentase</th>
            </tr>
        </thead>
        <tbody>
            @php
                $total_gross_profit = 0; 
            @endphp
            @forelse ($reportData as $item)
                @php
                    $sales = '';
                    if($item->trcd == 'SALES'){
                        $sl = DB::table('penjualan')                                                    
                                ->select(DB::raw('salesman.nama as nama_salesman'), 'penjualan.*')
                                ->leftJoin('salesman', 'salesman.id', '=', 'penjualan.salesman_id')
                                ->where('penjualan.id', $item->trans_id)
                                ->first();

                        $sales = $sl ? $sl->nama_salesman : '';
                    }

                    $jumlah = $item->debet-$item->kredit ;
                    $qty    = $item->debet > $item->kredit ? $item->debet-$item->kredit : $item->kredit-$item->debet;

                    $jual_harga = 0;
                    $jual_total = 0;

                    if($item->trans_type=='sales'){
                        $sale = DB::table('penjualan_detail')->where('id', $item->reff_id)->first();

                        $jual_harga  = $sale->harga;
                        $jual_total  = $jual_harga*$qty;
                    }

                    $gross_profit = 0;

                    if($item->trans_type=='sales'){
                        $gross_profit = $jual_total-$item->total_harga;
                        $total_gross_profit += $gross_profit;
                    }

                    if($item->trans_type=='sales_return'){
                        $jumlah = $item->kredit-$item->debet ;
                        
                        $kartu = DB::table('kartu_stok')->where('id', $item->source_price)->first();
                        $sale  = DB::table('penjualan_detail')->where('id', $kartu->reff_id)->first();

                        $jual_harga  = $sale->harga;
                        $jual_total  = $jual_harga*$qty;

                        $gross_profit = $qty*$jual_harga;
                        $total_gross_profit += $jumlah*$jual_harga;

                        
                        $sl = DB::table('penjualan')                                                    
                                ->select(DB::raw('salesman.nama as nama_salesman'), 'penjualan.*')
                                ->leftJoin('salesman', 'salesman.id', '=', 'penjualan.salesman_id')
                                ->where('penjualan.id', $kartu->trans_id)
                                ->first();
                        $sales = $sl ? $sl->nama_salesman : '';
                    }



                @endphp
                <tr>
                    <td style="text-align: center;">{{ date('d/m/Y', strtotime($item->tanggal)) }}</td>
                    <td style="text-align: center;">{{ $item->trcd }}</td>
                    <td style="text-align: center;">{{ $item->nomor }}</td>
                    <td style="text-align: left;">{{ $sales }}</td>
                    <td style="text-align: center;">Item</td>
                    <td style="text-align: left;">{{ $item->kode_barang }}</td>
                    <td style="text-align: left;">{{ $item->nama_barang }}</td>
                    @if( $item->trans_type!='sales_return' )
                        <td style="text-align: center;">{{ number_format($qty,0) }}</td>
                        <td style="text-align: right;">{{ $jual_harga >0 ? number_format($jual_harga) : '' }}</td>
                        <td style="text-align: right;">{{ number_format($item->harga) }}</td>
                        <td style="text-align: right;">{{ $jual_total >0 ? number_format($jual_total) : '' }}</td>
                        <td style="text-align: right;">{{ number_format($item->total_harga) }}</td>
                        <td style="text-align: right;">{{ $gross_profit >0 ? number_format($gross_profit) : '' }}</td>
                        <td style="text-align: center;">{{ number_format( (($jual_harga-$item->harga)/$item->harga)*100, 2) }}%</td>
                    @else
                        <td style="text-align: center;">{{ number_format($jumlah,0) }}</td>
                        <td style="text-align: right;">{{ $jual_harga >0 ? number_format($jual_harga) : '' }}</td>
                        <td style="text-align: right;">{{ number_format($item->harga) }}</td>
                        <td style="text-align: right;">{{ $jual_total >0 ? '('.number_format($jual_total).')' : '' }}</td>
                        <td style="text-align: right;">({{ number_format($item->total_harga) }})</td>
                        <td style="text-align: right;">{{ $gross_profit >0 ? '('.number_format($gross_profit).')' : '' }}</td>
                        <td style="text-align: center; color: red">-{{ number_format( (($jual_harga-$item->harga)/$item->harga)*100 , 2) }}%</td>
                    @endif
                </tr>
            @empty
                <tr>
                    <td colspan="14" class="text-center">Data tidak ditemukan</td>
                </tr>
            @endforelse
        </tbody>
        <tfoot>
            <tr>
                <th style="text-align: right;" colspan="12">TOTAL GROSS PROFIT :</th>
                <th style="text-align: right;">{{ number_format($total_gross_profit, 2) }}</th>
                <th></th>
            </tr>
        </tfoot>
    </table>

    <div id="printPageButton" style="text-align: center;">
      <button onClick="window.print();" style="margin-top: 100px;">Print</button>
    </div>
  </main>
            
@endsection

@section('headers')
  <style type="text/css">
    @media print {
      #printPageButton {
        display: none;
      }
    }
    body{
      width: 85% !important;
    }

    th{
      font-weight: bolder !important;
    }

    td{
      text-align: left;
    }

    table th, 
    table td {
        padding: 5px;
    }

    .button-7 {
      background-color: #0095ff;
      border: 1px solid transparent;
      border-radius: 3px;
      box-shadow: rgba(255, 255, 255, .4) 0 1px 0 0 inset;
      box-sizing: border-box;
      color: #fff;
      cursor: pointer;
      display: inline-block;
      font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
      font-size: 13px;
      font-weight: 400;
      line-height: 1.15385;
      margin: 0;
      outline: none;
      padding: 8px .8em;
      position: relative;
      text-align: center;
      text-decoration: none;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
      vertical-align: baseline;
      white-space: nowrap;
    }

    .button-7:hover,
    .button-7:focus {
      background-color: #07c;
    }

    .button-7:focus {
      box-shadow: 0 0 0 4px rgba(0, 149, 255, .15);
    }

    .button-7:active {
      background-color: #0064bd;
      box-shadow: none;
    }

  </style>
@endsection