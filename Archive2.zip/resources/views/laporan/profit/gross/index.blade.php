@extends('layouts.dashboard')

@section('title', trans('dashboard.laporan.gross_profit'))

@section('content')
    <!-- begin #content -->
    <div id="content" class="content">
        {{ Breadcrumbs::render('laporan_gross_profit') }}
        <!-- begin row -->
        <div class="row">
            <!-- begin col-12 -->
            <div class="col-md-12">
                <!-- begin panel -->
                <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                    <div class="panel-heading">
                        <div class="panel-heading-btn">
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default"
                                data-click="panel-expand">
                                <i class="fa fa-expand"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success"
                                data-click="panel-reload"><i class="fa fa-repeat"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning"
                                data-click="panel-collapse">
                                <i class="fa fa-minus"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger"
                                data-click="panel-remove">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                        <h4 class="panel-title">Laporan Gross Profit</h4>
                    </div>
                    <div class="panel-body">
                        <form action="{{ route('gross-profit.laporan') }}" method="GET" style="margin-bottom: 1em;">
                            <div class="form-group row" style="margin-bottom: 1em;">
                                <div class="col-md-3">
                                    <label for="dari_tanggal" class="control-label">Dari Tanggal</label>
                                    <input type="date" name="dari_tanggal" class="form-control" id="dari_tanggal"
                                        value="{{ request()->query('dari_tanggal') ? request()->query('dari_tanggal') : date('Y-m-d') }}"
                                        required />
                                </div>

                                <div class="col-md-3">
                                    <label for="sampai_tanggal" class="control-label">Sampai Tanggal</label>
                                    <input type="date" name="sampai_tanggal" class="form-control" id="sampai_tanggal"
                                        value="{{ request()->query('sampai_tanggal') ? request()->query('sampai_tanggal') : date('Y-m-d') }}"
                                        required />
                                </div>

                                <div class="col-md-3">
                                    <label for="gudang" class="control-label">Gudang</label>
                                    <select name="gudang" class="form-control select2" id="gudang">
                                        <option value="" selected>All</option>
                                        @forelse ($gudang as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('gudang') && request()->query('gudang') == $item->id ? 'selected' : '' }}>
                                                {{ $item->nama }}
                                            </option>
                                        @empty
                                            <option value="" selected disabled>Data tidak ditemukan</option>
                                        @endforelse
                                    </select>
                                </div>

                                <div class="col-md-3">
                                    <label for="barang" class="control-label">Barang</label>
                                    <select name="barang" class="form-control select2" id="barang">
                                        <option value="" selected>All</option>
                                        @forelse ($barang as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('barang') && request()->query('barang') == $item->id ? 'selected' : '' }}>
                                                {{ $item->kode . ' - ' . $item->nama }}
                                            </option>
                                        @empty
                                            <option value="" selected disabled>Data tidak ditemukan</option>
                                        @endforelse
                                    </select>
                                </div> 
                            </div>

                            {{-- 
                                <div class="form-group row" style="margin-bottom: 1em;">
                                    <div class="col-md-4">
                                        <label for="pelanggan" class="control-label">Pelanggan</label>
                                        <select name="pelanggan" class="form-control" id="pelanggan">
                                            <option value="" selected>All</option>
                                            @forelse ($pelanggan as $item)
                                                <option value="{{ $item->id }}"
                                                    {{ request()->query('pelanggan') && request()->query('pelanggan') == $item->id ? 'selected' : '' }}>
                                                    {{ $item->nama_pelanggan }}
                                                </option>
                                            @empty
                                                <option value="" selected disabled>Data tidak ditemukan</option>
                                            @endforelse
                                        </select>
                                    </div>

                                    <div class="col-md-4">
                                        <label for="salesman" class="control-label">Salesman</label>
                                        <select name="salesman" class="form-control" id="salesman">
                                            <option value="" selected>All</option>
                                            @forelse ($salesman as $item)
                                                <option value="{{ $item->id }}"
                                                    {{ request()->query('salesman') && request()->query('salesman') == $item->id ? 'selected' : '' }}>
                                                    {{ $item->nama }}
                                                </option>
                                            @empty
                                                <option value="" selected disabled>Data tidak ditemukan</option>
                                            @endforelse
                                        </select>
                                    </div>
                                </div>
                            --}}

                            <button type="submit" class="btn btn-sm btn-primary">
                                <i class="fa fa-eye"></i> Cek
                            </button>
                            <a href="{{ route('gross-profit.laporan') }}"
                                class="btn btn-sm btn-default{{ request()->query() ? '' : ' disabled' }}">
                                <i class="fa fa-trash"></i> Reset
                            </a>
                            @if (count($laporan) > 0)
                                <a href="{{ route('gross-profit.cetak', request()->query()) }}" target="_blank"
                                    class="btn btn-sm btn-success">
                                    <i class="fa fa-print"></i> Cetak
                                </a>
                            @endif
                        </form>

                        <table class="table table-striped table-condensed data-table" style="margin-top: 1em;">
                            <thead>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Transaksi</th>
                                    <th>Nomor</th>
                                    <th>Sales</th>
                                    <th>Jenis Barang</th>
                                    <th>Kode Barang</th>
                                    <th>Nama Barang</th>
                                    <th>Qty</th>
                                    <th>Harga Jual</th>
                                    <th>Harga Beli</th>
                                    <th>Total Harga Jual</th>
                                    <th>Total Harga Beli</th>
                                    <th>Gross Profit</th>
                                    <th>Persentase</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $total_gross_profit = 0; 
                                @endphp
                                @forelse ($laporan as $item)
                                    @php
                                        $sales = '';
                                        if($item->trcd == 'SALES'){
                                            $sl = DB::table('penjualan')                                                    
                                                    ->select(DB::raw('salesman.nama as nama_salesman'), 'penjualan.*')
                                                    ->leftJoin('salesman', 'salesman.id', '=', 'penjualan.salesman_id')
                                                    ->where('penjualan.id', $item->trans_id)
                                                    ->first();

                                            $sales = $sl ? $sl->nama_salesman : '';
                                        }

                                        $jumlah = $item->debet-$item->kredit ;
                                        $qty    = $item->debet > $item->kredit ? $item->debet-$item->kredit : $item->kredit-$item->debet;

                                        $jual_harga = 0;
                                        $jual_total = 0;

                                        if($item->trans_type=='sales'){
                                            $sale = DB::table('penjualan_detail')->where('id', $item->reff_id)->first();

                                            $jual_harga  = $sale->harga;
                                            $jual_total  = $jual_harga*$qty;
                                        }

                                        $gross_profit = 0;

                                        if($item->trans_type=='sales'){
                                            $gross_profit = $jual_total-$item->total_harga;
                                            $total_gross_profit += $gross_profit;
                                        }

                                        if($item->trans_type=='sales_return'){
                                            $jumlah = $item->kredit-$item->debet ;
                                            
                                            $kartu = DB::table('kartu_stok')->where('id', $item->source_price)->first();
                                            $sale  = DB::table('penjualan_detail')->where('id', $kartu->reff_id)->first();

                                            $jual_harga  = $sale->harga;
                                            $jual_total  = $jual_harga*$qty;

                                            $gross_profit = $qty*$jual_harga;
                                            $total_gross_profit += $jumlah*$jual_harga;

                        
                                            $sl = DB::table('penjualan')                                                    
                                                    ->select(DB::raw('salesman.nama as nama_salesman'), 'penjualan.*')
                                                    ->leftJoin('salesman', 'salesman.id', '=', 'penjualan.salesman_id')
                                                    ->where('penjualan.id', $kartu->trans_id)
                                                    ->first();
                                            $sales = $sl ? $sl->nama_salesman : '';
                                        }



                                    @endphp
                                    <tr>
                                        <td style="text-align: center;">{{ date('d/m/Y', strtotime($item->tanggal)) }}</td>
                                        <td>{{ $item->trcd }}</td>
                                        <td>{{ $item->nomor }}</td>
                                        <td>{{ $sales }}</td>
                                        <td style="text-align: center;">Item</td>
                                        <td>{{ $item->kode_barang }}</td>
                                        <td>{{ $item->nama_barang }}</td>
                                        @if( $item->trans_type!='sales_return' )
                                            <td style="text-align: center;">{{ number_format($qty,0) }}</td>
                                            <td align="right">{{ $jual_harga >0 ? number_format($jual_harga) : '' }}</td>
                                            <td align="right">{{ number_format($item->harga) }}</td>
                                            <td align="right">{{ $jual_total >0 ? number_format($jual_total) : '' }}</td>
                                            <td align="right">{{ number_format($item->total_harga) }}</td>
                                            <td align="right">{{ $gross_profit >0 ? number_format($gross_profit) : '' }}</td>
                                            <td align="center">{{ number_format( (($jual_harga-$item->harga)/$item->harga)*100, 2) }}%</td>
                                        @else
                                            <td style="text-align: center;">{{ number_format($jumlah,0) }}</td>
                                            <td align="right">{{ $jual_harga >0 ? number_format($jual_harga) : '' }}</td>
                                            <td align="right">{{ number_format($item->harga) }}</td>
                                            <td align="right">{{ $jual_total >0 ? '('.number_format($jual_total).')' : '' }}</td>
                                            <td align="right">({{ number_format($item->total_harga) }})</td>
                                            <td align="right">{{ $gross_profit >0 ? '('.number_format($gross_profit).')' : '' }}</td>
                                            <td align="center" style="color: red;">-{{ number_format( (($jual_harga-$item->harga)/$item->harga)*100, 2) }}%</td>
                                        @endif
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="14" class="text-center">Data tidak ditemukan</td>
                                    </tr>
                                @endforelse
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th style="text-align: right;" colspan="12">TOTAL GROSS PROFIT :</th>
                                    <th style="text-align: right;">{{ number_format($total_gross_profit, 2) }}</th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <!-- end panel -->
            </div>
            <!-- end col-12 -->
        </div>
        <!-- end row -->
    </div>
    <!-- end #content -->
@endsection
