@extends('layouts.dashboard')

@section('title', 'Laporan Saldo Piutang Jatuh Tempo')

@section('content')
    <!-- begin #content -->
    <div id="content" class="content">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">Laporan</li>
                <li class="breadcrumb-item active">Saldo Piutang Jatuh Tempo</li>
            </ol>
        </nav>
        <!-- begin row -->
        <div class="row">
            <!-- begin col-12 -->
            <div class="col-md-12">
                <!-- begin panel -->
                <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                    <div class="panel-heading">
                        <div class="panel-heading-btn">
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default"
                                data-click="panel-expand">
                                <i class="fa fa-expand"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success"
                                data-click="panel-reload"><i class="fa fa-repeat"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning"
                                data-click="panel-collapse">
                                <i class="fa fa-minus"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger"
                                data-click="panel-remove">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                        <h4 class="panel-title">Laporan Saldo Piutang Jatuh Tempo</h4>
                    </div>
                    <div class="panel-body">
                        <table border="0" class="opt-data" style="margin-bottom: 40px; width: 450px;">
                            <tbody>
                              <tr>
                                <td style="min-width: 60px;"><b>Dari Tanggal</b></td>
                                <td style="padding: 5px 0;">
                                    <input type="date" class="form-control" id="dari_tanggal" value="{{ date('Y-m-01') }}" >
                                </td>
                              </tr>
                              <tr>
                                <td style="min-width: 60px;"><b>Sampai Tanggal</b></td>
                                <td style="padding: 5px 0;">
                                    <input type="date" class="form-control" id="sampai_tanggal" value="{{ date('Y-m-d') }}" >
                                </td>
                              </tr>  
                              <tr>
                                <td style="min-width: 60px;"><b>Pelanggan</b></td>
                                <td style="padding: 5px 0;">
                                    <select name="pelanggan" class="form-control select2" id="pelanggan" style="width: 100%">
                                        <option value="" selected>All</option>
                                        @forelse ($pelanggan as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('gudang') && request()->query('pelanggan') == $item->id ? 'selected' : '' }}>
                                                {{ $item->nama_pelanggan }}
                                            </option>
                                        @empty
                                            <option value="" selected disabled>Data tidak ditemukan</option>
                                        @endforelse
                                    </select>
                                </td>
                              </tr> 
                              <tr>
                                <td colspan="2" style="text-align: right; padding: 10px 0;">
                                   <button type="button" id="print-data" class="btn btn-success btn-flat btn-sm">
                                    <i class="fa fa-print"></i> Cetak</button>
                                  <button type="button" id="show-info-data" class="btn btn-danger btn-flat btn-sm">View Report</button>
                                </td>
                              </tr>
                            </tbody>
                        </table>

                        <div class="table-responsive">
                            <table class="table table-striped table-condensed data-table" id="master-table" style="margin-top: 1em; width: 100%;">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Jatuh Tempo</th>
                                        <th>Nomor</th>
                                        <th>Pelanggan</th>
                                        <th>Keterangan</th>
                                        <th>Rate</th>
                                        <th>Debet</th>
                                        <th>Kredit</th>
                                        <th>Saldo</th>
                                    </tr>
                                </thead>
                                <tbody> </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- end panel -->
            </div>
            <!-- end col-12 -->
        </div>
        <!-- end row -->
    </div>
    <!-- end #content -->
@endsection


@push('custom-css')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css" />
    <style type="text/css">
        .dataTables_length{
            display: block;
            width: 100%;
        }
        .alert-small td{
            background-color: salmon !important;
            color: #000 !important;
        }

        .alert-medium td{
            background-color: #e92929 !important;
            color: #000 !important;
            font-weight: 500;
        }

        .alert-high td{
            background-color: #9d0c0c !important;
            color: #e3e3e3 !important;
            font-weight: bolder;
        }

    </style>
@endpush

@push('custom-js')
    
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>

    <script type="text/javascript">
      let dataTable, tbData = {};
      $(function () {
        tbData.action    = 'view_report';
        tbData.dari_tanggal     = '{{ date("Y-m-01") }}';
        tbData.sampai_tanggal   = '{{ date("Y-m-d") }}';
        tbData.pelanggan = 'all';
        tbData._token    = "{{ csrf_token() }}";

        dataTable = $("#master-table").DataTable({
            "aLengthMenu": [
                [25, 50, 75, 100, -1],
                [25, 50, 75, 100, 'All']
            ],
            "iDisplayLength": 25,
            "fixedHeader": {
                header: true
            },
            dom: 'lBfrtip',
            buttons: [ 'excel', 'pdf', 'print' ],
            "language": {
                "lengthMenu": "_MENU_ data",
            },
            "processing": true,
            "serverSide": true,
            "ajax": {
              url: `{{ route('piutang-jatuh-tempo.laporan') }}`,
              type: "POST",
              dataType: "json",
              data:function ( d ) {
                return  $.extend(d, tbData);
              },
            },  
            "columns": [
                { "data": "tanggal", }, 
                { "data": "due_date", }, 
                { "data": "kode" },
                { "data": "pelanggan_id" },
                { "data": "keterangan" },
                { "data": "rate" },
                { "data": "debet" },
                { "data": "kredit" },
                { "data": "saldo" },
            ],
            "order": [
                [0, "asc"]
            ],
            createdRow: function( row, data, dataIndex ) {
                let lama = data.lama ? parseInt(data.lama) : 0;

                if(lama >= 30 && lama <=59 )      $( row ).addClass('alert-small');
                else if(lama >= 60 && lama <=89 ) $( row ).addClass('alert-medium');
                else if(lama >= 90 ) $( row ).addClass('alert-high');
                
            }
        });

        $("#show-info-data").click(function(){
          tbData.dari_tanggal     = $("#dari_tanggal").val();
          tbData.sampai_tanggal   = $("#sampai_tanggal").val();
          tbData.pelanggan = $("#pelanggan").val();

          $("#show-info-data").html("Loading...");
          dataTable.ajax.reload(function(e){
            $("#show-info-data").html("View Report");
          }, false);            
        });

        $("#print-data").click(function(e){
            e.preventDefault();

            let dari_tanggal   = $("#dari_tanggal").val();
            let sampai_tanggal = $("#sampai_tanggal").val();
            let pelanggan   = $("#pelanggan").val();
            let url = `{{ route('piutang-jatuh-tempo.cetak') }}?dari_tanggal=${dari_tanggal}&sampai_tanggal=${sampai_tanggal}&pelanggan=${pelanggan}`;

            window.open(url, '_blank').focus();
        })
        
      });
    </script>
@endpush