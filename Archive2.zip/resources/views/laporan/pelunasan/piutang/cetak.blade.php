@extends('layouts.cetak2')
@section('title', 'Laporan Pelunasan Piutang')

@section('content')
  <main>
    <h3>{{ $toko->nama }}</h3>
    <center><strong style="text-transform: uppercase;">Laporan Pelunasan Piutang</strong></center><br/>
    <table style="margin-bottom: 0;">
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Tanggal</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ date('d-M-Y', strtotime($param['dari_tanggal'])) }} - {{ date('d-M-Y', strtotime($param['sampai_tanggal'])) }} </td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Jenis Pembayaran</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['jenis_pembayaran'] && $param['jenis_pembayaran']!='all' ? $param['jenis_pembayaran'] : 'Semua Jenis Pembayaran' }}</td>
      </tr>
    </table>
    <br/>
    
    <table  class="main" cellspacing="0" cellpadding="0" border="1">
        <thead>
            <tr>
                <th>No.</th>
                <th>Kode</th>
                <th>Kode Penjualan</th>
                {{-- <th>Tanggal</th> --}}
                <th>Pelanggan</th>
                <th>Jenis Pembayaran</th>
                <th>Nilai</th>
                <th>Rate</th>
                <th>Subtotal</th>
            </tr>
        </thead>

        <tbody>
            @php
                $total_nilai = 0;
                $grand_total = 0;
                $no = 1;
            @endphp
            @forelse ($reportData as $jual)
                @foreach ($jual->pelunasan_piutang_detail as $detail)
                    @php
                        $is_show = 1;
                        if ($jual->jenis_pembayaran == 'Giro'){
                            $giro = DB::table('cek_giro')
                                ->select('cek_giro.*', DB::raw('cek_giro_tolak.kode as kode_tolak'))
                                ->leftJoin('cek_giro_tolak', 'cek_giro.id', '=', 'cek_giro_tolak.cek_giro_id')
                                ->where('payment_id', $jual->id)
                                ->where('jenis_cek', 'In')
                                ->first();
                            if($giro->kode_tolak && $giro->kode_tolak!='') $is_show = 0;
                        }
                    @endphp

                    @if( $is_show == 1 )
                        <tr>
                            <td>{{ $no++ }}</td>
                            <td>{{ $jual->kode }}</td>
                            <td>{{ $detail->penjualan->kode }}</td>
                            {{-- <td>{{ $detail->tanggal->format('d F Y') }}</td> --}}
                            <td>{{ $detail->penjualan->pelanggan ? $detail->penjualan->pelanggan->nama_pelanggan : 'Tanpa pelanggan' }}
                            </td>
                            <td>
                                {{ $jual->jenis_pembayaran }}
                                @if ($jual->jenis_pembayaran == 'Transfer')
                                    <br>
                                    Bank: {{ $jual->bank->nama }}
                                    <br>
                                    Rekening:
                                    {{ $jual->rekening_bank->nomor_rekening . ' - ' . $jual->rekening_bank->nama_rekening }}
                                @endif

                                @if ($jual->jenis_pembayaran == 'Giro')
                                    <br>
                                    No Cek/Giro: {{ $jual->no_cek_giro }}
                                    <br>
                                    Tgl Cek/Giro:
                                    {{ date('d F Y', strtotime($jual->tgl_cek_giro)) }}
                                @endif
                            </td>
                            <td>{{ $detail->penjualan->matauang->kode . ' ' . number_format($jual->bayar) }}
                            </td>
                            <td>{{ $jual->rate }}</td>
                            <td>{{ $detail->penjualan->matauang->kode . ' ' . number_format($jual->bayar * $jual->rate) }}
                            </td>
                        </tr>
                        @php
                            $total_nilai += $jual->bayar;
                            $grand_total += $jual->bayar * $jual->rate;
                        @endphp
                    @endif
                @endforeach

            @empty
                <tr>
                    <td colspan="8" class="text-center">Data tidak ditemukan</td>
                </tr>
            @endforelse
        </tbody>
        {{-- @if ($laporan)
            <tfoot>
                <tr>
                    <th colspan="5">Total</th>
                    <th colspan="2">{{ number_format($total_nilai) }}</th>
                    <th>{{ number_format($grand_total) }}</th>
                </tr>
            </tfoot>
        @endif --}}
    </table>
    <div id="printPageButton" style="text-align: center;">
      <button onClick="window.print();" style="margin-top: 100px;">Print</button>
    </div>
  </main>
            
@endsection

@section('headers')
  <style type="text/css">
    @media print {
      #printPageButton {
        display: none;
      }
    }
    body{
      width: 85% !important;
    }

    table td {
      text-align: left;
    }

    table th{
      font-weight: bolder;
    }

    table th, 
    table td {
        padding: 5px;
    }

    .button-7 {
      background-color: #0095ff;
      border: 1px solid transparent;
      border-radius: 3px;
      box-shadow: rgba(255, 255, 255, .4) 0 1px 0 0 inset;
      box-sizing: border-box;
      color: #fff;
      cursor: pointer;
      display: inline-block;
      font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
      font-size: 13px;
      font-weight: 400;
      line-height: 1.15385;
      margin: 0;
      outline: none;
      padding: 8px .8em;
      position: relative;
      text-align: center;
      text-decoration: none;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
      vertical-align: baseline;
      white-space: nowrap;
    }

    .button-7:hover,
    .button-7:focus {
      background-color: #07c;
    }

    .button-7:focus {
      box-shadow: 0 0 0 4px rgba(0, 149, 255, .15);
    }

    .button-7:active {
      background-color: #0064bd;
      box-shadow: none;
    }

  </style>
@endsection