@extends('layouts.dashboard')

@section('title', trans('dashboard.laporan.saldo_piutang'))

@section('content')
    <!-- begin #content -->
    <div id="content" class="content">
        {{ Breadcrumbs::render('laporan_saldo_piutang') }}
        <!-- begin row -->
        <div class="row">
            <!-- begin col-12 -->
            <div class="col-md-12">
                <!-- begin panel -->
                <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                    <div class="panel-heading">
                        <div class="panel-heading-btn">
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default"
                                data-click="panel-expand">
                                <i class="fa fa-expand"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success"
                                data-click="panel-reload"><i class="fa fa-repeat"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning"
                                data-click="panel-collapse">
                                <i class="fa fa-minus"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger"
                                data-click="panel-remove">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                        <h4 class="panel-title">{{ trans('dashboard.laporan.saldo_piutang') }}</h4>
                    </div>
                    <div class="panel-body">
                        <form action="{{ route('saldo-piutang.laporan') }}" method="GET" style="margin-bottom: 1em;">
                            <div class="form-group row" style="margin-bottom: 1em;">
                                <div class="col-md-3">
                                    <label for="dari_tanggal" class="control-label">Dari Tanggal</label>
                                    <input type="date" name="dari_tanggal" class="form-control" id="dari_tanggal"
                                        value="{{ request()->query('dari_tanggal') ? request()->query('dari_tanggal') : date('Y-m-01') }}"
                                        required />
                                </div>
                                <div class="col-md-3">
                                    <label for="sampai_tanggal" class="control-label">Sampai Tanggal</label>
                                    <input type="date" name="sampai_tanggal" class="form-control" id="sampai_tanggal"
                                        value="{{ request()->query('sampai_tanggal') ? request()->query('sampai_tanggal') : date('Y-m-d') }}"
                                        required />
                                </div>

                                <div class="col-md-3">
                                    <label for="matauang" class="control-label">Mata Uang</label>
                                    <select name="matauang" class="form-control" id="matauang">
                                        @forelse ($matauang as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('matauang') && request()->query('matauang') == $item->id ? 'selected' : '' }}>
                                                {{ $item->nama }}
                                            </option>
                                        @empty
                                            <option value="" selected disabled>Data tidak ditemukan</option>
                                        @endforelse
                                    </select>
                                </div>

                                <div class="col-md-3">
                                    <label for="pelanggan" class="control-label">Pelanggan</label>
                                    <select name="pelanggan" class="form-control" id="pelanggan">
                                        <option value="" selected>All</option>
                                        @forelse ($pelanggan as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('pelanggan') && request()->query('pelanggan') == $item->id ? 'selected' : '' }}>
                                                {{ $item->nama_pelanggan }}
                                            </option>
                                        @empty
                                            <option value="" selected disabled>Data tidak ditemukan</option>
                                        @endforelse
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="salesman" class="control-label">Salesman</label>
                                    <select name="salesman" class="form-control" id="salesman">
                                        <option value="" selected>All</option>
                                        @forelse ($salesman as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('salesman') && request()->query('salesman') == $item->id ? 'selected' : '' }}>
                                                {{ $item->nama }}
                                            </option>
                                        @empty
                                            <option value="" selected disabled>Data tidak ditemukan</option>
                                        @endforelse
                                    </select>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary">
                                <i class="fa fa-eye"></i> Cek
                            </button>
                            <a href="{{ route('saldo-piutang.laporan') }}"
                                class="btn btn-sm btn-default{{ request()->query() ? '' : ' disabled' }}">
                                <i class="fa fa-trash"></i> Reset
                            </a>
                            @if( !empty($laporan) )
                                <a href="{{ route('saldo-piutang.cetak', request()->query()) }}" target="_blank"
                                    class="btn btn-sm btn-success">
                                    <i class="fa fa-print"></i> Cetak
                                </a>
                            @endif
                        </form>

                        <table class="table table-striped table-condensed" style="margin-top: 1em;" id="master-table">
                            <thead>
                                <tr>
                                    <th width="15">No.</th>
                                    <th>Kode</th>
                                    <th>Tanggal</th>
                                    <th>Jatuh Tempo</th>
                                    <th>Pelanggan</th>
                                    <th>Salesman</th>
                                    <th>Status</th>
                                    <th>Umur</th>
                                    <th>Nilai Nota</th>
                                    <th>Jumlah Retur</th>
                                    <th>Terbayar</th>
                                    <th>Sisa Pembayaran</th>
                                    <th>Giro Tertahan</th>
                                    <th>Giro Tolak</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $total_nilai_nota    = 0;
                                    $total_nilai_retur   = 0;
                                    $total_terbayar      = 0;
                                    $total_sisa          = 0;
                                    $total_tertahan      = 0;
                                    $total_tolak         = 0;

                                    $no = 1;
                                @endphp
                                @forelse ($laporan as $item)
                                    @if( $item->sisa_pembayaran != 0 )
                                        @php
                                            $umur_nota = $item->tanggal->diffForHumans();

                                            if( $item->due_date=='0000-00-00' ){
                                                $item->due_date = date('Y-m-d', strtotime($item->tanggal . " +{$item->pelanggan->top} days")); 
                                                DB::table('penjualan')->where('id', $item->id)->update(['due_date' => $item->due_date]);
                                            }

                                            $now  = time();   
                                            $due_date = strtotime($item->due_date);
                                            $datediff = round( ($now - $due_date) / (60 * 60 * 24));

                                            $class = '';
                                            if($datediff >= 30 && $datediff <=59 )      $class = 'alert-small';
                                            else if($datediff >= 60 && $datediff <=89 ) $class = 'alert-medium';
                                            else if($datediff >= 90 ) $class = 'alert-high';

                                            $umur = round( ($now - strtotime($item->tanggal)) / (60 * 60 * 24));
                                        @endphp

                                        <tr class="{{ $class }}">
                                            <td>{{ $no++ }}</td>
                                            <td>{{ $item->kode }}</td>
                                            <td>{{ $item->tanggal->format('d/m/Y') }}</td>
                                            <td>{{ $item->due_date!='0000-00-00' ? date('d/m/Y', strtotime($item->due_date)) : '' }}</td>
                                            <td>{{ $item->pelanggan ? $item->pelanggan->nama_pelanggan : 'Umum' }}</td>
                                            <td>{{ $item->salesman && $item->salesman->nama ? $item->salesman->nama : '' }}</td>
                                            <td>{{ $item->status }}</td>
                                            <td>{{ $umur_nota }}</td>
                                            <td align="right">{{ number_format($item->total_netto) }} </td>
                                            <td align="right">{{ number_format($item->total_retur)  }} </td>
                                            <td align="right">{{ number_format($item->total_paid)  }} </td>
                                            <td align="right">{{ number_format($item->sisa_pembayaran)  }} </td>
                                            <td align="right">{{ number_format($item->giro_tertahan)  }} </td>
                                            <td align="right">{{ number_format($item->giro_tolak)  }} </td>
                                        </tr>                                    
                                        @php
                                            $total_nilai_nota    += $item->total_netto;
                                            $total_nilai_retur   += $item->total_retur;
                                            $total_terbayar      += $item->total_paid;
                                            $total_sisa          += $item->sisa_pembayaran;
                                            $total_tertahan      += $item->giro_tertahan;
                                            $total_tolak         += $item->giro_tolak;
                                        @endphp
                                        <tr>
                                            <th colspan="2"></th>
                                            <th colspan="2">Kode</th>
                                            <th colspan="2">Jenis Pembayaran</th>
                                            <th colspan="2">Status</th>
                                            <th colspan="2">Rate</th>
                                            <th colspan="2">Nilai</th>
                                            <th colspan="2"></th>
                                        </tr>
                                        @foreach ($item->payment_detail as $pd)
                                            <tr>
                                                <td colspan="2"></td>
                                                <td colspan="2">{{ $pd->pelunasan_piutang->pelunasan_piutang->kode }}</td>
                                                <td colspan="2">
                                                    {{ $pd->jenis_pembayaran }}
                                                    @if ($pd->jenis_pembayaran == 'Transfer')
                                                        <br>
                                                        Bank: {{ $pd->bank->nama }}
                                                        <br>
                                                        Rekening:
                                                        {{ $pd->rekening_bank ? $pd->rekening_bank->nomor_rekening . ' - ' . $pd->rekening_bank->nama_rekening : '' }}
                                                    @endif

                                                    @if ($pd->jenis_pembayaran == 'Giro')
                                                        <br>
                                                        No Cek/Giro: {{ $pd->no_cek_giro }}
                                                        <br>
                                                        Tgl Cek/Giro:
                                                        {{ date('d F Y', strtotime($pd->tgl_cek_giro)) }}
                                                    @endif
                                                </td>
                                                <td colspan="2" style='text-align: center'>{{ $pd->status }}</td>
                                                <td colspan="2" style='text-align: center'>{{ number_format($pd->pelunasan_piutang->pelunasan_piutang->rate)  }} </td>
                                                <td colspan="2" style='text-align: right'>{{ number_format($pd->bayar)  }} </td>
                                                <td colspan="2"></td>
                                            </tr>
                                        @endforeach
                                    @endif
                                @empty
                                    <tr>
                                        <td colspan="14" class="text-center">Data tidak ditemukan</td>
                                    </tr>
                                @endforelse
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="8">Total</th>
                                    <th style="text-align: right;">{{ number_format($total_nilai_nota) }}</th>
                                    <th style="text-align: right;">{{ number_format($total_nilai_retur) }}</th>
                                    <th style="text-align: right;">{{ number_format($total_terbayar) }}</th>
                                    <th style="text-align: right;">{{ number_format($total_sisa) }}</th>
                                    <th style="text-align: right;">{{ number_format($total_tertahan) }}</th>
                                    <th style="text-align: right;">{{ number_format($total_tolak) }}</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <!-- end panel -->
            </div>
            <!-- end col-12 -->
        </div>
        <!-- end row -->
    </div>
    <!-- end #content -->
@endsection

@push('custom-css')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css" />
    <style type="text/css">
        .dataTables_length{
            display: block;
            width: 100%;
        }
        .alert-small td{
            background-color: salmon !important;
            color: #000 !important;
        }

        .alert-medium td{
            background-color: #e92929 !important;
            color: #000 !important;
            font-weight: 500;
        }

        .alert-high td{
            background-color: #9d0c0c !important;
            color: #e3e3e3 !important;
            font-weight: bolder;
        }

    </style>
@endpush

@push('custom-js')
    
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>

    <script type="text/javascript">
      let dataTable, tbData = {};
      $(function () {
        dataTable = $("#master-table").DataTable({
            "aLengthMenu": [
                [25, 50, 75, 100, -1],
                [25, 50, 75, 100, 'All']
            ],
            "iDisplayLength": 25,
            "fixedHeader": {
                header: true
            },
            dom: 'lBfrtip',
            buttons: [ 'excel', 'pdf', 'print' ],
            "language": {
                "lengthMenu": "_MENU_ data",
            },
            "order": [
                [0, "asc"]
            ]
        });
        
      });
    </script>
@endpush