@extends('layouts.cetak2')
@section('title', 'Laporan Saldo Piutang')

@section('content')
  <main>
    <h3>{{ $toko->nama }}</h3>
    <center><strong style="text-transform: uppercase;">Laporan Saldo Piutang</strong></center><br/>
    <table style="margin-bottom: 0;">
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Tanggal</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ date('d-M-Y', strtotime($param['dari_tanggal'])) }} - {{ date('d-M-Y', strtotime($param['sampai_tanggal'])) }} </td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Pelanggan</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['pelanggan'] ? $param['pelanggan']->nama_pelanggan : 'Semua Pelanggan' }}</td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Salesman</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['salesman'] ? $param['salesman']->nama : 'Semua Salesman' }}</td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Status</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['status'] && $param['status']!='all' ? $param['status'] : 'Semua Status' }}</td>
      </tr>
    </table>
    <br/>
    <table class="main" cellspacing="0" cellpadding="0" border="1">
        <thead>
            <tr>
              <th>No.</th>
              <th>Kode</th>
              <th>Tanggal</th>
              <th>Jatuh Tempo</th>
              <th>Pelanggan</th>
              <th>Salesman</th>
              <th>Status</th>
              <th>Umur</th>
              <th>Nilai Nota</th>
              <th>Jumlah Retur</th>
              <th>Terbayar</th>
              <th>Sisa Pembayaran</th>
              <th>Giro Tertahan</th>
              <th>Giro Tolak</th>
            </tr>
        </thead>
        <tbody>
            @php
                $total_nilai_nota    = 0;
                $total_nilai_retur   = 0;
                $total_terbayar      = 0;
                $total_sisa          = 0;
                $total_tertahan      = 0;
                $total_tolak         = 0;

                $no = 1;
            @endphp
            @forelse ($reportData as $item)
                @if( $item->sisa_pembayaran != 0 )
                    @php
                        $umur_nota = $item->tanggal->diffForHumans();

                        if( $item->due_date=='0000-00-00' ){
                            $item->due_date = date('Y-m-d', strtotime($item->tanggal . " +{$item->pelanggan->top} days")); 
                            DB::table('penjualan')->where('id', $item->id)->update(['due_date' => $item->due_date]);
                        }

                        $now  = time();   
                        $due_date = strtotime($item->due_date);
                        $datediff = round( ($now - $due_date) / (60 * 60 * 24));

                        $class = '';
                        if($datediff >= 30 && $datediff <=59 )      $class = 'alert-small';
                        else if($datediff >= 60 && $datediff <=89 ) $class = 'alert-medium';
                        else if($datediff >= 90 ) $class = 'alert-high';

                        $umur = round( ($now - strtotime($item->tanggal)) / (60 * 60 * 24));
                    @endphp

                    <tr class="{{ $class }}">
                        <td>{{ $no++ }}</td>
                        <td>{{ $item->kode }}</td>
                        <td>{{ $item->tanggal->format('d/m/Y') }}</td>
                        <td>{{ $item->due_date!='0000-00-00' ? date('d/m/Y', strtotime($item->due_date)) : '' }}</td>
                        <td>{{ $item->pelanggan ? $item->pelanggan->nama_pelanggan : 'Umum' }}</td>
                        <td>{{ $item->salesman && $item->salesman->nama ? $item->salesman->nama : '' }}</td>
                        <td>{{ $item->status }}</td>
                        <td>{{ $umur_nota }}</td>
                        <td align="right">{{ number_format($item->total_netto) }} </td>
                        <td align="right">{{ number_format($item->total_retur)  }} </td>
                        <td align="right">{{ number_format($item->total_paid)  }} </td>
                        <td align="right">{{ number_format($item->sisa_pembayaran)  }} </td>
                        <td align="right">{{ number_format($item->giro_tertahan)  }} </td>
                        <td align="right">{{ number_format($item->giro_tolak)  }} </td>
                    </tr>                                    
                    @php
                        $total_nilai_nota    += $item->total_netto;
                        $total_nilai_retur   += $item->total_retur;
                        $total_terbayar      += $item->total_paid;
                        $total_sisa          += $item->sisa_pembayaran;
                        $total_tertahan      += $item->giro_tertahan;
                        $total_tolak         += $item->giro_tolak;
                    @endphp
                    <tr>
                        <th colspan="2"></th>
                        <th colspan="2">Kode</th>
                        <th colspan="2">Jenis Pembayaran</th>
                        <th colspan="2">Status</th>
                        <th colspan="2">Rate</th>
                        <th colspan="2">Nilai</th>
                        <th colspan="2"></th>
                    </tr>
                    @foreach ($item->payment_detail as $pd)
                        <tr>
                            <td colspan="2"></td>
                            <td colspan="2">{{ $pd->pelunasan_piutang->pelunasan_piutang->kode }}</td>
                            <td colspan="2">
                                {{ $pd->jenis_pembayaran }}
                                @if ($pd->jenis_pembayaran == 'Transfer')
                                    <br>
                                    Bank: {{ $pd->bank->nama }}
                                    <br>
                                    Rekening:
                                    {{ $pd->rekening_bank ? $pd->rekening_bank->nomor_rekening . ' - ' . $pd->rekening_bank->nama_rekening : '' }}
                                @endif

                                @if ($pd->jenis_pembayaran == 'Giro')
                                    <br>
                                    No Cek/Giro: {{ $pd->no_cek_giro }}
                                    <br>
                                    Tgl Cek/Giro:
                                    {{ date('d F Y', strtotime($pd->tgl_cek_giro)) }}
                                @endif
                            </td>
                            <td colspan="2" style='text-align: center'>{{ $pd->status }}</td>
                            <td colspan="2" style='text-align: center'>{{ number_format($pd->pelunasan_piutang->pelunasan_piutang->rate)  }} </td>
                            <td colspan="2" style='text-align: right'>{{ number_format($pd->bayar)  }} </td>
                            <td colspan="2"></td>
                        </tr>
                    @endforeach
                @endif
            @empty
                <tr>
                    <td colspan="14" class="text-center">Data tidak ditemukan</td>
                </tr>
            @endforelse
        </tbody>
        <tfoot>
            <tr>
                <th colspan="8">Total</th>
                <th style="text-align: right;">{{ number_format($total_nilai_nota) }}</th>
                <th style="text-align: right;">{{ number_format($total_nilai_retur) }}</th>
                <th style="text-align: right;">{{ number_format($total_terbayar) }}</th>
                <th style="text-align: right;">{{ number_format($total_sisa) }}</th>
                <th style="text-align: right;">{{ number_format($total_tertahan) }}</th>
                <th style="text-align: right;">{{ number_format($total_tolak) }}</th>
            </tr>
        </tfoot>
    </table>
    <div id="printPageButton" style="text-align: center;">
      <button onClick="window.print();" style="margin-top: 100px;">Print</button>
    </div>
  </main>
            
@endsection

@section('headers')
  <style type="text/css">
    @media print {
      #printPageButton {
        display: none;
      }
    }
    body{
      width: 85% !important;
    }

    table td {
      text-align: left;
    }

    table th{
      font-weight: bolder;
    }

    table th, 
    table td {
        padding: 5px;
    }

    .button-7 {
      background-color: #0095ff;
      border: 1px solid transparent;
      border-radius: 3px;
      box-shadow: rgba(255, 255, 255, .4) 0 1px 0 0 inset;
      box-sizing: border-box;
      color: #fff;
      cursor: pointer;
      display: inline-block;
      font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
      font-size: 13px;
      font-weight: 400;
      line-height: 1.15385;
      margin: 0;
      outline: none;
      padding: 8px .8em;
      position: relative;
      text-align: center;
      text-decoration: none;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
      vertical-align: baseline;
      white-space: nowrap;
    }

    .button-7:hover,
    .button-7:focus {
      background-color: #07c;
    }

    .button-7:focus {
      box-shadow: 0 0 0 4px rgba(0, 149, 255, .15);
    }

    .button-7:active {
      background-color: #0064bd;
      box-shadow: none;
    }

  </style>
@endsection