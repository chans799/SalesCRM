@extends('layouts.dashboard')

@section('title', trans('dashboard.laporan.stok_barang'))

@section('content')
    <!-- begin #content -->
    <div id="content" class="content">
        {{ Breadcrumbs::render('laporan_stok_barang') }}
        <!-- begin row -->
        <div class="row">
            <!-- begin col-12 -->
            <div class="col-md-12">
                <!-- begin panel -->
                <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                    <div class="panel-heading">
                        <div class="panel-heading-btn">
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default"
                                data-click="panel-expand">
                                <i class="fa fa-expand"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success"
                                data-click="panel-reload"><i class="fa fa-repeat"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning"
                                data-click="panel-collapse">
                                <i class="fa fa-minus"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger"
                                data-click="panel-remove">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                        <h4 class="panel-title">{{ trans('dashboard.laporan.stok_barang') }}</h4>
                    </div>
                    <div class="panel-body">
                        <table border="0" class="opt-data" style="margin-bottom: 40px; width: 450px;">
                            <tbody>
                              <tr>
                                <td style="min-width: 60px;"><b>Saldo Per</b></td>
                                <td style="padding: 5px 0;"><input type="date" class="form-control" id="waktu" value="{{ date('Y-m-d') }}" ></td>
                              </tr> 
                              <tr>
                                <td style="min-width: 60px;"><b>Barang</b></td>
                                <td style="padding: 5px 0;">
                                    <select name="barang" class="form-control select2" id="barang" style="width: 100%">
                                        <option value="" selected>All</option>
                                        @forelse ($barang as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('barang') && request()->query('barang') == $item->id ? 'selected' : '' }}>
                                                {{ $item->kode . ' - ' . $item->nama }}
                                            </option>
                                        @empty
                                            <option value="" selected disabled>Data tidak ditemukan</option>
                                        @endforelse
                                    </select>
                                </td>
                              </tr> 
                              <tr>
                                <td style="min-width: 60px;"><b>Gudang</b></td>
                                <td style="padding: 5px 0;">
                                    <select name="gudang" class="form-control select2" id="gudang" style="width: 100%">
                                        <option value="" selected>All</option>
                                        @forelse ($gudang as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('gudang') && request()->query('gudang') == $item->id ? 'selected' : '' }}>
                                                {{ $item->nama }}
                                            </option>
                                        @empty
                                            <option value="" selected disabled>Data tidak ditemukan</option>
                                        @endforelse
                                    </select>
                                </td>
                              </tr> 
                              <tr>
                                <td colspan="2" style="text-align: right; padding: 10px 0;">
                                   <button type="button" id="print-data" class="btn btn-success btn-flat btn-sm">
                                    <i class="fa fa-print"></i> Cetak</button>
                                  <button type="button" id="show-info-data" class="btn btn-danger btn-flat btn-sm">View Report</button>
                                </td>
                              </tr>
                            </tbody>
                        </table>

                        <div class="table-responsive">
                            <table class="table table-striped table-condensed data-table" id="master-table" style="margin-top: 1em;">
                                <thead>
                                    <tr>
                                        <th>Kode</th>
                                        <th>Barang</th>
                                        <th>Qty</th>
                                        <th>Nilai Barang</th>
                                    </tr>
                                </thead>
                                <tbody> </tbody>

                              <!--   <tfoot>
                                    <tr>
                                        <th> </th>
                                        <th>Total</th>
                                        <th id="total-qty">0</th>
                                        <th id="total-value">0</th>
                                    </tr>
                                </tfoot> -->
                            </table>
                        </div>
                    </div>
                </div>
                <!-- end panel -->
            </div>
            <!-- end col-12 -->
        </div>
        <!-- end row -->
    </div>
    <!-- end #content -->
@endsection

@push('custom-css')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css" />
    <style type="text/css">
        .dataTables_length{
            display: block;
            width: 100%;
        }
    </style>
@endpush

@push('custom-js')
    
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>

    <script type="text/javascript">
      let dataTable, tbData = {};
      $(function () {
        tbData.action   = 'view_report';
        tbData.waktu    = '{{ date("Y-m-d") }}';
        tbData.gudang   = 'all';
        tbData.barang   = 'all';
        tbData._token   = "{{ csrf_token() }}";

        dataTable = $("#master-table").DataTable({
            "aLengthMenu": [
                [25, 50, 75, 100, -1],
                [25, 50, 75, 100, 'All']
            ],
            "iDisplayLength": 25,
            "fixedHeader": {
                header: true
            },
            dom: 'lBfrtip',
            buttons: [ 'excel', 'pdf', 'print' ],
            "language": {
                "lengthMenu": "_MENU_ produk",
            },
            "processing": true,
            "serverSide": true,
            "ajax": {
              url: `{{ route('stok-barang.laporan') }}`,
              type: "POST",
              dataType: "json",
              data:function ( d ) {
                return  $.extend(d, tbData);
              },
            },  
            "columns": [
                { "data": "kode", }, 
                { "data": "barang", }, 
                { "data": "qty" },
                { "data": "nilai" },
            ],
            "order": [
                [1, "asc"]
            ],
        });

        $("#show-info-data").click(function(){
          tbData.waktu   = $("#waktu").val();
          tbData.barang  = $("#barang").val();
          tbData.gudang  = $("#gudang").val();

          $("#show-info-data").html("Loading...");
          dataTable.ajax.reload(function(e){
            $("#show-info-data").html("View Report");
          }, false);            
        });

        $("#print-data").click(function(e){
            e.preventDefault();

            let waktu   = $("#waktu").val();
            let barang  = $("#barang").val();
            let gudang  = $("#gudang").val();
            let url = `{{ route('stok-barang.cetak') }}?waktu=${waktu}&barang=${barang}&gudang=${gudang}`;

            window.open(url, '_blank').focus();
        })
        
      });
    </script>
@endpush