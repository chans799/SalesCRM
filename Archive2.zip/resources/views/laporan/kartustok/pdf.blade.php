<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ trans('dashboard.laporan.stok_barang') }}</title>

    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            font-size: 11px;
            border-left: 0;
            margin-bottom: 1em;
        }

        table td,
        table th,
        table tfoot {
            border: 1px solid black;
            padding: 3px;
            border-left: 0px solid;
            border-right: 0px solid;
        }

        /* table tr:nth-child(even) {
            background-color: #F2F2F2;
        } */

        table th,
        table tfoot {
            padding-top: 8px;
            padding-bottom: 8px;
            text-align: left;
            /* background-color: #158CBA; */
            color: black;
        }

        p,
        h4 {
            line-height: 8px;
        }

        small {
            font-size: 12px;
        }

        .garis {
            height: 3px;
            border-top: 3px solid black;
            border-bottom: 1px solid black;
        }

    </style>
</head>

<body>
    <div>
        <center>
            <h4>{{ trans('dashboard.laporan.stok_barang') }}</h4>
            <p><small>{{ date('d F Y') }}</small></p>
        </center>

        <table style="margin-bottom: 1em;">
            <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>TrCd</th>	
                                        <th>Nomor</th>	
                                        <th>Line</th>
                                        <th>Tanggal	</th>
                                        <th>RfCd	</th>
                                        <th>RfNomor	</th>
                                        <th>RfLine</th>
                                        <th>Jenis	</th>
                                        <th>Barang</th>
                                        <th>Debet	</th>
                                        <th>Kredit	</th>
                                        <th>Saldo	</th>
                                        <th>Harga Beli	</th>
                                        <th>Total Harga	</th>
                                        <th>Rate	</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    @if(empty($laporan))
                                    <tr>
                                        <td colspan="15" class="text-center">Data tidak ditemukan </td>
                                    </tr>
                                    @endif
                                    @foreach($laporan as $lp)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $lp->trcd }} </td>
                                        <td>{{ $lp->nomor }}</td>
                                        <td>{{ $lp->line }}</td>
                                        <td>{{ $lp->tanggal }}</td>
                                        <td>{{ $lp->rfcd }}</td>
                                        <td>{{ $lp->rfnomor }}</td>
                                        <td>{{ $lp->rfline }}</td>
                                        <td>@if($lp->fkonsinyasi == 'FALSE') {{ 'Non Konsi' }} @else {{ 'Konsinyasi' }} @endif</td>
                                        <td>@if (($barang = \App\Models\Barang::find($lp->barang_id)) != null) {{ $barang->kode }} @endif</td>
                                        <td>{{ $lp->debet }}</td>
                                        <td>{{ $lp->kredit }}</td>
                                        <td>{{ $lp->saldo }}</td>
                                        <td>{{ number_format($lp->harga,2,',','.') }}</td>
                                        <td>{{ number_format($lp->total_harga,2,',','.') }}</td>
                                        <td>{{ $lp->rate }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>

        </table>

        <small>
            <strong>
                @if (request()->query('per_tanggal'))
                    Laporan Tanggal:
                    {{ date('d F Y', strtotime(request()->query('per_tanggal'))) }}
                @endif
            </strong>
        </small>
    </div>

</body>

</html>
