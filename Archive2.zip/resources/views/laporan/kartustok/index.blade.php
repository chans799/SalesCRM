@extends('layouts.dashboard')

@section('title', 'Laporan Kartu Stok')

@section('content')
    <!-- begin #content -->
    <div id="content" class="content">
        {{ Breadcrumbs::render('laporan_stok') }}
        <!-- begin row -->
        <div class="row">
            <!-- begin col-12 -->
            <div class="col-md-12">
                <!-- begin panel -->
                <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                    <div class="panel-heading">
                        <div class="panel-heading-btn">
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default"
                                data-click="panel-expand">
                                <i class="fa fa-expand"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success"
                                data-click="panel-reload"><i class="fa fa-repeat"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning"
                                data-click="panel-collapse">
                                <i class="fa fa-minus"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger"
                                data-click="panel-remove">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                        <h4 class="panel-title">Data Stok</h4>
                    </div>
                    <div class="panel-body">
                        <form action="{{ route('stock.laporan') }}" method="GET" style="margin-bottom: 1em;">
                            <div class="form-group row" style="margin-bottom: 1em;">
                                <div class="col-md-3">
                                    <label for="per_tanggal" class="control-label">Dari Tanggal</label>
                                    <input type="date" name="per_tanggal" class="form-control" id="per_tanggal"
                                        value="{{ request()->query('per_tanggal') ? request()->query('per_tanggal') : date('Y-m-d') }}"
                                        required />
                                </div>
                                <div class="col-md-3">
                                    <label for="to_date" class="control-label">Hingga Tanggal</label>
                                    <input type="date" name="to_date" class="form-control" id="to_date"
                                        value="{{ request()->query('to_date') ? request()->query('to_date') : date('Y-m-d') }}"
                                        required />
                                </div>

                                <div class="col-md-6">
                                    <label for="gudang" class="control-label">Gudang</label>
                                    <select name="gudang" class="form-control select2" id="gudang">
                                        <option value="" selected>All</option>
                                        @forelse ($gudang as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('gudang') && request()->query('gudang') == $item->id ? 'selected' : '' }}>
                                                {{ $item->nama }}
                                            </option>
                                        @empty
                                            <option value="" selected disabled>Data tidak ditemukan</option>
                                        @endforelse
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row" style="margin-bottom: 1em;">
                                <div class="col-md-6">
                                    <label for="barang" class="control-label">Barang</label>
                                    <select name="barang" class="form-control select2" id="barang">
                                        <option value="" selected>All</option>
                                        @forelse ($barang as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('barang') && request()->query('barang') == $item->id ? 'selected' : '' }}>
                                                {{ $item->kode . ' - ' . $item->nama }}
                                            </option>
                                        @empty
                                            <option value="" selected disabled>Data tidak ditemukan</option>
                                        @endforelse
                                    </select>
                                </div>
                                
                                <div class="col-md-6">
                                    <label for="bentuk_kepemilikan_stok">Bentuk Kepemilikan Stok</label>
                                    <select name="bentuk_kepemilikan_stok" id="bentuk_kepemilikan_stok"
                                        class="form-control select2">
                                        <option value="" selected>All</option>
                                            <option value="Stok Sendiri"
                                                {{ request()->query('bentuk_kepemilikan_stok') && request()->query('bentuk_kepemilikan_stok') == $item->id ? 'selected' : '' }}>
                                                Stok Sendiri
                                            </option>
                                            <option value="Konsinyasi"
                                                {{ request()->query('bentuk_kepemilikan_stok') && request()->query('bentuk_kepemilikan_stok') == $item->id ? 'selected' : '' }}>
                                                Konsinyasi
                                            </option>
                                    </select>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-sm btn-success">
                                <i class="fa fa-eye"></i> Cek
                            </button>
                            <a href="{{ route('stock.laporan') }}"
                                class="btn btn-sm btn-default{{ request()->query() ? '' : ' disabled' }}">
                                <i class="fa fa-refresh"></i> Reset
                            </a>
                            @if (count($laporan) > 0)
                                <a href="{{ route('stock.cetak', request()->query()) }}" target="_blank"
                                    class="btn btn-sm btn-info">
                                    <i class="fa fa-print"></i> Print
                                </a>                                
                            @endif                             
                        </form>
                    </div>
                    <div class="panel-footer">
                        <div class="table-responsive ">
                            <table class="table table-striped table-condensed data-tables" style="margin-top: 1em;">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>TrCd</th>	
                                        <th>Nomor</th>	
                                        <th>Line</th>
                                        <th>Tanggal	</th>
                                        <th>RfCd	</th>
                                        <th>RfNomor	</th>
                                        <th>RfLine</th>
                                        <th>Jenis	</th>
                                        <th>Barang</th>
                                        <th>Debet	</th>
                                        <th>Kredit	</th>
                                        <th>Saldo	</th>
                                        <th>Harga Beli	</th>
                                        <th>Total Harga	</th>
                                        <th>Rate	</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    @if(empty($laporan))
                                    <tr>
                                        <td colspan="15" class="text-center">Data tidak ditemukan </td>
                                    </tr>
                                    @endif
                                    @foreach($laporan as $lp)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $lp->trcd }} </td>
                                        <td>{{ $lp->nomor }}</td>
                                        <td>{{ $lp->line }}</td>
                                        <td>{{ date('d-m-Y', strtotime($lp->tanggal)) }}</td>
                                        <td>{{ $lp->rfcd }}</td>
                                        <td>{{ $lp->rfnomor }}</td>
                                        <td>{{ $lp->rfline }}</td>
                                        <td>@if($lp->fkonsinyasi == 'FALSE') {{ 'Non Konsi'; }} @else {{ 'Konsinyasi'; }} @endif</td>
                                        <td>@if (($barang = \App\Models\Barang::find($lp->barang_id)) != null) {{ $barang->kode }} @endif</td>
                                        <td>{{ $lp->debet }}</td>
                                        <td>{{ $lp->kredit }}</td>
                                        <td>{{ $lp->saldo }}</td>
                                        <td>{{ number_format($lp->harga,2,',','.') }}</td>
                                        <td>{{ number_format($lp->total_harga,2,',','.') }}</td>
                                        <td>{{ $lp->rate }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>

                                
                            </table>

                        </div>
                    </div>
                </div>
                <!-- end panel -->
            </div>
            <!-- end col-12 -->
        </div>
        <!-- end row -->
    </div>
    <!-- end #content -->
    
    

@endsection
