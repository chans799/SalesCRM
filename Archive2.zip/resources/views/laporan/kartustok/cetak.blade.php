@extends('layouts.cetak2')
@section('title', 'Laporan Kartu Stok')

@section('headers')
  <style type="text/css">
    @media print {
      #printPageButton {
        display: none;
      }
    }
    body{
      width: 99% !important;
    }
    table td {
        padding: 10px 5px;
    }
    table tr:nth-child(2n-1) td {
      background: transparent;
    }
    .button-7 {
      background-color: #0095ff;
      border: 1px solid transparent;
      border-radius: 3px;
      box-shadow: rgba(255, 255, 255, .4) 0 1px 0 0 inset;
      box-sizing: border-box;
      color: #fff;
      cursor: pointer;
      display: inline-block;
      font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
      font-size: 13px;
      font-weight: 400;
      line-height: 1.15385;
      margin: 0;
      outline: none;
      padding: 8px .8em;
      position: relative;
      text-align: center;
      text-decoration: none;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
      vertical-align: baseline;
      white-space: nowrap;
    }

    .button-7:hover,
    .button-7:focus {
      background-color: #07c;
    }

    .button-7:focus {
      box-shadow: 0 0 0 4px rgba(0, 149, 255, .15);
    }

    .button-7:active {
      background-color: #0064bd;
      box-shadow: none;
    }

  </style>
@endsection


@section('content')
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
      <tbody>
        <tr>
          <td align="center">
            <table class="jrPage" data-jr-height="595" cellpadding="0" cellspacing="0" border="0" style="empty-cells: show; width: 100%; border-collapse: collapse; background-color: white;">
              <tbody>
                <tr valign="top" style="height:0">
                  <td style="width:20px"></td>
                  <td style="width:65px"></td>
                  <td style="width:55px"></td>
                  <td style="width:70px"></td>
                  <td style="width:50px"></td>
                  <td style="width:35px"></td>
                  <td style="width:75px"></td>
                  <td style="width:75px"></td>
                  <td style="width:35px"></td>
                  <td style="width:75px"></td>
                  <td style="width:75px"></td>
                  <td style="width:35px"></td>
                  <td style="width:75px"></td>
                  <td style="width:81px"></td>
                </tr>
                <tr valign="top" style="height:30px">
                  
                  <td colspan="14" style="padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: center;">
                    <span style=" color: #0078B0; font-size: 16px; line-height: 1.1640625;">KARTU STOK PERSEDIAAN UMUM</span>
                  </td>
                  
                </tr>
                <tr valign="top" style="height:20px">
                  
                  <td colspan="14" style="padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: center;">
                    <span style=" color: #BF4747; font-size: 12px; line-height: 1.1640625; font-weight: bold;">
                        {{ date("M d, Y", strtotime($report_item['from'])) }} - {{ date("M d, Y", strtotime($report_item['to'])) }}</span>
                  </td>
                  
                </tr>

                @foreach($report_item['branch'] as $br)
                    <tr valign="top" style="height:10px">
                      <td colspan="14"><hr /></td>
                    </tr>
                    <tr valign="top" style="height:30px">
                      
                      <td colspan="14" style="padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: center;">
                        <span style=" color: #000000; font-size: 15px; line-height: 1.1640625; font-weight: bolder;">{{ $br['gudang_nama'] }}</span>
                      </td>
                      
                    </tr>

                    @if( isset($br['item']) )
                      @foreach($br['item'] as $it)
                          <tr valign="top" style="height:20px">
                            
                            <td colspan="7" style="padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: left;">
                              <a href="#">
                                <span style=" color: #0078B0; font-size: 11px; font-weight: bolder; line-height: 1.1640625;">{{ $it['kode'] }} - {{ $it['nama'] }}</span>
                              </a>
                            </td>
                            <td colspan="7" style="padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #0078B0; font-size: 9px; line-height: 1.1640625;"></span>
                            </td>
                          </tr>

                          <tr valign="top" style="height:30px">
                            
                            <td rowspan="2" style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: left;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">TANGGAL</span>
                            </td>
                            <td rowspan="2" style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: left;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">TRANSAKSI</span>
                            </td>
                            <td rowspan="2" style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: left;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">NO. REF</span>
                            </td>
                            <td rowspan="2" style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: left;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">SATUAN</span>
                            </td>
                            <td colspan="3" style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: center;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">MASUK</span>
                            </td>
                            <td colspan="3" style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: center;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">KELUAR</span>
                            </td>
                            <td colspan="4" style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: center;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">SALDO</span>
                            </td>
                            
                          </tr>
                          <tr valign="top" style="height:30px">
                            
                            <td style="border: 1px solid #000; background-color: #107AAE; padding-top: 1px; padding-left: 3px; padding-bottom: 3px; padding-right: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">JML</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding-top: 1px; padding-left: 3px; padding-bottom: 3px; padding-right: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">HARGA POKOK</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding-top: 1px; padding-left: 3px; padding-bottom: 3px; padding-right: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">NILAI</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding-top: 1px; padding-left: 3px; padding-bottom: 3px; padding-right: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">JML</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding-top: 1px; padding-left: 3px; padding-bottom: 3px; padding-right: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">HARGA POKOK</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding-top: 1px; padding-left: 3px; padding-bottom: 3px; padding-right: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">NILAI</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding-top: 1px; padding-left: 3px; padding-bottom: 3px; padding-right: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">JML</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding-top: 1px; padding-left: 3px; padding-bottom: 3px; padding-right: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">HARGA POKOK</span>
                            </td>
                            <td colspan="2" style="border: 1px solid #000; background-color: #107AAE; padding-top: 1px; padding-left: 3px; padding-bottom: 3px; padding-right: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">NILAI</span>
                            </td>
                            
                          </tr>

                          @foreach($it['kartu_stock'] as $kr)
                              <tr valign="top" style="height:30px">
                                
                                <td style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: left;">
                                  <span style=" color: #000000; font-size: 10px; line-height: 1.1640625;">{{ $kr['tanggal']!='Saldo Awal' ? date("M d, Y", strtotime($kr['tanggal'])) : 'Saldo Awal' }}</span>
                                </td>
                                <td style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: left;">
                                  <span style=" color: #000000; font-size: 10px; line-height: 1.1640625;">{{ isset($kr['jenis']) ? $kr['jenis'] : '' }}</span>
                                </td>
                                <td style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: left;">
                                  <a href="#">
                                    <span style=" color: #0078B0; font-size: 10px; line-height: 1.1640625;">{{ isset($kr['reff']) ? $kr['reff'] : '' }}</span>
                                  </a>
                                </td>
                                <td style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: left;">
                                  <span style=" color: #000000; font-size: 10px; line-height: 1.1640625;">{{ isset($kr['satuan']) ? $kr['satuan'] : '' }}</span>
                                </td>
                                <td style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                                  <span style=" color: #000000; font-size: 10px; line-height: 1.1640625;">{{ isset($kr['in_jml']) ? number_format($kr['in_jml'],2) : '' }}</span>
                                </td>
                                <td style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                                  <span style=" color: #000000; font-size: 10px; line-height: 1.1640625;">{{ isset($kr['in_hapok']) ? number_format($kr['in_hapok'],2) : '' }}</span>
                                </td>
                                <td style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                                  <span style=" color: #000000; font-size: 10px; line-height: 1.1640625;">{{ isset($kr['in_nilai']) ? number_format($kr['in_nilai'],2) : '' }}</span>
                                </td>
                                <td style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                                  <span style=" color: #a72727; font-size: 10px; line-height: 1.1640625;">{{ isset($kr['out_jml']) ? number_format($kr['out_jml'],2) : '' }}</span>
                                </td>
                                <td style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                                  <span style=" color: #a72727; font-size: 10px; line-height: 1.1640625;">{{ isset($kr['out_hapok']) ? number_format($kr['out_hapok'],2) : '' }}</span>
                                </td>
                                <td style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                                  <span style=" color: #a72727; font-size: 10px; line-height: 1.1640625;">{{ isset($kr['out_nilai']) ? number_format($kr['out_nilai'],2) : '' }}</span>
                                </td>
                                <td style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                                  <span style=" color: #000000; font-size: 10px; line-height: 1.1640625;">{{ isset($kr['saldo_jml']) ? number_format($kr['saldo_jml'],2) : '' }}</span>
                                </td>
                                <td style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                                  <span style=" color: #000000; font-size: 10px; line-height: 1.1640625;">{{ isset($kr['saldo_hapok']) ? number_format($kr['saldo_hapok'],2) : '' }}</span>
                                </td>
                                <td colspan="2" style="border: 1px solid #000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                                  <span style=" color: #000000; font-size: 10px; line-height: 1.1640625;">{{ isset($kr['saldo_nilai']) ? number_format($kr['saldo_nilai'],2) : '' }}</span>
                                </td>
                                
                              </tr>
                          @endforeach

                          <tr valign="top" style="height:30px">
                            
                            <td colspan="4" style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: left;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625; font-weight: bolder;">Total {{ $it['nama'] }}</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($it['total']['in_jml']) ? number_format($it['total']['in_jml'],2) : '' }}</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($it['total']['in_hapok']) ? number_format($it['total']['in_hapok'],2) : '' }}</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($it['total']['in_nilai']) ? number_format($it['total']['in_nilai'],2) : '' }}</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($it['total']['out_jml']) ? number_format($it['total']['out_jml'],2) : '' }}</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($it['total']['out_hapok']) ? number_format($it['total']['out_hapok'],2) : '' }}</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($it['total']['out_nilai']) ? number_format($it['total']['out_nilai'],2) : '' }}</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($it['total']['saldo_jml']) ? number_format($it['total']['saldo_jml'],2) : '' }}</span>
                            </td>
                            <td style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($it['total']['saldo_hapok']) ? number_format($it['total']['saldo_hapok'],2) : '' }}</span>
                            </td>
                            <td colspan="2" style="border: 1px solid #000; background-color: #107AAE; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                              <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($it['total']['saldo_nilai']) ? number_format($it['total']['saldo_nilai'],2) : '' }}</span>
                            </td>
                            
                          </tr>
                          <tr valign="top" style="height:60px">
                            <td colspan="16"></td>
                          </tr>
                      @endforeach
                    @endif

                    <tr valign="top" style="height:40px">
                      
                      <td colspan="4" style="border: 1px solid #000; background-color: #067716; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: left;">
                        <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625; font-weight: bolder;">TOTAL KESELURUHAN: {{ strtoupper($br['gudang_nama']) }}</span>
                      </td>
                      <td style="border: 1px solid #000; background-color: #067716; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                        <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($br['total']['in_jml']) ? number_format($br['total']['in_jml'],2) : '' }}</span>
                      </td>
                      <td style="border: 1px solid #000; background-color: #067716; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                        <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($br['total']['in_hapok']) ? number_format($br['total']['in_hapok'],2) : '' }}</span>
                      </td>
                      <td style="border: 1px solid #000; background-color: #067716; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                        <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($br['total']['in_nilai']) ? number_format($br['total']['in_nilai'],2) : '' }}</span>
                      </td>
                      <td style="border: 1px solid #000; background-color: #067716; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                        <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($br['total']['out_jml']) ? number_format($br['total']['out_jml'],2) : '' }}</span>
                      </td>
                      <td style="border: 1px solid #000; background-color: #067716; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                        <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($br['total']['out_hapok']) ? number_format($br['total']['out_hapok'],2) : '' }}</span>
                      </td>
                      <td style="border: 1px solid #000; background-color: #067716; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                        <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($br['total']['out_nilai']) ? number_format($br['total']['out_nilai'],2) : '' }}</span>
                      </td>
                      <td style="border: 1px solid #000; background-color: #067716; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                        <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($br['total']['saldo_jml']) ? number_format($br['total']['saldo_jml'],2) : '' }}</span>
                      </td>
                      <td style="border: 1px solid #000; background-color: #067716; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                        <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($br['total']['saldo_hapok']) ? number_format($br['total']['saldo_hapok'],2) : '' }}</span>
                      </td>
                      <td colspan="2" style="border: 1px solid #000; background-color: #067716; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                        <span style=" color: #FFFFFF; font-size: 10px; line-height: 1.1640625;">{{ isset($br['total']['saldo_nilai']) ? number_format($br['total']['saldo_nilai'],2) : '' }}</span>
                      </td>
                      
                    </tr>
                @endforeach

                <tr valign="top" style="height:80px">
                  <td colspan="16"></td>
                </tr>

                <tr valign="top" style="height:40px">
                  
                  <td colspan="4" style="border: 1px solid #000; background-color: #9e0000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: left;">
                    <span style=" color: #FFFFFF; font-size: 14px; font-weight: bolder; line-height: 1.1640625; font-weight: bolder;">TOTAL KESELURUHAN GUDANG</span>
                  </td>
                  <td style="border: 1px solid #000; background-color: #9e0000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                    <span style=" color: #FFFFFF; font-size: 14px; font-weight: bolder; line-height: 1.1640625;">{{ isset($report_item['total']['in_jml']) ? number_format($report_item['total']['in_jml'],2) : '' }}</span>
                  </td>
                  <td style="border: 1px solid #000; background-color: #9e0000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                    <span style=" color: #FFFFFF; font-size: 14px; font-weight: bolder; line-height: 1.1640625;">{{ isset($report_item['total']['in_hapok']) ? number_format($report_item['total']['in_hapok'],2) : '' }}</span>
                  </td>
                  <td style="border: 1px solid #000; background-color: #9e0000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                    <span style=" color: #FFFFFF; font-size: 14px; font-weight: bolder; line-height: 1.1640625;">{{ isset($report_item['total']['in_nilai']) ? number_format($report_item['total']['in_nilai'],2) : '' }}</span>
                  </td>
                  <td style="border: 1px solid #000; background-color: #9e0000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                    <span style=" color: #FFFFFF; font-size: 14px; font-weight: bolder; line-height: 1.1640625;">{{ isset($report_item['total']['out_jml']) ? number_format($report_item['total']['out_jml'],2) : '' }}</span>
                  </td>
                  <td style="border: 1px solid #000; background-color: #9e0000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                    <span style=" color: #FFFFFF; font-size: 14px; font-weight: bolder; line-height: 1.1640625;">{{ isset($report_item['total']['out_hapok']) ? number_format($report_item['total']['out_hapok'],2) : '' }}</span>
                  </td>
                  <td style="border: 1px solid #000; background-color: #9e0000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                    <span style=" color: #FFFFFF; font-size: 14px; font-weight: bolder; line-height: 1.1640625;">{{ isset($report_item['total']['out_nilai']) ? number_format($report_item['total']['out_nilai'],2) : '' }}</span>
                  </td>
                  <td style="border: 1px solid #000; background-color: #9e0000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                    <span style=" color: #FFFFFF; font-size: 14px; font-weight: bolder; line-height: 1.1640625;">{{ isset($report_item['total']['saldo_jml']) ? number_format($report_item['total']['saldo_jml'],2) : '' }}</span>
                  </td>
                  <td style="border: 1px solid #000; background-color: #9e0000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                    <span style=" color: #FFFFFF; font-size: 14px; font-weight: bolder; line-height: 1.1640625;">{{ isset($report_item['total']['saldo_hapok']) ? number_format($report_item['total']['saldo_hapok'],2) : '' }}</span>
                  </td>
                  <td colspan="2" style="border: 1px solid #000; background-color: #9e0000; padding: 3px; text-indent: 0px;  vertical-align: middle;text-align: right;">
                    <span style=" color: #FFFFFF; font-size: 14px; font-weight: bolder; line-height: 1.1640625;">{{ isset($report_item['total']['saldo_nilai']) ? number_format($report_item['total']['saldo_nilai'],2) : '' }}</span>
                  </td>
                  
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>

    <div id="printPageButton" style="margin-top: 30px; margin-bottom: 50px; text-align: center;">
      {!! $pagination['text'] !!} {!! $pagination['paging'] !!}
      <button onClick="window.print();">Print</button>
    </div>
@endsection