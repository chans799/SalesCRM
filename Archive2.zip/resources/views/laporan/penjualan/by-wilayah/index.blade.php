@extends('layouts.dashboard')

@section('title', 'Laporan Penjualan By Wilayah')

@section('content')
    <!-- begin #content -->
    <div id="content" class="content">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">Laporan</li>
                <li class="breadcrumb-item active">Penjualan By Wilayah</li>
            </ol>
        </nav>
        <!-- begin row -->
        <div class="row">
            <!-- begin col-12 -->
            <div class="col-md-12">
                <!-- begin panel -->
                <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                    <div class="panel-heading">
                        <div class="panel-heading-btn">
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default"
                                data-click="panel-expand">
                                <i class="fa fa-expand"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success"
                                data-click="panel-reload"><i class="fa fa-repeat"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning"
                                data-click="panel-collapse">
                                <i class="fa fa-minus"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger"
                                data-click="panel-remove">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                        <h4 class="panel-title">Laporan Penjualan By Wilayah</h4>
                    </div>
                    <div class="panel-body">
                        <form action="{{ route('penjualan-by-wilayah.laporan') }}" method="GET" style="margin-bottom: 1em;">
                            <div class="form-group row" style="margin-bottom: 1em;">
                                <div class="col-md-6">
                                    <label for="dari_tanggal" class="control-label">Dari Tanggal</label>
                                    <input type="date" name="dari_tanggal" class="form-control" id="dari_tanggal"
                                        value="{{ request()->query('dari_tanggal') ? request()->query('dari_tanggal') : date('Y-m-d') }}"
                                        required />
                                </div>

                                <div class="col-md-6">
                                    <label for="sampai_tanggal" class="control-label">Sampai Tanggal</label>
                                    <input type="date" name="sampai_tanggal" class="form-control" id="sampai_tanggal"
                                        value="{{ request()->query('sampai_tanggal') ? request()->query('sampai_tanggal') : date('Y-m-d') }}"
                                        required />
                                </div>
                            </div>

                            <div class="form-group row" style="margin-bottom: 1em;">
                                <div class="col-md-6">
                                    <label for="area" class="control-label">Wilayah</label>
                                    <select name="area" class="form-control" id="area">
                                        <option value="" selected>All</option>
                                        @forelse ($area as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('area') && request()->query('area') == $item->id ? 'selected' : '' }}>
                                                {{ $item->nama }}
                                            </option>
                                        @empty
                                            <option value="" selected disabled>Data tidak ditemukan</option>
                                        @endforelse
                                    </select>
                                </div>
                            </div>

                            {{-- <div class="form-group row" style="margin-bottom: 1em;">
                                <div class="col-md-6">
                                    <label for="barang" class="control-label">Barang</label>
                                    <select name="barang" class="form-control" id="barang">
                                        <option value="" selected>All</option>
                                        @forelse ($barang as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('barang') && request()->query('barang') == $item->id ? 'selected' : '' }}>
                                                {{ $item->kode . ' - ' . $item->nama }}
                                            </option>
                                        @empty
                                            <option value="" selected disabled>Data tidak ditemukan</option>
                                        @endforelse
                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label for="bentuk_kepemilikan_stok">Bentuk Kepemilikan Stok</label>
                                    <select name="bentuk_kepemilikan_stok" id="bentuk_kepemilikan_stok"
                                        class="form-control">
                                        <option value="" selected>All</option>
                                        @foreach ($bentukKepemilikanStok as $item)
                                            <option value="{{ $item->id }}"
                                                {{ request()->query('bentuk_kepemilikan_stok') && request()->query('bentuk_kepemilikan_stok') == $item->id ? 'selected' : '' }}>
                                                {{ $item->nama }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div> --}}

                            <button type="submit" class="btn btn-sm btn-primary">
                                <i class="fa fa-eye"></i> Cek
                            </button>
                            <a href="{{ route('penjualan-by-wilayah.laporan') }}"
                                class="btn btn-sm btn-default{{ request()->query() ? '' : ' disabled' }}">
                                <i class="fa fa-trash"></i> Reset
                            </a>
                            @if (count($laporan) > 0)
                                <a href="{{ route('penjualan-by-wilayah.cetak', request()->query()) }}" target="_blank"
                                    class="btn btn-sm btn-success">
                                    <i class="fa fa-print"></i> Cetak
                                </a>
                            @endif
                        </form>

                        <table class="table table-striped table-condensed" style="margin-top: 1em;">
                            <thead>
                                <tr>
                                    <th width="30">Tanggal</th>
                                    <th colspan="2">Nomor</th>
                                    <th colspan="2">Gudang</th>
                                    <th colspan="2">Salesman</th>
                                    <th colspan="2">Pelanggan</th>
                                    <th colspan="2">Jatuh Tempo</th>
                                    <th colspan="2">Gross</th>
                                    <th colspan="2">Diskon</th>
                                    <th colspan="2">PPN</th>
                                    <th colspan="2">Rate</th>
                                    <th>Netto</th>
                                </tr>
                            </thead>
                            @php
                                $grandtotal = 0;
                            @endphp
                            <tbody>
                                @forelse ($laporan as $item)
                                    @php
                                        $total_qty = 0;
                                        $total = 0;
                                        $total_diskon = 0;
                                        $total_qty_retur = 0;
                                        $total_retur = 0;
                                        $total_nota = 0;
                                    @endphp
                                    <tr>
                                        <th>{{ $loop->iteration }}</th>
                                        <th colspan="2">{{ $item->tanggal->format('d F Y') }}</th>
                                        <th colspan="2">{{ $item->gudang->nama }}</th>
                                        <th colspan="2">{{ $item->salesman && $item->salesman->nama ? $item->salesman->nama : '' }}</th>
                                        <th colspan="2">{{ $item->pelanggan->nama_pelanggan }}</th>
                                        <th colspan="2">{{ $item->due_date!='' ? date('d F Y', strtotime($item->due_date)) : '-' }}</th>
                                        <th colspan="2">{{ number_format($item->total_gross,2) }}</th>
                                        <th colspan="2">{{ number_format($item->total_diskon,2) }}</th>
                                        <th colspan="2">{{ number_format($item->total_ppn,2) }}</th>
                                        <th colspan="2">{{ $item->rate }}</th>
                                        <th>{{ number_format($item->total_netto,2) }}</th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th colspan="4">Barang</th>
                                        <th>Qty</th>
                                        <th colspan="3">Harga</th>
                                        <th>Disc</th>
                                        <th>PPN</th>
                                        <th colspan="5">Netto</th>
                                        <th colspan="2">Retur</th>
                                        <th colspan="2">Netto Default</th>
                                    </tr>
                                    @foreach ($item->penjualan_detail as $index => $detail)
                                        <tr>
                                            <td></td>
                                            <td colspan="4">
                                                {{ $detail->barang->kode . ' - ' . $detail->barang->nama }}
                                            </td>
                                            <td>{{ $detail->qty }}</td>
                                            <td colspan="3">
                                                {{ $item->matauang->kode . ' ' . number_format($detail->harga) }}
                                            </td>
                                            <td>
                                                {{ $item->matauang->kode . ' ' . number_format($detail->diskon) }}
                                            </td>
                                            <td>
                                                {{ $item->matauang->kode . ' ' . number_format($detail->ppn) }}
                                            </td>
                                            <td colspan="5">
                                                {{ $item->matauang->kode . ' ' . number_format($detail->netto) }}
                                            </td>
                                            <td colspan="2">
                                                @php
                                                    $retur = get_sales_retur($item->id, $detail->barang->id);
                                                    $jumlah_retur = isset($retur['jumlah']) ? $retur['jumlah'] : 0;
                                                    $total_retur += $jumlah_retur; 
                                                @endphp
                                                {{ number_format($jumlah_retur) }}
                                            </td>
                                            <td colspan="2">
                                                @php
                                                    $jumlah_nett = $detail->netto-$jumlah_retur;
                                                    $total_nota += $jumlah_nett; 
                                                @endphp
                                                {{ number_format($jumlah_nett) }}                                                
                                            </td>
                                        </tr>

                                        @php
                                            $total_qty += $detail->qty;
                                            $total += $detail->subtotal;
                                            $grandtotal += $detail->subtotal;
                                            $total_diskon += $detail->diskon_persen;
                                        @endphp
                                    @endforeach
                                    <tr>
                                        <th></th>
                                        <th colspan="4">Total</th>
                                        <th>{{ $total_qty }}</th>
                                        <th colspan="3">
                                            {{ $item->matauang->kode . ' ' . number_format($item->total_gross) }}
                                        </th>
                                        <th>
                                            {{ $item->matauang->kode . ' ' . number_format($item->total_diskon) }}
                                        </th>
                                        <th>
                                            {{ $item->matauang->kode . ' ' . number_format($item->total_ppn) }}
                                        </th>
                                        <th colspan="5">
                                            {{ $item->matauang->kode . ' ' . number_format($item->total_netto) }}
                                        </th>
                                        <th colspan="2">{{ $item->matauang->kode . ' ' . number_format($total_retur) }}</th>
                                        <th colspan="2">{{ $item->matauang->kode . ' ' . number_format($total_nota) }}</th>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="20" class="text-center">Data tidak ditemukan</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- end panel -->
            </div>
            <!-- end col-12 -->
        </div>
        <!-- end row -->
    </div>
    <!-- end #content -->
@endsection
