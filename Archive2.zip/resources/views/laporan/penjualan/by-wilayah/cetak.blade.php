@extends('layouts.cetak2')
@section('title', 'Laporan Penjualan Berdasarkan Wilayah')

@section('content')
  <main>
    <h3>{{ $toko->nama }}</h3>
    <center><strong style="text-transform: uppercase;">Laporan Penjualan Berdasarkan Wilayah</strong></center><br/>
    <table style="margin-bottom: 0;">
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Tanggal</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ date('d-M-Y', strtotime($param['dari_tanggal'])) }} - {{ date('d-M-Y', strtotime($param['sampai_tanggal'])) }}</td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Wilayah</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['area'] ? $param['area']->nama : 'Semua Wilayah' }}</td>
      </tr>
    </table>
    <br/>
    <table class="main" cellspacing="0" cellpadding="0" border="1">
        <thead>
            <tr>   
              <th >Nomor</th>
              <th colspan="2">Tanggal</th>
              <th colspan="2">Gudang</th>
              <th colspan="2">Salesman</th>
              <th colspan="2">Pelanggan</th>
              <th colspan="2">Jatuh Tempo</th>
              <th colspan="2">Gross</th>
              <th colspan="2">Diskon</th>
              <th colspan="2">PPN</th>
              <th colspan="2">Rate</th>
              <th>Netto</th>
            </tr>
        </thead>
        @php
            $no = 1;
            $grandtotal = 0;
        @endphp
        <tbody>
            @forelse ($reportData as $item)
                @php
                  $total_qty = 0;
                  $total = 0;
                  $total_diskon = 0;
                  $total_qty_retur = 0;
                  $total_retur = 0;
                  $total_nota = 0;
                @endphp
                <tr>
                    <th>{{ $no++ }}</th>                    
                    <th colspan="2">{{ $item->tanggal->format('d F Y') }}</th>
                    <th colspan="2">{{ $item->gudang->nama }}</th>
                    <th colspan="2">{{ $item->salesman && $item->salesman->nama ? $item->salesman->nama : '' }}</th>
                    <th colspan="2">{{ $item->pelanggan->nama_pelanggan }}</th>
                    <th colspan="2">{{ $item->due_date!='' ? date('d F Y', strtotime($item->due_date)) : '-' }}</th>
                    <th colspan="2">{{ number_format($item->total_gross,2) }}</th>
                    <th colspan="2">{{ number_format($item->total_diskon,2) }}</th>
                    <th colspan="2">{{ number_format($item->total_ppn,2) }}</th>
                    <th colspan="2">{{ $item->rate }}</th>
                    <th>{{ number_format($item->total_penjualan,2) }}</th>
                </tr>
                <tr>
                  <th></th>
                  <th colspan="4">Barang</th>
                  <th colspan="2">Qty</th>
                  <th colspan="2">Harga</th>
                  <th>Disc</th>
                  <th>PPN</th>
                  <th colspan="4">Netto</th>
                  <th colspan="2">Retur</th>
                  <th colspan="3">Netto Default</th>
                </tr>
                @foreach ($item->penjualan_detail as $detail)
                    <tr>
                        <td></td>                        
                        <td  style="text-align: left; background-color: #F5F5F5;" colspan="4">
                            {{ $detail->barang->kode . ' - ' . $detail->barang->nama }}
                        </td>
                        <td  style="text-align: center; background-color: #F5F5F5;" colspan="2">{{ $detail->qty }}</td>
                        <td  style="text-align: right; background-color: #F5F5F5;" colspan="2">
                            {{ $item->matauang->kode . ' ' . number_format($detail->harga) }}
                        </td>
                        <td  style="text-align: right; background-color: #F5F5F5;">
                            {{ $item->matauang->kode . ' ' . number_format($detail->diskon) }}
                        </td>
                        <td  style="text-align: right; background-color: #F5F5F5;">
                            {{ $item->matauang->kode . ' ' . number_format($detail->ppn) }}
                        </td>
                        <td  style="text-align: right; background-color: #F5F5F5;" colspan="4">
                            {{ $item->matauang->kode . ' ' . number_format($detail->netto) }}
                        </td>
                        <td  style="text-align: right; background-color: #F5F5F5;" colspan="2">
                            @php
                                $retur = get_sales_retur($item->id, $detail->barang->id);
                                $jumlah_retur = isset($retur['jumlah']) ? $retur['jumlah'] : 0;
                                $total_retur += $jumlah_retur; 
                            @endphp
                            {{ number_format($jumlah_retur) }}
                        </td>
                        <td  style="text-align: right; background-color: #F5F5F5;" colspan="3">
                            @php
                                $jumlah_nett = $detail->netto-$jumlah_retur;
                                $total_nota += $jumlah_nett; 
                            @endphp
                            {{ number_format($jumlah_nett) }}                                                
                        </td>
                    </tr>
                    @php
                      $total_qty += $detail->qty;
                      $total += $detail->subtotal;
                      $grandtotal += $detail->subtotal;
                      $total_diskon += $detail->diskon_persen;
                    @endphp
                @endforeach
                <tr>
                  <th></th>
                  <th  style="text-align: right;"  colspan="4">Total :</th>
                  <th  style="text-align: center;" colspan="2">{{ $total_qty }}</th>
                  <th  style="text-align: right;"  colspan="2">
                      {{ $item->matauang->kode . ' ' . number_format($item->total_gross) }}
                  </th>
                  <th  style="text-align: right;" >
                      {{ $item->matauang->kode . ' ' . number_format($item->total_diskon) }}
                  </th>
                  <th  style="text-align: right;" >
                      {{ $item->matauang->kode . ' ' . number_format($item->total_ppn) }}
                  </th>
                  <th  style="text-align: right;"  colspan="4">
                      {{ $item->matauang->kode . ' ' . number_format($item->total_netto) }}
                  </th>
                  <th  style="text-align: right;"  colspan="2">{{ $item->matauang->kode . ' ' . number_format($total_retur) }}</th>
                  <th  style="text-align: right;"  colspan="3">{{ $item->matauang->kode . ' ' . number_format($total_nota) }}</th>
                </tr>
                <tr><td colspan="20" style="background-color: white;"></td></tr>
            @empty
                <tr>
                    <td colspan="20" class="text-center">Data tidak ditemukan</td>
                </tr>
            @endforelse
        </tbody>
    </table>
    <div id="printPageButton" style="text-align: center;">
      <button onClick="window.print();" style="margin-top: 100px;">Print</button>
    </div>
  </main>
            
@endsection

@section('headers')
  <style type="text/css">
    @media print {
      #printPageButton {
        display: none;
      }
    }
    body{
      width: 85% !important;
    }

    th{
      font-weight: bolder !important;
    }

    td{
      text-align: left;
    }

    table th, 
    table td {
        padding: 5px;
    }

    .button-7 {
      background-color: #0095ff;
      border: 1px solid transparent;
      border-radius: 3px;
      box-shadow: rgba(255, 255, 255, .4) 0 1px 0 0 inset;
      box-sizing: border-box;
      color: #fff;
      cursor: pointer;
      display: inline-block;
      font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
      font-size: 13px;
      font-weight: 400;
      line-height: 1.15385;
      margin: 0;
      outline: none;
      padding: 8px .8em;
      position: relative;
      text-align: center;
      text-decoration: none;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
      vertical-align: baseline;
      white-space: nowrap;
    }

    .button-7:hover,
    .button-7:focus {
      background-color: #07c;
    }

    .button-7:focus {
      box-shadow: 0 0 0 4px rgba(0, 149, 255, .15);
    }

    .button-7:active {
      background-color: #0064bd;
      box-shadow: none;
    }

  </style>
@endsection