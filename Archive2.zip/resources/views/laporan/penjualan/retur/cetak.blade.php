@extends('layouts.cetak2')
@section('title', 'Laporan Retur Penjualan')

@section('content')
  <main>
    <h3>{{ $toko->nama }}</h3>
    <center><strong style="text-transform: uppercase;">Laporan Retur Penjualan</strong></center><br/>
    <table style="margin-bottom: 0;">
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Tanggal</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ date('d-M-Y', strtotime($param['dari_tanggal'])) }} - {{ date('d-M-Y', strtotime($param['sampai_tanggal'])) }}</td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Gudang</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['gudang'] ? $param['gudang']->nama : 'Semua Gudang' }}</td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Pelanggan</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['pelanggan'] ? $param['pelanggan']->nama_pelanggan : 'Semua Pelanggan' }}</td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Salesman</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['salesman'] ? $param['salesman']->nama : 'Semua Salesman' }}</td>
      </tr>
    </table>
    <br/>
    <table class="main" cellspacing="0" cellpadding="0" border="1">
        <thead>
            <tr>
              <th width="15">No.</th>
              <th colspan="4">Kode</th>
              <th>Kode Penjualan</th>
              <th>Tanggal</th>
              <th colspan="3">Gudang</th>
              <th colspan="3">Pelanggan</th>
              <th colspan="3">Salesman</th>
              <th>Rate</th>
            </tr>
        </thead>
        @php
            $no = 1;
            $grandtotal = 0;
        @endphp
        <tbody>
            @forelse ($reportData as $item)
                @php
                  $total_qty_beli = 0;
                  $total_qty_retur = 0;
                  $total = 0;
                @endphp
                <tr>
                    <th>{{ $no++ }}</th>
                    <th colspan="4">{{ $item->kode }}</th>
                    <th>{{ $item->penjualan->kode }}</th>
                    <th>{{ $item->tanggal->format('d F Y') }}</th>
                    <th colspan="3">{{ $item->gudang->nama }}</th>
                    <th colspan="3">
                        {{ $item->penjualan->pelanggan->nama_pelanggan }}
                    </th>
                    <th colspan="3">
                        {{ $item->penjualan->salesman->nama }}
                    </th>
                    <th>{{ $item->rate }}</th>
                </tr>
                <tr>
                  <th></th>
                    <th colspan="4">Barang</th>
                    <th>Qty Beli</th>
                    <th>Qty Retur</th>
                    <th colspan="2">Harga</th>
                    <th>Disc</th>
                    <th>PPN</th>
                    <th>PPH</th>
                    <th>B.Msk</th>
                    <th colspan="3">Clr.Fee</th>
                    <th >Subtotal</th>
                </tr>
                @foreach ($item->retur_penjualan_detail as $detail)
                    <tr>
                        <td style="text-align: left; background-color: #F5F5F5;" ></td>
                        <td style="text-align: left; background-color: #F5F5F5;" colspan="4">
                            {{ $detail->barang->kode . ' - ' . $detail->barang->nama }}
                        </td>
                        <td style="text-align: center; background-color: #F5F5F5;">{{ $detail->qty_beli }}</td>
                        <td style="text-align: center; background-color: #F5F5F5;">{{ $detail->qty_retur }}</td>
                        <td style="text-align: right; background-color: #F5F5F5;" colspan="2">
                            {{ $item->penjualan->matauang->kode . ' ' . number_format($detail->harga) }}
                        </td>
                        <td style="text-align: right; background-color: #F5F5F5;">
                            {{ $item->penjualan->matauang->kode . ' ' . number_format($detail->diskon) }}
                        </td>
                        <td style="text-align: right; background-color: #F5F5F5;">
                            {{ $item->penjualan->matauang->kode . ' ' . number_format($detail->ppn) }}
                        </td>
                        <td style="text-align: right; background-color: #F5F5F5;">
                            {{ $item->penjualan->matauang->kode . ' ' . number_format($detail->pph) }}
                        </td>
                        <td style="text-align: right; background-color: #F5F5F5;">
                            {{ $item->penjualan->matauang->kode . ' ' . number_format($detail->biaya_masuk) }}
                        </td>
                        <td style="text-align: right; background-color: #F5F5F5;" colspan="3">
                            {{ $item->penjualan->matauang->kode . ' ' . number_format($detail->clr_fee) }}
                        </td>
                        <td style="text-align: right; background-color: #F5F5F5;" >
                            {{ $item->penjualan->matauang->kode . ' ' . number_format($detail->netto) }}
                        </td>
                    </tr>
                    @php
                      $total_qty_beli += $detail->qty_beli;
                      $total_qty_retur += $detail->qty_retur;
                      $total += $detail->subtotal;
                      $grandtotal += $detail->subtotal;
                    @endphp
                @endforeach
                <tr>
                  <th></th>
                  <th  style="text-align: right;" colspan="4">Total :</th>
                  <th  style="text-align: center;">{{ $total_qty_beli }}</th>
                  <th  style="text-align: center;">{{ $total_qty_retur }}</th>
                  <th  style="text-align: right;" colspan="2">
                      {{ $item->penjualan->matauang->kode . ' ' . number_format($item->total_gross) }}
                  </th>
                  <th  style="text-align: right;">
                      {{ $item->penjualan->matauang->kode . ' ' . number_format($item->total_diskon) }}
                  </th>
                  <th  style="text-align: right;">
                      {{ $item->penjualan->matauang->kode . ' ' . number_format($item->total_ppn) }}
                  </th>
                  <th  style="text-align: right;">
                      {{ $item->penjualan->matauang->kode . ' ' . number_format($item->total_pph) }}
                  </th>
                  <th  style="text-align: right;">
                      {{ $item->penjualan->matauang->kode . ' ' . number_format($item->total_biaya_masuk) }}
                  </th>
                  <th  style="text-align: right;" colspan="3">
                      {{ $item->penjualan->matauang->kode . ' ' . number_format($item->total_clr_fee) }}
                  </th>
                  <th  style="text-align: right;" >
                      {{ $item->penjualan->matauang->kode . ' ' . number_format($item->total_netto) }}
                  </th>
                </tr>
                <tr><td colspan="18" style="background-color: white;"></td></tr>
            @empty
                <tr>
                    <td colspan="18" class="text-center">Data tidak ditemukan</td>
                </tr>
            @endforelse
        </tbody>
    </table>
    <div id="printPageButton" style="text-align: center;">
      <button onClick="window.print();" style="margin-top: 100px;">Print</button>
    </div>
  </main>
            
@endsection

@section('headers')
  <style type="text/css">
    @media print {
      #printPageButton {
        display: none;
      }
    }
    body{
      width: 85% !important;
    }

    th{
      font-weight: bolder !important;
    }

    td{
      text-align: left;
    }

    table th, 
    table td {
        padding: 5px;
    }

    .button-7 {
      background-color: #0095ff;
      border: 1px solid transparent;
      border-radius: 3px;
      box-shadow: rgba(255, 255, 255, .4) 0 1px 0 0 inset;
      box-sizing: border-box;
      color: #fff;
      cursor: pointer;
      display: inline-block;
      font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
      font-size: 13px;
      font-weight: 400;
      line-height: 1.15385;
      margin: 0;
      outline: none;
      padding: 8px .8em;
      position: relative;
      text-align: center;
      text-decoration: none;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
      vertical-align: baseline;
      white-space: nowrap;
    }

    .button-7:hover,
    .button-7:focus {
      background-color: #07c;
    }

    .button-7:focus {
      box-shadow: 0 0 0 4px rgba(0, 149, 255, .15);
    }

    .button-7:active {
      background-color: #0064bd;
      box-shadow: none;
    }

  </style>
@endsection