@extends('layouts.dashboard')

@section('title', trans('Laporan Penjualan Berdasarkan Cara Bayar'))

@section('content')
    <!-- begin #content -->
    <div id="content" class="content">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">Laporan</li>
                <li class="breadcrumb-item active">Penjualan Berdasarkan Cara Bayar</li>
            </ol>
        </nav>
        <!-- begin row -->
        <div class="row">
            <!-- begin col-12 -->
            <div class="col-md-12">
                <!-- begin panel -->
                <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                    <div class="panel-heading">
                        <div class="panel-heading-btn">
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default"
                                data-click="panel-expand">
                                <i class="fa fa-expand"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success"
                                data-click="panel-reload"><i class="fa fa-repeat"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning"
                                data-click="panel-collapse">
                                <i class="fa fa-minus"></i>
                            </a>
                            <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger"
                                data-click="panel-remove">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                        <h4 class="panel-title">Laporan Penjualan Berdasarkan Cara Bayar</h4>
                    </div>
                    <div class="panel-body">
                        <table border="0" class="opt-data" style="margin-bottom: 40px; width: 450px;">
                            <tbody>
                              <tr>
                                <td style="min-width: 60px;"><b>Periode Tanggal</b></td>
                                <td style="padding: 5px 0;">
                                    <input type="date" class="form-control" style="width: 45%; display: inline-block;" id="from" value="{{ date('Y-m-01') }}" > - 
                                    <input type="date" class="form-control" style="width: 45%; display: inline-block;" id="to" value="{{ date('Y-m-d') }}" >
                                </td>
                              </tr> 
                              <tr>
                                <td style="min-width: 60px;"><b>Cara Bayar</b></td>
                                <td style="padding: 5px 0;">
                                    <select name="pembayaran" class="form-control" id="pembayaran" style="width: 100%">
                                        <option value="all">All</option>
                                        <option value="Cash">Cash</option>
                                        <option value="Transfer">Transfer</option>
                                        <option value="Giro">Giro</option>
                                    </select>
                                </td>
                              </tr> 
                              <tr>
                                <td colspan="2" style="text-align: right; padding: 10px 0;">
                                   <button type="button" id="print-data" class="btn btn-success btn-flat btn-sm">
                                    <i class="fa fa-print"></i> Cetak</button>
                                  <button type="button" id="show-info-data" class="btn btn-danger btn-flat btn-sm">View Report</button>
                                </td>
                              </tr>
                            </tbody>
                        </table>

                        <div class="table-responsive">
                            <table class="table table-striped table-condensed data-table" id="master-table" style="margin-top: 1em; width: 100%;">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Nomor</th>
                                        <th>Mata Uang</th>
                                        <th>Nilai Jual</th>
                                        <th>Tunai</th>
                                        <th>Transfer</th>
                                        <th>Giro(Cek)</th>
                                        <th>K. Debit</th>
                                        <th>K. Kredit</th>
                                    </tr>
                                </thead>
                                <tbody> </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- end panel -->
            </div>
            <!-- end col-12 -->
        </div>
        <!-- end row -->
    </div>
    <!-- end #content -->
@endsection

@push('custom-css')
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css" />
    <style type="text/css">
        .dataTables_length{
            display: block;
            width: 100%;
        }
    </style>
@endpush

@push('custom-js')
    
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>

    <script type="text/javascript">
      let dataTable, tbData = {};
      $(function () {
        tbData.action   = 'view_report';
        tbData.from     = '{{ date("Y-m-01") }}';
        tbData.to       = '{{ date("Y-m-d") }}';
        tbData.pembayaran = 'all';
        tbData._token   = "{{ csrf_token() }}";

        dataTable = $("#master-table").DataTable({
            "aLengthMenu": [
                [25, 50, 75, 100, -1],
                [25, 50, 75, 100, 'All']
            ],
            "ordering": false,
            "iDisplayLength": 25,
            "fixedHeader": {
                header: true
            },
            dom: 'lBfrtip',
            buttons: [ 'excel', 'pdf', 'print' ],
            "language": {
                "lengthMenu": "_MENU_ data",
            },
            // "processing": true,
            // "serverSide": true,
            "ajax": {
              url: `{{ route('penjualan-by-pembayaran.laporan') }}`,
              type: "POST",
              dataType: "json",
              data:function ( d ) {
                return  $.extend(d, tbData);
              },
            },  
            "columns": [
                { "data": "tanggal" },
                { "data": "nomor" },
                { "data": "matauang" },
                { "data": "nilai" },
                { "data": "tunai" },
                { "data": "transfer" },
                { "data": "giro" },
                { "data": "debit" },
                { "data": "kredit" },
            ],
            "order": [
                [0, "asc"]
            ],
        });

        $("#show-info-data").click(function(){
          tbData.from   = $("#from").val();
          tbData.to     = $("#to").val();
          tbData.pembayaran   = $("#pembayaran").val();

          $("#show-info-data").html("Loading...");
          dataTable.ajax.reload(function(e){
            $("#show-info-data").html("View Report");
          }, false);            
        });

        $("#print-data").click(function(e){
            e.preventDefault();

            let from   = $("#from").val();
            let to     = $("#to").val();
            let pembayaran   = $("#pembayaran").val();
            let url = `{{ route('penjualan-by-pembayaran.cetak') }}?from=${from}&to=${to}&pembayaran=${pembayaran}`;

            window.open(url, '_blank').focus();
        })
        
      });
    </script>
@endpush