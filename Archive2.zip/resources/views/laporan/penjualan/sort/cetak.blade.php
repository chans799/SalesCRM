@extends('layouts.cetak2')
@section('title', 'Laporan Penjualan Urut Berdasarkan '.$param['sort'])

@section('content')
  <main>
    <h3>{{ $toko->nama }}</h3>
    <center><strong style="text-transform: uppercase;">Laporan Penjualan Urut Berdasarkan {{ $param['sort'] }}</strong></center><br/>
    <table style="margin-bottom: 0;">
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 100px; ">Tanggal</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ date('d-M-Y', strtotime($param['dari_tanggal'])) }} - {{ date('d-M-Y', strtotime($param['sampai_tanggal'])) }}</td>
      </tr>
    </table>
    <br/>
    <table class="main" cellspacing="0" cellpadding="0" border="1">
        <thead>
            <tr>
              <th>No.</th>
              <th>Kode Barang</th>
              <th>Nama Barang</th>
              <th>Qty</th>
              <th>Harga Satuan</th>
              <th>Total</th>
            </tr>
        </thead>
        <tbody>
            @php ($no = 1)
            @forelse ($reportData as $item)
              <tr>
                <td style="text-align: center;">{{ $no++ }}</td>                
                <td style="text-align: center;">{{ $item['barang_id'] }}</td>
                <td style="text-align: left;">{{ $item['nama'] }}</td>
                <td style="text-align: center;">{{ $item['qty'] }}</td>
                <td style="text-align: right;">{{ $item['harga'] }}</td>
                <td style="text-align: right;">{{ $item['total'] }}</td>
              </tr>
            @empty
                <tr>
                    <td colspan="6" class="text-center" style="text-align: center;">Data tidak ditemukan</td>
                </tr>
            @endforelse
        </tbody>
    </table>
    <div id="printPageButton" style="text-align: center;">
      <button onClick="window.print();" style="margin-top: 100px;">Print</button>
    </div>
  </main>
            
@endsection

@section('headers')
  <style type="text/css">
    @media print {
      #printPageButton {
        display: none;
      }
    }
    body{
      width: 85% !important;
    }

    table td {
      text-align: left;
    }

    table th{
      font-weight: bolder;
    }

    table th, 
    table td {
        padding: 5px;
    }

    .button-7 {
      background-color: #0095ff;
      border: 1px solid transparent;
      border-radius: 3px;
      box-shadow: rgba(255, 255, 255, .4) 0 1px 0 0 inset;
      box-sizing: border-box;
      color: #fff;
      cursor: pointer;
      display: inline-block;
      font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
      font-size: 13px;
      font-weight: 400;
      line-height: 1.15385;
      margin: 0;
      outline: none;
      padding: 8px .8em;
      position: relative;
      text-align: center;
      text-decoration: none;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
      vertical-align: baseline;
      white-space: nowrap;
    }

    .button-7:hover,
    .button-7:focus {
      background-color: #07c;
    }

    .button-7:focus {
      box-shadow: 0 0 0 4px rgba(0, 149, 255, .15);
    }

    .button-7:active {
      background-color: #0064bd;
      box-shadow: none;
    }

  </style>
@endsection