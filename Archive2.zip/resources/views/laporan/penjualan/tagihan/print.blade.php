@extends('layouts.cetak2')
@section('title', 'Tanda Terima Tagihan')

@section('content')
  <main>
    <h3>{{ $toko->nama }}</h3>
    <table style="width: 100%; margin-bottom: 0;">
      <tr>
        <td align="left" style="text-align: left !important; background-color: white; font-weight: bolder; ">
          TANDA TERIMA TAGIHAN 
        </td>
        <td align="right" style="background-color: white; font-weight: bolder;"> </td>
      </tr>
    </table>
    <table class="main" cellspacing="0" cellpadding="0" border="0">
      <thead>
        <tr>
          <th style="border: 1px solid #000;">No.</th>
          <th style="border: 1px solid #000;">Tanggal Faktur</th>
          <th style="border: 1px solid #000;">Nomor Faktur</th>
          <th style="border: 1px solid #000;">Pelanggan</th>
          <th style="border: 1px solid #000;">Salesman</th>
          <th style="border: 1px solid #000;">Wilayah</th>
          <th style="border: 1px solid #000;">Mata Uang</th>
          <th style="border: 1px solid #000;">Total Faktur</th>
          <th style="border: 1px solid #000;">Umur Piutang</th>
        </tr>
      </thead>
      <tbody>
        @php  
          $no = 1;
        @endphp
        @foreach($reportData as $r)
          <tr>
            <td style="border: 1px solid #000; font-size: 12px; padding: 3px; width: 50px; text-align: center;">{{ $no++ }}</td>
            <td style="border: 1px solid #000; font-size: 12px; padding: 3px;" class="desc" align="center">{{ $r['tanggal'] }}</td>
            <td style="border: 1px solid #000; font-size: 12px; padding: 3px;" class="desc">{{ $r['nomor'] }}</td>
            <td style="border: 1px solid #000; font-size: 12px; padding: 3px; text-align: left;" class="desc">{{ $r['nama_pelanggan'] }}</td>
            <td style="border: 1px solid #000; font-size: 12px; padding: 3px; text-align: left;" class="desc">{{ $r['nama_salesman'] }}</td>
            <td style="border: 1px solid #000; font-size: 12px; padding: 3px; text-align: center;" class="desc">{{ $r['nama_area'] }}</td>
            <td style="border: 1px solid #000; font-size: 12px; padding: 3px; text-align: center;" class="desc">{{ $r['nama_matauang'] }}</td>
            <td style="border: 1px solid #000; font-size: 12px; padding: 3px;" align="right">{{ number_format((float)$r['nilai'],2) }}</td>
            <td style="border: 1px solid #000; font-size: 12px; padding: 3px;" align="right">{{ number_format((float)$r['terbayar'],2) }}</td>
          </tr>
        @endforeach
        <tr>
          <td colspan="6" style="text-align: left">
            <strong>Saldo Terbilang: {{ ucwords($param['label']) }}</strong>
          </td>
          <td class="total" style="font-size: 12.5px; border: 1px solid #000;"><strong>TOTAL:</strong></td>
          <td class="total" style="font-size: 12.5px; border: 1px solid #000;">{{ number_format($param['total'], 2) }}</td>
          <td class="total" style="font-size: 12.5px; border: 1px solid #000;">{{ number_format($param['bayar'], 2) }}</td>
        </tr>
      </tbody>
    </table>
   
    <div id="printPageButton" style="text-align: center;">
      <button onClick="window.print();" style="margin-top: 100px;">Print</button>
    </div>
  </main>
            
@endsection

@section('headers')
  <style type="text/css">
    @media print {
      #printPageButton {
        display: none;
      }
    }
    body{
      width: 85% !important;
    }
    table td {
        padding: 5px;
    }

    .button-7 {
      background-color: #0095ff;
      border: 1px solid transparent;
      border-radius: 3px;
      box-shadow: rgba(255, 255, 255, .4) 0 1px 0 0 inset;
      box-sizing: border-box;
      color: #fff;
      cursor: pointer;
      display: inline-block;
      font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
      font-size: 13px;
      font-weight: 400;
      line-height: 1.15385;
      margin: 0;
      outline: none;
      padding: 8px .8em;
      position: relative;
      text-align: center;
      text-decoration: none;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
      vertical-align: baseline;
      white-space: nowrap;
    }

    .button-7:hover,
    .button-7:focus {
      background-color: #07c;
    }

    .button-7:focus {
      box-shadow: 0 0 0 4px rgba(0, 149, 255, .15);
    }

    .button-7:active {
      background-color: #0064bd;
      box-shadow: none;
    }

  </style>
@endsection