@extends('layouts.cetak2')
@section('title', 'Tanda Terima Tagihan')

@section('content')
  <main>
    <h3>{{ $toko->nama }}</h3>
    <center><strong>TANDA TERIMA TAGIHAN</strong></center>
    <table style="width: 100%; margin-bottom: 0;">
      <tr>
        <td align="left" style="text-align: left !important; background-color: white; ">
          Tanggal: {{ date('d-M-Y', strtotime($param['from'])).' s/d '.date('d-M-Y', strtotime($param['to'])) }}
        </td>
        <td align="right" style="background-color: white; font-weight: bolder;">{{ $param['pelanggan'] ? $param['pelanggan']->nama_pelanggan : 'Semua Pelanggan' }}</td>
      </tr>
    </table>
    <table class="main" cellspacing="0" cellpadding="0" border="1">
      <thead>
        <tr>
          <th>No.</th>
          <th>Tanggal Faktur</th>
          <th>Nomor Faktur</th>
          <th>Total Faktur</th>
        </tr>
      </thead>
      <tbody>
        @php  
          $no = 1;
        @endphp
        @foreach($reportData as $r)
          <tr>
            <td style="font-size: 12px; padding: 3px; text-align: center;">{{ $no++ }}</td>
            <td style="font-size: 12px; padding: 3px;" class="desc" align="center">{{ $r['tanggal'] }}</td>
            <td style="font-size: 12px; padding: 3px;" class="desc">{{ $r['nomor'] }}</td>
            <td style="font-size: 12px; padding: 3px;" align="right">{{ number_format($r['nilai'],2) }}</td>
          </tr>
        @endforeach
        <tr>
          <td class="total" colspan="3"><strong>TOTAL:</strong></td>
          <td class="total">{{ number_format($param['total'], 2) }}</td>
        </tr>
      </tbody>
    </table>
    <br/>
    <strong><i>Saldo Terbilang: {{ ucwords($param['label']) }}</i></strong> <br/> <br/> <br/>
    <div>      
      <table style="width: 100%;">
          <tbody>
              <tr>
                  <td style="border: 0 !important; width: 33%; font-size: 11px; background-color: #fff;">
                      <div style="border: 0 !important; margin-bottom: 50px">
                          <center>Tanda Terima</center>
                      </div>
                  </td>
                  <td style="border: 0 !important; width: 33%; font-size: 11px; background-color: #fff; text-align: left;">                      
                      @php  
                        $bank = DB::table('rekening_bank')
                                    ->select('rekening_bank.*', DB::raw('bank.nama AS nama_bank'))
                                    ->leftJoin('bank', 'bank.id', '=', 'rekening_bank.bank_id')
                                    ->where('rekening_bank.status','Y')->orderBy('rekening_bank.id','ASC')
                                    ->limit(1)->first();
                      @endphp
                      <div style="border: 0 !important; padding: 10px; border: 1px solid #000; font-weight: bolder; text-align: left;">
                          Pembayaran dianggap sah apabila Giro sudah cari atau transfer ke rekening: <br/>
                          A/N : {{ $bank ? $bank->nama_rekening : '-' }} <br/>
                          BANK : {{ $bank ? $bank->nama_bank : '-' }} <br/>
                          NO. REKENING : {{ $bank ? $bank->nomor_rekening : '-' }} <br/>
                      </div>
                  </td>
                  <td style="border: 0 !important; width: 33%; font-size: 11px; background-color: #fff;">
                      <div style="border: 0 !important; margin-bottom: 50px">
                          <center>Hormat kami</center>
                      </div>
                  </td>
              </tr>
              <tr><td style="border: 0 !important; padding: 10px"><hr></td><td style="border: 0 !important; padding: 10px"><hr></td><td style="border: 0 !important; padding: 10px"><hr></td></tr>
          </tbody>
      </table>
    </div>
    <div id="printPageButton" style="text-align: center;">
      <button onClick="window.print();" style="margin-top: 100px;">Print</button>
    </div>
  </main>
            
@endsection

@section('headers')
  <style type="text/css">
    @media print {
      #printPageButton {
        display: none;
      }
    }
    body{
      width: 85% !important;
    }
    table td {
        padding: 5px;
    }

    .button-7 {
      background-color: #0095ff;
      border: 1px solid transparent;
      border-radius: 3px;
      box-shadow: rgba(255, 255, 255, .4) 0 1px 0 0 inset;
      box-sizing: border-box;
      color: #fff;
      cursor: pointer;
      display: inline-block;
      font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
      font-size: 13px;
      font-weight: 400;
      line-height: 1.15385;
      margin: 0;
      outline: none;
      padding: 8px .8em;
      position: relative;
      text-align: center;
      text-decoration: none;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
      vertical-align: baseline;
      white-space: nowrap;
    }

    .button-7:hover,
    .button-7:focus {
      background-color: #07c;
    }

    .button-7:focus {
      box-shadow: 0 0 0 4px rgba(0, 149, 255, .15);
    }

    .button-7:active {
      background-color: #0064bd;
      box-shadow: none;
    }

  </style>
@endsection