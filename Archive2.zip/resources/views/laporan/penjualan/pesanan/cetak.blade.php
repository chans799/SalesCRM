@extends('layouts.cetak2')
@section('title', 'Laporan Pesanan Pembelian')

@section('content')
  <main>
    <h3>{{ $toko->nama }}</h3>
    <center><strong style="text-transform: uppercase;">Laporan Pesanan Pembelian</strong></center><br/>
    <table style="margin-bottom: 0;">
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 150px; ">Tanggal</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ date('d-M-Y', strtotime($param['dari_tanggal'])) }} - {{ date('d-M-Y', strtotime($param['sampai_tanggal'])) }}</td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 150px; ">Pelanggan</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['pelanggan'] ? $param['pelanggan']->nama_pelanggan : 'Semua Pelanggan' }}</td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 150px; ">Status</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['status'] && $param['status']!='all' ? $param['status'] : 'Semua Status' }}</td>
      </tr>
      <tr>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; width: 150px; ">Bentuk Kepemilikan</td>
        <td align="left" style="text-align: left !important; padding: 2px; background-color: white; ">: {{ $param['bentuk'] && $param['bentuk']!='all' ? $param['bentuk'] : 'Semua Bentuk Kepemilikan' }}</td>
      </tr>
    </table>
    <br/>
    <table class="main" cellspacing="0" cellpadding="0" border="1">
        <thead>
            <tr>
              <th width="30">No.</th>
              <th colspan="3">Kode</th>
              <th colspan="3">Tanggal</th>
              <th colspan="2">Pelanggan</th>
              <th>Rate</th>
              <th>Status</th>
            </tr>
        </thead>
        @php
            $no = 1;
            $grandtotal = 0;
        @endphp
        <tbody>
            @forelse ($reportData as $item)
                @php
                  $total_qty = 0;
                  $total = 0;
                @endphp
                <tr>
                  <th>{{ $no++ }}</th>
                  <th colspan="3">{{ $item->kode }}</th>
                  <th colspan="3">{{ $item->tanggal->format('d F Y') }}</th>
                  <th colspan="2">
                      {{ $item->pelanggan ? $item->pelanggan->nama_pelanggan : 'Tanpa pelanggan' }}
                  </th>
                  <th>{{ $item->rate }}</th>
                  <th>{{ $item->status }}</th>
                </tr>
                <tr>
                  <th></th>
                  <th colspan="3">Barang</th>
                  <th>Qty</th>
                  <th>Harga</th>
                  <th>Disc</th>
                  <th>PPN</th>
                  <th>B.Msk</th>
                  <th>Clr.Fee</th>
                  <th>Subtotal</th>
                </tr>
                @foreach ($item->pesanan_penjualan_detail as $detail)
                    <tr>
                        <td  style="text-align: right; background-color: #F5F5F5;" ></td>
                        <td  style="text-align: left; background-color: #F5F5F5;"  colspan="3">
                            {{ $detail->barang->kode . ' - ' . $detail->barang->nama }}
                        </td>
                        <td  style="text-align: center; background-color: #F5F5F5;" >{{ $detail->qty }}</td>
                        <td  style="text-align: right; background-color: #F5F5F5;" >
                            {{ $item->matauang->kode . ' ' . number_format($detail->harga, 2, '.', ',') }}
                        </td>
                        <td  style="text-align: right; background-color: #F5F5F5;" >
                            {{ $item->matauang->kode . ' ' . number_format($detail->diskon, 2, '.', ',') }}
                        </td>
                        <td  style="text-align: right; background-color: #F5F5F5;" >
                            {{ $item->matauang->kode . ' ' . number_format($detail->ppn, 2, '.', ',') }}
                        </td>
                        <td  style="text-align: right; background-color: #F5F5F5;" >
                            {{ $item->matauang->kode . ' ' . number_format($detail->biaya_masuk, 2, '.', ',') }}
                        </td>
                        <td  style="text-align: right; background-color: #F5F5F5;" >
                            {{ $item->matauang->kode . ' ' . number_format($detail->clr_fee, 2, '.', ',') }}
                        </td>
                        <td  style="text-align: right; background-color: #F5F5F5;" >
                            {{ $item->matauang->kode . ' ' . number_format($detail->netto, 2, '.', ',') }}
                        </td>
                    </tr>
                    @php
                      $total_qty += $detail->qty;
                      $total += $detail->subtotal;
                      $grandtotal += $detail->subtotal;
                    @endphp
                @endforeach
                <tr>
                  <th style="text-align: left;" ></th>
                  <th style="text-align: right;" colspan="3">Total :</th>
                  <th  style="text-align: center;" >{{ $total_qty }}</th>
                  <th  style="text-align: right;" >
                      {{ $item->matauang->kode . ' ' . number_format($item->total_gross, 2, '.', ',') }}
                  </th>
                  <th  style="text-align: right;" >
                      {{ $item->matauang->kode . ' ' . number_format($item->total_diskon, 2, '.', ',') }}
                  </th>
                  <th  style="text-align: right;" >
                      {{ $item->matauang->kode . ' ' . number_format($item->total_ppn, 2, '.', ',') }}
                  </th>
                  <th  style="text-align: right;" >
                      {{ $item->matauang->kode . ' ' . number_format($item->total_biaya_masuk, 2, '.', ',') }}
                  </th>
                  <th  style="text-align: right;" >
                      {{ $item->matauang->kode . ' ' . number_format($item->total_clr_fee, 2, '.', ',') }}
                  </th>
                  <th  style="text-align: right;" >
                      {{ $item->matauang->kode . ' ' . number_format($item->total_netto, 2, '.', ',') }}
                  </th>
                </tr>
                <tr><td colspan="12" style="background-color: white;"></td></tr>
            @empty
                <tr>
                    <td colspan="12" class="text-center">Data tidak ditemukan</td>
                </tr>
            @endforelse
        </tbody>
    </table>
    <div id="printPageButton" style="text-align: center;">
      <button onClick="window.print();" style="margin-top: 100px;">Print</button>
    </div>
  </main>
            
@endsection

@section('headers')
  <style type="text/css">
    @media print {
      #printPageButton {
        display: none;
      }
    }
    body{
      width: 85% !important;
    }

    th{
      font-weight: bolder !important;
    }

    td{
      text-align: left;
    }

    table th, 
    table td {
        padding: 5px;
    }

    .button-7 {
      background-color: #0095ff;
      border: 1px solid transparent;
      border-radius: 3px;
      box-shadow: rgba(255, 255, 255, .4) 0 1px 0 0 inset;
      box-sizing: border-box;
      color: #fff;
      cursor: pointer;
      display: inline-block;
      font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
      font-size: 13px;
      font-weight: 400;
      line-height: 1.15385;
      margin: 0;
      outline: none;
      padding: 8px .8em;
      position: relative;
      text-align: center;
      text-decoration: none;
      user-select: none;
      -webkit-user-select: none;
      touch-action: manipulation;
      vertical-align: baseline;
      white-space: nowrap;
    }

    .button-7:hover,
    .button-7:focus {
      background-color: #07c;
    }

    .button-7:focus {
      box-shadow: 0 0 0 4px rgba(0, 149, 255, .15);
    }

    .button-7:active {
      background-color: #0064bd;
      box-shadow: none;
    }

  </style>
@endsection