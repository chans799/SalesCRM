<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>@yield('title') - {{ config('app.name') }}</title>
    <link href="{{ asset('vendor/print2.css') }}" rel="stylesheet" />
    @yield('headers')
    <style type="text/css">
    	#project{ width: 50%; }
    	#project div{
    		white-space: normal !important;
    	}

      h1{
        color: #000 !important;
        font-weight: bolder !important;
      }

      td, th{
        color: #000 !important;
        font-weight: 500 !important;
        font-size: 12.7px;
      }

      table.main th,
      table.main td{
        font-size: 12.5px !important;
        font-weight: bolder !important;
        border: 2px solid #000;
      }

      
    </style>
  </head>
  <body style="width: 99% !important;">
  	@yield('content')
  </body>
</html>