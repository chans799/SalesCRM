	<!-- ================== BEGIN BASE CSS STYLE ================== -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
	<link href="{{ asset('vendor/assets/plugins/jquery-ui/themes/base/minified/jquery-ui.min.css') }}" rel="stylesheet" />
	<link href="{{ asset('vendor/assets/plugins/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet" />
	<link href="{{ asset('vendor/assets/plugins/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" />
	<link href="{{ asset('vendor/assets/css/animate.min.css') }}" rel="stylesheet" />
	<link href="{{ asset('vendor/assets/css/style.min.css') }}" rel="stylesheet" />
	<link href="{{ asset('vendor/assets/css/style-responsive.min.css') }}" rel="stylesheet" />
	<link href="{{ asset('vendor/assets/css/theme/default.css') }}" rel="stylesheet" id="theme" />
	<link href="{{ asset('vendor/assets/css/select2.min.css') }}" rel="stylesheet" />
	<link href="{{ asset('vendor/assets/css/select2-bootstrap4.min.css') }}" rel="stylesheet" />
	<!-- ================== END BASE CSS STYLE ================== -->
    <!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
	<link href="{{ asset('vendor/assets/plugins/jquery-jvectormap/jquery-jvectormap.css') }}" rel="stylesheet" />
	<link href="{{ asset('vendor/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.css') }}" rel="stylesheet" />
    <link href="{{ asset('vendor/assets/plugins/DataTables/media/css/dataTables.bootstrap.min.css') }}" rel="stylesheet" />
	<link href="{{ asset('vendor/assets/plugins/DataTables/extensions/Responsive/css/responsive.bootstrap.min.css') }}" rel="stylesheet" />
	<!-- ================== END PAGE LEVEL STYLE ================== -->
    <!-- ================== BEGIN BASE JS ================== -->
	<script src="{{ asset('vendor/assets/plugins/pace/pace.min.js') }}"></script>
	<!-- ================== END BASE JS ================== -->

