<div id="sidebar" class="sidebar">
    <div data-scrollbar="true" data-height="100%">
        <ul class="nav">
            <li class="nav-profile">
                <div class="image">
                    <a href="javascript:;">
                        @if (auth()->user()->foto != null)
                            <img src="{{ asset('storage/img/foto/Avatar.jpg') }}{{--' . auth()->user()->foto) --}}" alt="Avatar"
                                class="img-fluid rounded" style="width: 40px; height: 40px; object-fit: cover;">
                        @else
                            <img src="https://www.gravatar.com/avatar/{{ md5(strtolower(trim(auth()->user()->email))) }}&s=40"
                                alt="Avatar" class="img-fluid rounded"
                                style="width: 40px; height: 40px; object-fit: cover;">
                        @endif
                    </a>
                </div>
                <div class="info">
                    {{ Auth::user()->name }}
                    <small>{{ Auth::user()->email }}</small>
                </div>
            </li>
        </ul>
        <ul class="nav">
            <li class="nav-header">Navigation</li>
            {{-- menu dashboard --}}
            @hasanyrole('admin|user')
                <li class="{{ set_active('dashboard.index') }}">
                    <a href="{{ route('dashboard.index') }}">
                        <i class="fa fa-laptop"></i>
                        <span>{{ trans('dashboard.link.dashboard') }}</span>
                    </a>
                </li>

                {{-- menu master data --}}
                <li class="has-sub {{ request()->is('masterdata*') ? ' active expand' : '' }}">
                    <a href="javascript:;">
                        <b class="caret pull-right"></b>
                        <i class="fa fa-list"></i>
                        <span>{{ trans('dashboard.menu.master') }}</span>
                    </a>
                    <ul class="sub-menu" style="display: {{ request()->is('masterdata*') ? 'block' : 'none' }};">
                        <li class="{{ set_active('matauang*') }}">
                            <a href="{{ route('matauang.index') }}">
                                {{ trans('dashboard.menu.matauang') }}
                            </a>
                        </li>
                        <li class="{{ set_active('rate-matauang*') }}">
                            <a href="{{ route('rate-matauang.index') }}">
                                {{ trans('dashboard.menu.rate_matauang') }}
                            </a>
                        </li>

                        <li class="{{ set_active('bank*') }}">
                            <a href="{{ route('bank.index') }}">
                                {{ trans('dashboard.menu.bank') }}
                            </a>
                        </li>

                        <li class="{{ set_active('rekening-bank*') }}">
                            <a href="{{ route('rekening-bank.index') }}">
                                {{ trans('dashboard.menu.rekening_bank') }}
                            </a>
                        </li>

                        <li class="{{ set_active('area*') }}">
                            <a href="{{ route('area.index') }}">
                                {{ trans('dashboard.menu.area') }}
                            </a>
                        </li>

                        <li class="{{ set_active('satuan-barang*') }}">
                            <a
                                href="{{ route('satuan-barang.index') }}">{{ trans('dashboard.menu.satuan_barang') }}</a>
                        </li>

                        <li class="{{ set_active('pelanggan*') }}">
                            <a href="{{ route('pelanggan.index') }}">
                                {{ trans('dashboard.menu.pelanggan') }}
                            </a>
                        </li>

                        <li class="{{ set_active('salesman*') }}">
                            <a href="{{ route('salesman.index') }}">
                                {{ trans('dashboard.menu.salesman') }}
                            </a>
                        </li>

                        <li class="{{ set_active('gudang*') }}">
                            <a href="{{ route('gudang.index') }}">
                                {{ trans('dashboard.menu.gudang') }}
                            </a>
                        </li>

                        <li class="{{ set_active('kategori*') }}">
                            <a href="{{ route('kategori.index') }}">
                                {{ trans('dashboard.menu.kategori') }}
                            </a>
                        </li>

                        <li class="{{ set_active('barang*') }}">
                            <a href="{{ route('barang.index') }}">
                                {{ trans('dashboard.menu.barang') }}
                            </a>
                        </li>
                    </ul>
                </li>

               
                {{-- menu penjualan --}}
                <li class="has-sub {{ request()->is('jual*') ? ' active expand' : '' }}">
                    <a href="javascript:;">
                        <b class="caret pull-right"></b>
                        <i class="fa fa-shopping-cart"></i>
                        <span>{{ trans('dashboard.menu.penjualan') }}</span>
                    </a>
                    <ul class="sub-menu" style="display: {{ request()->is('jual*') ? 'block' : 'none' }};">
                        <li class="{{ set_active('pesanan-penjualan*') }}">
                            <a href="{{ route('pesanan-penjualan.index') }}">
                                {{ trans('dashboard.menu.pesanan_penjualan') }}
                            </a>
                        </li>

                        <li class="{{ request()->is('jual/penjualan*') ? ' active' : '' }}">
                            <a href="{{ route('penjualan.index') }}">
                                {{ trans('dashboard.menu.penjualan') }}
                            </a>
                        </li>

                        <li class="{{ set_active('retur-penjualan*') }}">
                            <a href="{{ route('retur-penjualan.index') }}">
                                {{ trans('dashboard.menu.retur_penjualan') }}
                            </a>
                        </li>
                    </ul>
                </li>

                
                {{-- menu Laporan --}}
                <li class="has-sub {{ request()->is('laporan*') ? ' active expand' : '' }}">
                    <a href="javascript:;">
                        <b class="caret pull-right"></b>
                        <i class="fa fa-book"></i>
                        <span>{{ trans('dashboard.menu.laporan') }}</span>
                    </a>
                    <ul class="sub-menu" style="display: {{ request()->is('laporan*') ? 'block' : 'none' }};">
                        <li class="has-sub {{ request()->is('laporan/persediaan/*') ? ' active expand' : '' }}">
                            <a href="javascript:;">
                                <b class="caret pull-right"></b>
                                Persediaan
                            </a>
                            <ul class="sub-menu" style="display: {{ request()->is('laporan/persediaan/*') ? 'block' : 'none' }};">
                                <li class="{{ set_active('stok-barang*') }}">
                                    <a href="{{ route('stok-barang.laporan') }}">
                                        Saldo Stok
                                    </a>
                                </li>
                                <li class="{{ set_active('stock.laporan') }}">
                                    <a href="{{ route('stock.laporan') }}">
                                        Kartu Stok
                                    </a>
                                </li>                        
                
                                <li class="{{ set_active('stok-opname.laporan') }}">
                                    <a href="{{ route('stok-opname.laporan') }}">
                                        Stock Opname
                                    </a>
                                </li>    
                            </ul>
                        </li>

                        <li class="has-sub {{ request()->is('laporan/penjualan/*') ? ' active expand' : '' }}">
                            <a href="javascript:;">
                                <b class="caret pull-right"></b>
                                Penjualan
                            </a>
                            <ul class="sub-menu"  style="display: {{ request()->is('laporan/penjualan/*') ? 'block' : 'none' }};">
                                <li class="{{ set_active('penjualan.laporan') }}">
                                    <a href="{{ route('penjualan.laporan') }}">
                                        History Penjualan
                                    </a>
                                </li>
                                <li class="{{ set_active('penjualan-per-barang*') }}">
                                    <a href="{{ route('penjualan-per-barang.laporan') }}">
                                        Penjualan Per Barang
                                    </a>
                                </li>          
                                <li class="{{ set_active('penjualan-by-sales*') }}">
                                    <a href="{{ route('penjualan-by-sales.laporan') }}">
                                        Penjualan Per Sales
                                    </a>
                                </li>
                                <li class="{{ set_active('penjualan-by-wilayah*') }}">
                                    <a href="{{ route('penjualan-by-wilayah.laporan') }}">
                                        Penjualan Per Wilayah
                                    </a>

                                <li class="{{ set_active('penjualan-sort*') }}">
                                    <a href="{{ route('penjualan-sort.laporan') }}">
                                        Penjualan Sort By Qty & Value
                                    </a>
                                </li>
                                <li class="{{ set_active('pesanan-penjualan.laporan') }}">
                                    <a href="{{ route('pesanan-penjualan.laporan') }}">
                                        History Sales Order
                                    </a>
                                </li>
                                <li class="{{ set_active('retur-penjualan.laporan') }}">
                                    <a href="{{ route('retur-penjualan.laporan') }}">
                                         History Retur Penjualan
                                    </a>
                                </li>    
                        </li>

                                <li class="{{ set_active('saldo-piutang.laporan') }}">
                                    <a href="{{ route('saldo-piutang.laporan') }}">
                                        Saldo Piutang
                                    </a>
                                </li>
                                <li class="{{ set_active('pelunasan-piutang.laporan') }}">
                                    <a href="{{ route('pelunasan-piutang.laporan') }}">
                                        History Pelunasan Piutang
                                    </a>
                                </li>
                                <li class="{{ set_active('piutang-jatuh-tempo.laporan') }}">
                                    <a href="{{ route('piutang-jatuh-tempo.laporan') }}">
                                        Saldo Piutang Jatuh Tempo
                                    </a>
                                </li>
                                 
                        <li class="has-sub {{ request()->is('laporan/internal/*') ? ' active expand' : '' }}">
                            <a href="javascript:;">
                                <b class="caret pull-right"></b>
                                Internal
                            </a>
                            <ul class="sub-menu"  style="display: {{ request()->is('laporan/internal/*') ? 'block' : 'none' }};">
                                <li class="{{ set_active('komisi-salesman*') }}">
                                    <a href="{{ route('komisi-salesman.laporan') }}">
                                       Komisi Sales
                                    </a>
                                </li>                 
                            </ul>
                        </li>
                    </ul>
                </li>

                {{-- menu Setting --}}
                <li class="has-sub {{ request()->is('setting*') ? ' active expand' : '' }}">
                    <a href="javascript:;">
                        <b class="caret pull-right"></b>
                        <i class="fa fa-gear"></i>
                        <span>{{ trans('dashboard.menu.setting') }}</span>
                    </a>
                    <ul class="sub-menu" style="display: {{ request()->is('setting*') ? 'block' : 'none' }};">
                        <li class="{{ set_active('toko*') }}">
                            <a href="{{ route('toko.index') }}">
                                {{ trans('dashboard.menu.toko') }}
                            </a>
                        </li>

                        <li class="{{ set_active('user*') }}">
                            <a href="{{ route('user.index') }}">
                                {{ trans('dashboard.menu.user') }}
                            </a>
                        </li>
                    </ul>
                </li>
            @endhasanyrole

            @role('salesman')
                <li class="has-sub  {{ request()->is('jual*') || request()->is('laporan*') ? ' active expand' : '' }}">
                    <a href="javascript:;">
                        <b class="caret pull-right"></b>
                        <i class="fa fa-cart-plus"></i>
                        <span> {{ trans('dashboard.menu.penjualan') }}</span>
                    </a>
                    <ul class="sub-menu" style="display: {{ request()->is('jual*') || request()->is('laporan*') ? 'block' : 'none' }};">
                        <li class="{{ set_active('direct-penjuala*') }}">
                            <a href="{{ route('direct-penjualan.create') }}">
                                {{ trans('dashboard.menu.direct_sales') }}
                            </a>
                        </li>

                        <li class="{{ set_active('komisi-salesman.laporan*') }}">
                            <a href="{{ route('komisi-salesman.laporan') }}">
                                {{ trans('dashboard.laporan.komisi_salesman') }}
                            </a>
                        </li>

                        <li class="{{ set_active('penjualan.laporan*') }}">
                            <a href="{{ route('penjualan.laporan') }}">
                                {{ trans('dashboard.laporan.penjualan') }}
                            </a>
                        </li>

                    </ul>
                </li>
            @endhasanyrole

            {{-- menu Akun --}}
            <li class="has-sub {{ request()->is('akun*') ? ' active expand' : '' }}">
                <a href="javascript:;">
                    <b class="caret pull-right"></b>
                    <i class="fa fa-user"></i>
                    <span>{{ trans('dashboard.menu.akun') }}</span>
                </a>
                <ul class="sub-menu" style="display: {{ request()->is('akun*') ? 'block' : 'none' }};">
                    <li class="{{ set_active('profile*') }}">
                        <a href="{{ route('profile.index') }}">
                            {{ trans('dashboard.menu.profile') }}
                        </a>
                    </li>

                    <li>
                        <a class="dropdown-item" href="{{ route('logout') }}"
                            onclick="event.preventDefault();document.getElementById('logout-form-sidebar').submit();">
                            Logout
                        </a>

                        <form id="logout-form-sidebar" action="{{ route('logout') }}" method="POST"
                            class="d-none">
                            @csrf
                        </form>
                    </li>
                </ul>
            </li>


            @hasanyrole('admin|user')
                
                <li class="{{ set_active('history') }}">
                    <a href="{{ route('history') }}">
                        <i class="fa fa-history"></i>
                        <span>History</span>
                    </a>
                </li>
                @if(session('ubah_status'))
                    <li class="" style="background-color: #d9534f !important;">
                        <a href="javascript:ubah_status();" style="color: #FFFFFF !important;">
                            <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                            <span>Ubah Status</span>
                        </a>
                    </li>
                @endif
            @endhasanyrole

            <li>
                <a href="javascript:;" class="sidebar-minify-btn" data-click="sidebar-minify">
                    <i class="fa fa-angle-double-left"></i>
                </a>
            </li>
        </ul>
    </div>
</div>
<div class="sidebar-bg"></div>

@push('custom-js')
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.1.9/dist/sweetalert2.all.min.js"
        integrity="sha256-EQtsX9S1OVXguoTG+N488HS0oZ1+s80IbOEbE3wzJig=" crossorigin="anonymous"></script>
    <script>
        function ubah_status(){
            Swal.fire({
                icon: 'warning',
                title: 'Perhatian!',
                text: 'Apakah kamu yakin untuk mengubah semua status transaksi yang belum terselesaikan dalam 7 hari terakhir ',
                showCancelButton: true,
                confirmButtonText: 'Ya',
                cancelButtonText: 'Tidak',
            }).then((result =>{
                if (result.isConfirmed) {
                    $.ajax({
                        url: "{{ url('/jual/penjualan/update-status') }}",
                        type: 'PUT',
                        headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(data) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil',
                                text: 'Proses pengubahan status berhasil dilakukan'
                            }).then((hasil) => {
                                if (hasil.isConfirmed) {
                                    location.reload();
                                }
                            })
                        },
                        error: function(xhr, status, error) {
                            // console.error(xhr.responseText)

                            Swal.fire({
                                icon: 'error',
                                title: 'Oops...',
                                text: 'Something went wrong!'
                            })
                        }
                    })
                }
            }))
        }
    </script>
@endpush