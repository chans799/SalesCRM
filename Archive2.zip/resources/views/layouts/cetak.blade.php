<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8"/>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">

      <title>@yield('title') - {{ config('app.name') }}</title>
      @yield('headers')
   </head>
   <body>
      <div id="invoice-table" class="container-fluid invoice-container" >
        <link href="https://fonts.googleapis.com/css?family=Ubuntu:300,500" rel="stylesheet">
        <link href="{{ asset('vendor/print.css') }}" rel="stylesheet" />

        <div id="main-content">
          <style type="text/css">
            strong {
              color: #333;
            }

            hr {
              border-top: 1px solid #ddd;
            }

            .payment-btn-container img {
              width: 300px;
            }

            .invoice-container td.total-row {
              background-color: #fff;
            }

            .payment-btn-container {
              border: 1px solid #eee;
              padding: 20px 10px;
              margin-top: 0 !important;
            }

            .margin-footer {
              margin: 20px 0 50px 0;
            }

            .invoice-button input[type="submit"] {
              padding: 7px 15px;
              background-color: #0fb0f8;
              border: 1px solid #0fb0f8;
              color: #fff;
              -webkit-transition: all 0.2s ease-in-out;
              -moz-transition: all 0.2s ease-in-out;
              -o-transition: all 0.2s ease-in-out;
              transition: all 0.2s ease-in-out;
            }

            .invoice-button input[type="submit"]:hover {
              background-color: #3bb878;
              border: 1px solid #3bb878;
            }

            .table > tbody > tr > td,
            .table > tbody > tr > th,
            .table > tfoot > tr > td,
            .table > tfoot > tr > th,
            .table > thead > tr > td,
            .table > thead > tr > th {
              border-top: 1px solid #ddd;
            }

            .panel-default > .panel-heading {
              border-color: #ddd;
            }

            .panel-default {
              border-color: #ddd;
            }

            .payment-btn-container {
              border: 1px solid #ddd;
              margin-top: -11px !important;
            }

            .mainPayment {
              background: url(/assets/img/xpayment.png.pagespeed.ic.QqweTTJI0X.webp)
                no-repeat top left;
              background-size: 80%;
              width: 100px;
              height: 30px;
              -moz-transition: all 0.3s;
              -webkit-transition: all 0.3s;
              transition: all 0.3s;
              margin-bottom: 15px !important;
              opacity: 0.6;
            }

            .mainPayment:hover {
              opacity: 1;
            }

            .vaPayment {
              background: url(/assets/img/xva.png.pagespeed.ic.p3VqDPOASb.webp) no-repeat
                top left;
              background-size: 75%;
            }

            .alfaPayment {
              background: url(/assets/img/xalfamart-logo.png.pagespeed.ic.TkiCVwJ9ha.webp)
                no-repeat top left;
              background-size: 75%;
            }

            .indoPayment {
              background: url(/assets/img/xindomaret-logo.png.pagespeed.ic.ag2gsLWnKh.webp)
                no-repeat top left;
              background-size: 75%;
            }

            .storePayment {
              background: url(/assets/img/xstore-logo.png.pagespeed.ic.CcJ7evWHwB.webp)
                no-repeat top left;
              background-size: 75%;
            }

            .qrisPayment {
              background: url(/assets/img/xicon-qris.png.pagespeed.ic.o76iEmz4Xh.webp)
                no-repeat top left;
              background-size: 55%;
              margin-left: 20px;
              margin-top: 1px;
            }

            #midtrans {
              margin-left: -20px !important;
              margin-top: -2px !important;
            }

            #select-gateway {
              margin-bottom: 185px;
            }

            #select-gateway > .col-xs-4 {
              padding: 0 !important;
              text-align: left;
            }

            #select-gateway > .col-xs-4 input {
              margin-top: 4px;
              cursor: pointer;
            }

            #gateway-loading img {
              width: 30px !important;
            }

            .gateway-checked {
              -webkit-filter: grayscale(0%);
              -moz-filter: grayscale(0%);
              filter: grayscale(0%);
              opacity: 1;
            }

            .modal-iframe {
              background: rgba(0, 0, 0, 0.75) !important;
            }

            #gopayQR {
              width: 100%;
              max-width: 200px;
            }

            #bankbca-label {
              background-position: 90% 2px;
            }

            #bankmandiri_2-label {
              background-position: 90% -30px;
            }

            #bankbni-label {
              background-position: 90% -60px;
            }

            #paypal-label {
              background-position: 90% -90px;
            }

            #nicepaygateway-label {
              background-position: 90% -118px;
            }

            #nicepaygatewayva-label {
              background-position: 80% 0;
            }

            #nicepaygatewaycvs-label {
              background-position: 60% 5px;
              width: 140px;
            }

            .popover {
              min-width: 200px;
            }
          </style>
          @yield('content')
        </div>
      </div>

      <div class="text-center hidden-print margin-footer">
         <button type="button" onclick='printPage();' class="btn btn-default"><i class="fa fa-print"></i> Print</button>
      </div>
      <script type="text/javascript">
        function printPage() {

        }
      </script>
   </body>
</html>