<!-- ================== BEGIN BASE CSS STYLE ================== -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<link href="{{ asset('vendor/assets/plugins/jquery-ui/themes/base/minified/jquery-ui.min.css') }}" rel="stylesheet" />
<link href="{{ asset('vendor/assets/plugins/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet" />
<link href="{{ asset('vendor/assets/plugins/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" />
<link href="{{ asset('vendor/assets/css/animate.min.css') }}" rel="stylesheet" />
<link href="{{ asset('vendor/assets/css/style.min.css') }}" rel="stylesheet" />
<link href="{{ asset('vendor/assets/css/style-responsive.min.css') }}" rel="stylesheet" />
<link href="{{ asset('vendor/assets/css/theme/default.css') }}" rel="stylesheet" id="theme" />
<!-- ================== END BASE CSS STYLE ================== -->
<!-- ================== BEGIN BASE JS ================== -->
<script src="{{ asset('vendor/assets/plugins/pace/pace.min.js') }}"></script>
