<ul class="login-bg-list clearfix">
    <li class="active"><a href="#" data-click="change-bg"><img src="{{ asset('vendor/assets/img/login-bg/bg-1.jpg') }}" alt="" /></a></li>
    <li><a href="#" data-click="change-bg"><img src="{{ asset('vendor/assets/img/login-bg/bg-2.jpg') }}" alt="" /></a></li>
    <li><a href="#" data-click="change-bg"><img src="{{ asset('vendor/assets/img/login-bg/bg-3.jpg') }}" alt="" /></a></li>
    <li><a href="#" data-click="change-bg"><img src="{{ asset('vendor/assets/img/login-bg/bg-4.jpg') }}" alt="" /></a></li>
    <li><a href="#" data-click="change-bg"><img src="{{ asset('vendor/assets/img/login-bg/bg-5.jpg') }}" alt="" /></a></li>
    <li><a href="#" data-click="change-bg"><img src="{{ asset('vendor/assets/img/login-bg/bg-6.jpg') }}" alt="" /></a></li>
</ul>
