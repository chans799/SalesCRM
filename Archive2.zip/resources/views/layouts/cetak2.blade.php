<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>@yield('title') - {{ config('app.name') }}</title>
    <link href="{{ asset('vendor/print2.css') }}" rel="stylesheet" />
    @yield('headers')
    <style type="text/css">
    	#project{ width: 50%; }
    	#project div{
    		white-space: normal !important;
    	}

      h1{
        color: #000 !important;
        font-weight: bolder !important;
      }

      table.main td, 
      table.main th{
        border: 2px solid #000 !important;
        color: #000 !important;
        font-weight: 500 !important;
      }

      @media print {
        table.main {
          width: 100%;
          height: 90vh;
          table-layout: fixed;
        }   
        table.main th, table.main td {
          /*overflow-wrap: break-word;*/
          /*white-space:pre-wrap; */
          /*word-wrap:break-word;*/
        }     
      }

    </style>
  </head>
  <body style="width: 99% !important;">
  	@yield('content')
  </body>
</html>