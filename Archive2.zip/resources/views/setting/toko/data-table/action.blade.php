@can('toko')
    <td>
        <a href="{{ route('toko.edit', $model->id) }}" class="btn btn-success btn-icon btn-circle">
            <i class="fa fa-edit"></i>
        </a>
    </td>
@endcan
