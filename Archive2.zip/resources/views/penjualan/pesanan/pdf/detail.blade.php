<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nota Pesanan Penjualan</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            font-size: 11.5px;
            border-left: 0;
            margin-bottom: 1em;
        }

        table.aaa td,
        table th,
        table tfoot {
            border: 1px solid black;
            padding: 3px;
            border-left: 0px solid;
            border-right: 0px solid;
        }

        /* table tr:nth-child(even) {
            background-color: #F2F2F2;
        } */

        table th,
        table tfoot {
            padding-top: 8px;
            padding-bottom: 8px;
            text-align: left;
            /* background-color: #158CBA; */
            color: black;
        }

        p,
        h4 {
            line-height: 8px;
        }

        small {
            font-size: 11.5px;
        }

        .garis {
            height: 3px;
            border-top: 3px solid black;
            border-bottom: 1px solid black;
        }
        .table-garis {
            /* border: 1px solid black; */
            padding: 3px;
            border-left: 0px solid;
            border-right: 0px solid;
        }

        @page {
          margin-left: 10px !important;
          margin-right: 20px !important;
        }

    </style>
</head>

<body>
    <div style="margin-top:-55px;padding-top:0px;padding:20px">
        <div>
            <table style="width: 100%">
                <tbody>
                    <tr>
                        <td style="width: 40%">
                            <table style="width: 100%">
                                <tbody style="vertical-align: bottom">
                                    <tr>
                                        <td colspan="2" style="padding: 1px; background-color: white;">
                                            <h2 style="font-size: 32px; font-weight: bold;padding: 0; margin: 0;">
                                                {{ $toko[0]->nama }} 
                                                <hr style='padding: 0; margin: 0' />
                                            </h2>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" style="padding: 1px; background-color: white;"><strong>{{ $toko[0]->deskripsi }}</strong></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 1px; width: 80px; background-color: white;">Faktur No</td>
                                        <td style="padding: 1px; background-color: white;">: {{ $penjualan->kode }}</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 1px; width: 80px; background-color: white;">Sales</td>
                                        <td style="padding: 1px; background-color: white;">: {{ $penjualan->salesman ? $penjualan->salesman->nama : '-' }}</td>
                                    </tr>


                                    @php
                                        if( $penjualan->due_date=='0000-00-00' ){
                                            $penjualan->due_date = date('Y-m-d', strtotime($penjualan->tanggal . " +{$penjualan->pelanggan->top} days")); 
                                            DB::table('penjualan')->where('id', $penjualan->id)->update(['due_date' => $penjualan->due_date]);
                                        }
                                    @endphp
                                    <tr>
                                        <td style="padding: 1px; width: 80px; background-color: white;">TOP</td>
                                        <td style="padding: 1px; background-color: white;">: {{ $penjualan->pelanggan->top }} hari</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 1px; width: 80px; background-color: white;">Jatuh Tempo</td>
                                        <td style="padding: 1px; background-color: white;">: {{ date("d M Y", strtotime($penjualan->due_date)) }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                        <td style="width: 20%; vertical-align:bottom"><p style="text-align: center; margin: 0; padding-bottom: 5px; font-size: 13px; font-weight: bolder;">PESANAN PENJUALAN</p></td>
                        <td style="width: 40%">
                            <div style="border-radius: 2px; border:solid;padding:5px">
                                <table style="width: 100%">
                                    <tbody>
                                        <tr>
                                            <td colspan="2">{{ $toko[0]->kota }}, {{ date('d F Y', strtotime($penjualan->tanggal)) }}</td>
                                        </tr>
                                        <tr>
                                            <td style="width: 35%; vertical-align:top">Kepada Yth</td>
                                            <td style="width: 65%; vertical-align:top">
                                                  Kepada Yth, {{ strtoupper($penjualan->pelanggan->nama_pelanggan) }} <br/>
                                                  <p style="padding-left: 20px; margin: 0;">
                                                    <strong>{{ $penjualan->pelanggan->alamat }}</strong><br/>

                                                    {{ $penjualan->pelanggan->kota }}<br/>
                                                    NPWP. {{ $penjualan->pelanggan->npwp }} / Kontak.  {{ $penjualan->pelanggan->telp_kontak }}
                                                  </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </td>
                  </tr>
                </tbody>
            </table>
        </div>        
        <table style="width: 100%; margin-bottom: 0px;">
          <thead>
            <tr>
              <th style="border: 0.3px solid #000; padding: 2px; text-align: center;" class="desc">NO</th>
              <th style="border: 0.3px solid #000; padding: 2px; text-align: center;" class="desc">KODE BARANG</th>
              <th style="border: 0.3px solid #000; padding: 2px;" class="desc">NAMA BARANG</th>
              <th style="border: 0.3px solid #000; padding: 2px; text-align: center;">QTY</th>
              <th style="border: 0.3px solid #000; padding: 2px; text-align: right;">HARGA</th>
              <th style="border: 0.3px solid #000; padding: 2px; text-align: center;">DISKON</th>
              <th style="border: 0.3px solid #000; padding: 2px; text-align: right;">TOTAL</th>
            </tr>
          </thead>
          <tbody>
            @foreach($penjualan->pesanan_penjualan_detail as $key => $detail)
              @php
                $diskon = '';
                if( $detail->diskon_tipe=='perc' ){
                    $diskon =  number_format($detail->diskon_persen).'%' ;
                }else{
                    $diskon = (($detail->diskon_persen/($detail->gross+$detail->diskon_persen))*100).'%';
                }
              @endphp
              <tr>
                <td style="border: 0.3px solid #000; padding: 2px; font-size: 11.5px; text-align: center;width: 20px;">{{ $loop->iteration }}</td>
                <td style="border: 0.3px solid #000; padding: 2px; font-size: 11.5px !important; width: 60px;" class="desc">{{ $detail->barang->kode }}</td>
                <td style="border: 0.3px solid #000; padding: 2px; font-size: 11.5px; width: 210px; " class="desc">{{ $detail->barang->nama }}</td>
                <td class="qty" style="border: 0.3px solid #000; padding: 2px; font-size: 11.5px; width: 30px; text-align: center">{{ $detail->qty }}</td>
                <td class="unit" style="border: 0.3px solid #000; padding: 2px; font-size: 11.5px; width: 50px;  text-align: right">Rp. {{ number_format($detail->harga) }}</td>
                <td class="unit" style="border: 0.3px solid #000; padding: 2px; font-size: 11.5px; text-align: center;  width: 30px;"> {{ $diskon }}</td>
                <td class="total"  style="border: 0.3px solid #000; padding: 2px; font-size: 11.5px; text-align: right; width: 60px;">Rp. {{ number_format($detail->gross) }}</td>
              </tr>
            @endforeach
            <tr>
              <td colspan="5" class="total" style="background-color: #fff; padding-top: 5px; text-align: left !important; vertical-align: top">
                <strong style="font-size: 12.5px"><i>TERBILANG: {{ ucwords($penjualan->label) }}</i></strong>

                <p style="font-size: 12.5px; line-height: 10px; margin-bottom: 0; padding-bottom: 0; width: 260px; padding: 4px; border: 1px solid #525252; border-radius: 2px; margin-top: 5px;">
                  <strong>Barang yang sudah dibeli atau <br/>diterima tidak dapat ditukar/dikembalikan</strong>
                </p>
              </td>
              <td  colspan="2">
                <table border="1">
                    <tr>
                      <td style="width: 80px;" class="total"><strong style="letter-spacing: -1px; font-size: 11.5px;">SUBTOTAL:</strong></td>
                      <td style="text-align: right !important;" class="total">Rp. {{ number_format($penjualan->total_gross, 0) }}</td>
                    </tr>
                    <tr>
                      <td style="width: 80px;" class="total"><strong style="letter-spacing: -1px; font-size: 11.5px;">TOTAL PPN:</strong></td>
                      <td style="text-align: right !important;" class="total">Rp. {{ number_format($penjualan->total_ppn, 0) }}</td>
                    </tr>
                    <tr>
                      <td style="width: 80px;" class="total"><strong style="letter-spacing: -1px; font-size: 11.5px;">DISKON:</strong></td>
                      <td style="text-align: right !important;" class="total">Rp. {{ number_format($penjualan->diskon_toko, 0) }}</td>
                    </tr>
                    <tr>
                      <td style="width: 80px;" class="grand total"><strong style="letter-spacing: -1px; font-size: 11.5px;">GRANDTOTAL:</strong></td>
                      <td style="text-align: right !important;" class="grand total">Rp. {{ number_format($penjualan->total_penjualan, 0) }}</td>
                    </tr>
                </table>
              </td>
            </tr>
          </tbody>
        </table>

        <div style="margin-top:0px">
            <table style="margin-top:0px">
                <tbody>
                    <tr>
                        <td style="width: 30%">
                            <center>Tanda Terima</center>
                        </td>
                        <td style="width: 40%; vertical-align: top">
                            <center>
                                <div style="padding:10px">
                                    <div style="border: 1px solid;width:100%">
                                        <div><strong>Pembayaran dianggap sah apabila Giro sudah Cair.</strong></div>
                                        @php $mstr = \App\Models\RekeningBank::where('status', 'Y')->first() @endphp
                                        <div><strong>Giro A/N : Bank BCA - {{  $mstr->nomor_rekening }} / {{ $mstr->nama_rekening}}</strong></div>
                                    </div>
                                </div>
                            </center>
                        </td>
                        <td style="width: 30%">
                            <center>Hormat kami</center>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>
