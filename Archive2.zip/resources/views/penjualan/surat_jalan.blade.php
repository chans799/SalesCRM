@extends('layouts.cetak3')

@section('title', 'Cetak Nota Penjualan')

@section('headers')
  <style type="text/css">
    #project span {
      width: 60px;
  }
  h1{
    background: url( asset('vendor/dimension.png') );
  }
  table td{
    padding: 10px;
    text-align: left;
  }
  table td.unit, table td.qty, table td.total {
    font-size: 13px;
  }

  @media print {
    #printPageButton {
      display: none;
    }
  }
  .total{
    text-align: right !important;
  }

  h2{
     font-size: 32px; font-weight: bold;
    padding: 0; margin: 0;
  }

  hr {
    background-color:white;
    margin: 0 10px 0 0 !important;
    width: 85%;
    max-width:600px;
    border-width:0;
  }

  hr.s1 {
    height:5px;
    border-top:1px solid black;
    border-bottom:2px solid black;
  }

  table.main th  {
    border: 1px solid #cecece;
  }

  table.main td {
    border: 1px solid #cecece;    
    padding: 3px !important;
    font-size: 12.4 !important;
  }

  table th{
    padding: 2px !important;
  }

  </style>
@endsection

{{-- 
 Ukuran kertas 
  - width: 864px;
  - height: 528px;
--}}

@section('content')
  <main>
    <table style="width: 100%; margin-top: 0px; margin-bottom: 0px;">
      <tr>
        <td colspan="2" style="padding: 2px; background-color: white;"><h2>{{ $toko->nama }} <hr class="s1"></h2></td>
        <td rowspan="6" style="padding: 2px; width: 45%; background-color: white; vertical-align: top;" >
          <div style="border: 2px solid #000; border-radius: 15px; padding: 10px;">
            {{ $toko->kota }}, &nbsp; {{ date("M d, Y", strtotime($param->tanggal)) }} <br/>
              Kepada Yth, {{ strtoupper($param->pelanggan->nama_pelanggan) }} <br/>
              <p style="padding-left: 20px; margin: 0;">
                <strong>{{ $param->pelanggan->alamat }}</strong><br/>

                {{ $param->pelanggan->kota }}<br/>
                NPWP. {{ $param->pelanggan->npwp }} / Kontak.  {{ $param->pelanggan->telp_kontak }}
              </p>
          </div>
        </td>
      </tr>
      <tr>
        <td colspan="2" style="padding: 2px; background-color: white;"><strong>{{ $toko->deskripsi }}</strong></td>
      </tr>
      <tr>
        <td colspan="2" style="padding: 2px; background-color: white;"></td>
      </tr>
      <tr>
        <td style="padding: 2px; width: 80px; background-color: white;">SJ No</td>
        <td style="padding: 2px; background-color: white;">: {{ $param->kode }}</td>
      </tr>
      <tr>
        <td style="padding: 2px; width: 80px; background-color: white;">Sales</td>
        <td style="padding: 2px; background-color: white;">: {{ $param->salesman ? $param->salesman->nama : '-' }}</td>
      </tr>

      @php
        if( $param->due_date=='0000-00-00' ){
            $param->due_date = date('Y-m-d', strtotime($param->tanggal . " +{$param->pelanggan->top} days")); 
            DB::table('penjualan')->where('id', $param->id)->update(['due_date' => $param->due_date]);
        }
      @endphp
      <tr>
        <td style="padding: 2px; width: 80px; background-color: white;">TOP</td>
        <td style="padding: 2px; background-color: white;">: {{ $param->pelanggan->top }} hari</td>
      </tr>
      <tr>
        <td style="padding: 2px; width: 80px; background-color: white;">Jatuh Tempo</td>
        <td style="padding: 2px; background-color: white;">: {{ date("d M Y", strtotime($param->due_date)) }}</td>
      </tr>

    </table>
    <p style="text-align: center; margin: 0; padding-bottom: 5px; font-weight: bolder; font-size: 18px;">SURAT JALAN</p>
    <table class="main" style="width: 100%; margin-bottom: 0px;">
      <thead>
        <tr>
          <th class="desc">NO</th>
          <th class="desc">KODE BARANG</th>
          <th class="desc">NAMA BARANG</th>
          <th>QTY</th>
          <th>HARGA</th>
          <th>DISKON</th>
          <th>TOTAL HARGA</th>
        </tr>
      </thead>
      <tbody>
        @php( $qty_total = 0 )
        @foreach($param->penjualan_detail as $key => $detail)
          <tr>
            <td style="font-size: 12px; text-align: center; width: 40px;">{{ $loop->iteration }}</td>
            <td style="font-size: 14px !important; width: 100px" class="desc">{{ $detail->barang->kode }}</td>
            <td style="font-size: 12px;" class="desc">{{ $detail->barang->nama }}</td>
            <td class="qty" style="font-size: 12px; width: 70px; text-align: center">{{ number_format($detail->qty) }}</td>
            <td class="unit" style="font-size: 12px; width: 120px; text-align: right">Rp. {{ number_format($detail->harga) }}</td>
            <td class="unit" style="font-size: 12px; text-align: {{ $detail->diskon_tipe=='perc' ? 'center' : 'right' }};  width: 80px;">
              {{ $detail->diskon_tipe=='perc' ? number_format($detail->diskon_persen).'%' : 'Rp. '.number_format($detail->diskon_persen) }}
            </td>
            <td class="total"  style="font-size: 12px; text-align: right; width: 130px;">Rp. {{ number_format($detail->gross) }}</td>
          </tr>
          @php( $qty_total += $detail->qty )
        @endforeach
        <tr>
          <td style="background-color: #fff; text-align: right; font-weight: bolder; border: 0" colspan="3">Total Qty : &nbsp;</td>
          <td style="background-color: #fff; text-align: center; font-weight: bolder;">{{ number_format($qty_total) }}</td>
        </tr>
      </tbody>
    </table>
    <div style="font-size: 12.5px; width: 260px; padding: 4px; border: 1px solid #525252; border-radius: 2px; margin-top: 5px;">
      <strong>Barang yang sudah dibeli atau <br/>diterima tidak dapat ditukar/dikembalikan</strong>
    </div>
    <div>      
      <table style="width: 100%;">
          <tbody>
              <tr>
                  <td style="width: 33%; background-color: #fff;">
                      <div style="margin-bottom: 50px">Tanda Terima</div>
                      <hr/>
                  </td>
                  <td style="width: 33%; background-color: #fff;">
                      <div style="margin-bottom: 50px">
                          <center>Gudang</center>
                      </div>
                      <hr/>
                  </td>
                  <td style="width: 33%; background-color: #fff;">
                      <div style="margin-bottom: 50px; text-align: right;">Hormat Kami</div>
                      <hr/>
                  </td>
              </tr>
              <tr><td style="padding: 10px"><hr></td><td style="padding: 10px"><hr></td><td style="padding: 10px"><hr></td></tr>
          </tbody>
      </table>
    </div>
    <div id="printPageButton" style="text-align: center;">
      <button onClick="window.print();" style="margin-top: 100px;">Print</button>
    </div>
  </main>
            
@endsection
