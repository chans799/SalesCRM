@extends('layouts.cetak3')

@section('title', 'Cetak Nota Penjualan')

@section('headers')
  <style type="text/css">
    #project span {
      width: 60px;
  }
  h1{
    background: url( asset('vendor/dimension.png') );
  }
  table td{
    padding: 10px;
    text-align: left;
  }
  table td.unit, table td.qty, table td.total {
    font-size: 15px;
  }

  @media print {
    #printPageButton {
      display: none;
    }
  }
  .total{
    text-align: right !important;
  }

  h2{
     font-size: 32px; font-weight: bold;
    padding: 0; margin: 0;
  }

  hr {
    background-color:white;
    margin: 0 10px 0 0 !important;
    width: 85%;
    max-width:600px;
    border-width:0;
  }

  hr.s1 {
    height:5px;
    border-top:1px solid black;
    border-bottom:2px solid black;
  }

  table.main th  {
    border: 1px solid #cecece;
  }

  table.main td {
    border: 1px solid #cecece;    
    padding: 3px !important;
    font-size: 12.4 !important;
  }

  table th{
    padding: 2px !important;
  }

  </style>
@endsection

{{-- 
 Ukuran kertas 
  - width: 875px;
  - height: 535px;
--}}

@section('content')
  <main>
    <table style="width: 100%; margin-top: 0px; margin-bottom: 0px;">
      <tr>
        <td colspan="2" style="padding: 2px; background-color: white;"><h2>{{ $toko->nama }} <hr class="s1"></h2></td>
        <td rowspan="4" style="padding: 2px; width: 30%; background-color: white; vertical-align: top;" >
          <div style="border: 2px solid #000; border-radius: 12px; padding: 8px;">
            {{ $toko->kota }}, &nbsp; {{ date("M d, Y", strtotime($param->tanggal)) }} <br/>
              Kepada Yth, {{ strtoupper($param->pelanggan->nama_pelanggan) }} <br/>
              <p style="padding-left: 0px; margin: 3;">
              <p style="padding-left: 0px; margin: 3;">          
                {{ $param->pelanggan->alamat }}<br/>
             <p style="padding-left: 10px; margin: 3;">    
                {{ $param->pelanggan->kota }}<br/>
                NPWP. {{ $param->pelanggan->npwp }} / Kontak.  {{ $param->pelanggan->telp_kontak }}
              </p>
          </div>
        </td>
      </tr>
      <tr>
        <td colspan="1" style="padding: 2px; background-color: white;"><strong>{{ $toko->deskripsi }}</strong></td>
      </tr>
      <tr>
        <td colspan="2" style="padding: 2px; background-color: white;"></td>
      </tr>
      <tr>
        <td style="padding: 2px; width: 80px; background-color: white;">Faktur No</td>
        <td style="padding: 2px; background-color: white;">: {{ $param->kode }}</td>
      </tr>
      <tr>
        <td style="padding: 2px; width: 80px; background-color: white;">Sales</td>
        <td style="padding: 2px; background-color: white;">: {{ $param->salesman ? $param->salesman->nama : '-' }}</td>
      </tr>


      @php
        if( $param->due_date=='0000-00-00' ){
            $param->due_date = date('Y-m-d', strtotime($param->tanggal . " +{$param->pelanggan->top} days")); 
            DB::table('penjualan')->where('id', $param->id)->update(['due_date' => $param->due_date]);
        }
      @endphp
      <tr>
        <td style="padding: 2px; width: 80px; background-color: white;">TOP</td>
        <td style="padding: 2px; background-color: white;">: {{ $param->pelanggan->top }} hari</td>
      </tr>
      <tr>
        <td style="padding: 2px; width: 80px; background-color: white;">Jatuh Tempo</td>
        <td style="padding: 2px; background-color: white;">: {{ date("d M Y", strtotime($param->due_date)) }}</td>
      </tr>
    </table>
    <p style="text-align: center; margin: 0; padding-bottom: 5px; font-size: 18px; font-weight: bolder;">F A K T U R</p>
    <table class="main" style="width: 100%;">
      <thead>
        <tr>
          <th class="desc">NO</th>
          <th class="desc">KODE BARANG</th>
          <th class="desc">NAMA BARANG</th>
          <th>QTY</th>
          <th>HARGA</th>
          <th>DISKON</th>
          <th>SUB TOTAL</th>
        </tr>
      </thead>
      <tbody>
        @foreach($param->penjualan_detail as $key => $detail)
          <tr>
            <td style="font-size: 12px; text-align: center;width: 35px;">{{ $loop->iteration }}</td>
            <td style="font-size: 14px !important; width: 100px;" class="desc">{{ $detail->barang->kode }}</td>
            <td style="font-size: 12px;" class="desc">{{ $detail->barang->nama }}</td>
            <td class="qty" style="font-size: 12px; width: 60px; text-align: center">{{ $detail->qty }}</td>
            <td class="unit" style="font-size: 12px; width: 110px;  text-align: right">Rp. {{ number_format($detail->harga) }}</td>
            <td class="unit" style="font-size: 12px; text-align: {{ $detail->diskon_tipe=='perc' ? 'center' : 'right' }};  width: 80px;">
              {{ $detail->diskon_tipe=='perc' ? number_format($detail->diskon_persen).'%' : 'Rp. '.number_format($detail->diskon_persen) }}
            </td>
            <td class="total"  style="font-size: 12px; text-align: right; width: 120px;">Rp. {{ number_format($detail->gross) }}</td>
          </tr>
        @endforeach
        <tr>
          <td colspan="5" rowspan="4" class="total" style="border: 0; background-color: #fff; text-align: left !important; padding-top: 10px; vertical-align: top">
            <strong style="font-size: 12.5px"><i>TERBILANG: {{ ucwords($param->label) }}</i></strong>

            <div style="font-size: 12.5px; width: 260px; padding: 4px; border: 1px solid #525252; border-radius: 2px; margin-top: 20px;">
              <strong>Barang yang sudah dibeli atau <br/>diterima tidak dapat ditukar/dikembalikan</strong>
            </div>
          </td>
          <td style="width: 80px;" class="total"><strong style="letter-spacing: -1px; font-size: 12px;">SUBTOTAL:</strong></td>
          <td class="total">Rp. {{ number_format($param->total_gross, 0) }}</td>
        </tr>
        <tr>
          <td style="width: 80px;" class="total"><strong style="letter-spacing: -1px; font-size: 12px;">TOTAL PPN:</strong></td>
          <td class="total">Rp. {{ number_format($param->total_ppn, 0) }}</td>
        </tr>
        <tr>
          <td style="width: 80px;" class="total"><strong style="letter-spacing: -1px; font-size: 12px;">DISKON:</strong></td>
          <td class="total">Rp. {{ number_format($param->diskon_toko, 0) }}</td>
        </tr>
        <tr>
          <td style="width: 80px;" class="grand total"><strong style="letter-spacing: -1px; font-size: 12px;">GRANDTOTAL:</strong></td>
          <td class="grand total">Rp. {{ number_format($param->total_penjualan, 0) }}</td>
        </tr>
      </tbody>
    </table>
    <div>      
      <table style="width: 100%;">
          <tbody>
              <tr>
                  <td style="width: 33%; background-color: #fff; tex">
                      <div style="margin-bottom: 50px">Tanda Terima</div>
                  </td>
                  <td style="width: 33%; background-color: #fff; font-size: 12.5px;">
                      @php  
                        $bank = DB::table('rekening_bank')
                                    ->select('rekening_bank.*', DB::raw('bank.nama AS nama_bank'))
                                    ->leftJoin('bank', 'bank.id', '=', 'rekening_bank.bank_id')
                                    ->where('rekening_bank.status','Y')->orderBy('rekening_bank.id','ASC')
                                    ->limit(1)->first();
                      @endphp
                      <div style="padding: 10px; border: 1px solid #000; font-weight: bolder; font-size: 12.5px">
                          Pembayaran dianggap sah apabila Giro sudah cari atau transfer ke rekening: <br/>
                          A/N : {{ $bank ? $bank->nama_rekening : '-' }} <br/>
                          BANK : {{ $bank ? $bank->nama_bank : '-' }} <br/>
                          NO. REKENING : {{ $bank ? $bank->nomor_rekening : '-' }} <br/>
                      </div>
                  </td>
                  <td style="width: 33%; background-color: #fff;">
                      <div style="margin-bottom: 50px; text-align: right;">Hormat kami</div>
                  </td>
              </tr>
              <tr><td style="padding: 10px"><hr></td><td style="padding: 10px"><hr></td><td style="padding: 10px"><hr></td></tr>
          </tbody>
      </table>
    </div>
    <div id="printPageButton" style="text-align: center;">
      <button onClick="window.print();" style="margin-top: 100px;">Print</button>
    </div>
  </main>
            
@endsection
