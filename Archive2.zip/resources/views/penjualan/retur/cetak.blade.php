@extends('layouts.cetak2')

@section('title', 'Cetak Nota Retur Penjualan')

@section('headers')
  <style type="text/css">
    #project span {
      width: 60px;
  }
  h1{
    background: url( asset('vendor/dimension.png') );
  }
  table td{
    padding: 10px;
    text-align: left;
  }
  table td.unit, table td.qty, table td.total {
    font-size: 13px;
  }

  @media print {
    #printPageButton {
      display: none;
    }
  }
  .total{
    text-align: right !important;
  }

  #company{
    float: left !important;
    text-align: left !important;
  }

  #project{
    float: right !important;
    text-align: right !important;
  }
  </style>
@endsection

@section('content')  
  <header class="clearfix">
    <h1>INVOICE: {{ $param->kode }}</h1>
    <div id="company" class="clearfix">
      <div style="font-size: 14px; font-weight: bolder;">{{ $toko->nama }}</div>
      <div>{{ $toko->alamat }},<br /> {{ $toko->kota }}</div>
      <div>{{ $toko->telp1 }} / {{ $toko->telp2 }}</div>
      <div><a >{{ $toko->email }}</a></div>
      <div><span>DATE :</span> {{ date("M d, Y", strtotime($param->tanggal)) }}</div>
    </div>
    <div id="project">
      <div>{{ $param->penjualan->pelanggan->nama_pelanggan }}</div>
      <div>NPWP. {{ $param->penjualan->pelanggan->npwp }}</div>
      <div>{{ $param->penjualan->pelanggan->alamat }}, {{ $param->penjualan->pelanggan->kota }}<br/>{{ $param->penjualan->pelanggan->kode_pos }}</div>
      <div><a>{{ $param->penjualan->pelanggan->nama_kontak }}</a> / {{ $param->penjualan->pelanggan->telp_kontak }}</div>
    </div>
  </header>
  <main>
    <table>
      <thead>
        <tr>
          <th class="desc">KODE BARANG</th>
          <th class="desc">NAMA BARANG</th>
          <th>QTY</th>
          <th>HARGA</th>
          <th>PPN</th>
          <th>DISKON</th>
          <th>TOTAL</th>
        </tr>
      </thead>
      <tbody>
        @foreach($param->retur_penjualan_detail as $key => $detail)
          <tr>
            <td class="desc" style="text-align: center;">{{ $detail->barang->kode }}</td>
            <td class="desc">{{ $detail->barang->nama }}</td>
            <td class="qty" align="center" style="text-align: center;">{{ number_format($detail->qty_retur) }}</td>
            <td class="unit" align="right">Rp. {{ number_format($detail->harga) }}</td>
            <td class="unit" align="right">Rp. {{ number_format($detail->ppn) }}</td>
            <td class="unit" align="right">Rp. {{ number_format($detail->diskon) }}</td>
            <td class="total"  align="right">Rp. {{ number_format($detail->netto) }}</td>
          </tr>
        @endforeach
        <tr>
          <td colspan="5" class="grand total"><strong>GRAND TOTAL :</strong></td>
          <td colspan="2" class="grand total">Rp. {{ number_format($param->total_netto, 2) }}</td>
        </tr>
      </tbody>
    </table>
    <div id="notices">
      <div>Catatan:</div>
      <div class="notice">{{ $param->keterangan }}</div>
    </div>

    <div id="printPageButton" style="margin-top: 50px; text-align: center;">
      <button onClick="window.print();" style="margin-top: 100px;">Print</button>
    </div>
  </main>
            
@endsection
