@extends('layouts.dashboard')

@section('title', 'History')

@section('content')
    <div id="content" class="content">
         {{   Breadcrumbs::render('dashboard')  }}  
        <h2 style="margin-bottom: 1em;">History Setiap Transaksi</h2>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body table-responsive">
                        <h5 class="text-center"></h5>
                        <table class="table table-striped table-hover datatable">
                            <thead>
                                <tr>
                                    <th width="5%">#</th>
                                    <th>Transaksi</th>
                                    {{-- <th>User</th> --}}
                                    <th>Barang</th>
                                    <th>Kredit</th>
                                    <th>Debet</th>
                                    <th>Stok</th>
                                    <th>Harga</th>
                                    <th>Total Harga</th>
                                    <th>Tanggal Transaksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data as $data)
                                    <tr>
                                        <td> {{ $loop->iteration }}  </td>
                                        <td> {{  $data->history_name }}  </td>
                                        {{-- <td> {{  $data->name }}  </td> --}}
                                        <td> {{  $data->barang }}  </td>
                                        <td> {{  $data->stok_plus }}  </td>
                                        <td> {{  $data->stok_minus }}  </td>
                                        <td> {{  $data->stok }}  </td>
                                        <td> {{  number_format($data->harga)  }}</td>
                                        <td> {{  number_format($data->total_harga)  }}</td>
                                        <td> {{  (!$data->created_at) ? '' : date('d M Y', strtotime($data->created_at)) }}  </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection