<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Perakitan Paket',
        'tambah' => 'Tambah Perakitan Paket',
        'edit' => 'Edit Perakitan Paket',
        'show' => 'Detail Perakitan Paket'
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
