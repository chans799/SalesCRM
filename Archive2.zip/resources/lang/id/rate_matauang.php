<?php
// Language English

return [
    'title' => [
        'index' => 'Rate Mata Uang',
        'tambah' => 'Tambah Rate Mata Uang',
        'edit' => 'Edit Rate Mata Uang',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
