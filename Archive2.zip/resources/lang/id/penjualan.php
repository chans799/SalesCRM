<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Penjualan',
        'tambah' => 'Tambah Penjualan',
        'edit' => 'Edit Penjualan',
        'show' => 'Detail Penjualan',
        'payment' => 'Pembayaran',
        'payment_list' => 'Daftar Pembayaran',
        'item_list' => 'Daftar Barang'
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
