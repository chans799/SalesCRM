<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Pesanan Penjualan',
        'tambah' => 'Tambah Pesanan Penjualan',
        'edit' => 'Edit Pesanan Penjualan',
        'show' => 'Detail Pesanan Penjualan',
        'payment' => 'Pembayaran',
        'payment_list' => 'Daftar Pembayaran',
        'item_list' => 'Daftar Barang'
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
