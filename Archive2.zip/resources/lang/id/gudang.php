<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Gudang',
        'tambah' => 'Tambah Gudang',
        'edit' => 'Edit Gudang',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
