<?php
// Language English

return [
    'title' => [
        'index' => 'Area',
        'tambah' => 'Tambah Area',
        'edit' => 'Edit Area',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
