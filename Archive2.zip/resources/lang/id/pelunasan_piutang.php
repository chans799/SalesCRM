<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Pelunasan Piutang',
        'tambah' => 'Tambah Pelunasan Piutang',
        'edit' => 'Edit Pelunasan Piutang',
        'show' => 'Detail Pelunasan Piutang',
        'payment' => 'Pembayaran',
        'payment_list' => 'Pembayaran',
        'item_list' => 'Daftar Penjualan'
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
