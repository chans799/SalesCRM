<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Kategori Barang',
        'tambah' => 'Tambah Kategori Barang',
        'edit' => 'Edit Kategori Barang',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
