<?php
// Language English

return [
    'title' => [
        'index' => 'Supplier',
        'tambah' => 'Tambah Supplier',
        'edit' => 'Edit Supplier',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
