<?php
// Language English

return [
    'title' =>[
        'index' =>'Satuan Barang',
        'tambah' =>'Tambah Satuan Barang',
        'edit' =>'Edit Satuan Barang',
    ],
    'button' =>[
        'tambah' =>'Tambah',
    ]

];


