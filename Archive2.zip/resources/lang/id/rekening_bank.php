<?php
// Language English

return [
    'title' => [
        'index' => 'Rekening Bank',
        'tambah' => 'Tambah Rekening Bank',
        'edit' => 'Edit Rekening Bank',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
