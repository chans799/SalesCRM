<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Adjusment Plus',
        'tambah' => 'Tambah Adjusment Plus',
        'edit' => 'Edit Adjusment Plus',
        'show' => 'Detail Adjusment Plus'
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
