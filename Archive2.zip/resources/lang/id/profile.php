<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Profile',
        'tambah' => 'Tambah Profile',
        'edit' => 'Edit Profile',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
