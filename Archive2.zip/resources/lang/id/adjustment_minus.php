<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Adjusment Minus',
        'tambah' => 'Tambah Adjusment Minus',
        'edit' => 'Edit Adjusment Minus',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
