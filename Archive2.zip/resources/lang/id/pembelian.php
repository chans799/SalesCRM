<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Pembelian',
        'tambah' => 'Tambah Pembelian',
        'edit' => 'Edit Pembelian',
        'show' => 'Detail Pembelian',
        'payment' => 'Pembayaran',
        'payment_list' => 'Daftar Pembayaran',
        'item_list' => 'Daftar Barang'
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
