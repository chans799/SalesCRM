<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Pesanan Pembelian',
        'tambah' => 'Tambah Pesanan Pembelian',
        'edit' => 'Edit Pesanan Pembelian',
        'show' => 'Detail Pesanan Pembelian'
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
