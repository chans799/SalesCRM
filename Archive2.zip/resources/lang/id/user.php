<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Pengguna',
        'tambah' => 'Tambah Pengguna',
        'edit' => 'Edit Pengguna',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
