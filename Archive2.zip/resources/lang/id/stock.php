<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Laporan Kartu Stok',
        'tambah' => 'Tambah Laporan Kartu Stok',
        'edit' => 'Edit Laporan Kartu Stok',
        'show' => 'Detail Laporan Kartu Stok'
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
