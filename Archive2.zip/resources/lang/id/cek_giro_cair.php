<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Cek/Giro Cair',
        'tambah' => 'Tambah Cek/Giro Cair',
        'edit' => 'Edit Cek/Giro Cair',
        'show' => 'Detail Cek/Giro Cair',
        'header_entry' => 'Data Header',
        'detail_info' => 'Detail Informasi'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
