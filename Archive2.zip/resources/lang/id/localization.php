<?php
// Language Indonesia

return [
    'id' =>'Indonesia',
    'en' =>'Inggris'
];


