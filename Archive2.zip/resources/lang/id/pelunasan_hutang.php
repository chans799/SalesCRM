<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Pelunasan Hutang',
        'tambah' => 'Tambah Pelunasan Hutang',
        'edit' => 'Edit Pelunasan Hutang',
        'show' => 'Detail Pelunasan Hutang',
        'payment' => 'Pembayaran',
        'payment_list' => 'Pembayaran',
        'item_list' => 'Daftar Pembelian'
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
