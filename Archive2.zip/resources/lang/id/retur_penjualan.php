<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Retur Penjualan',
        'tambah' => 'Tambah Retur Penjualan',
        'edit' => 'Edit Retur Penjualan',
        'show' => 'Detail Retur Penjualan',
        'payment' => 'Pembayaran',
        'payment_list' => 'Daftar Pembayaran',
        'item_list' => 'Daftar Barang'
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
