<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Cek/Giro Tolak',
        'tambah' => 'Tambah Cek/Giro Tolak',
        'edit' => 'Edit Cek/Giro Tolak',
        'show' => 'Detail Cek/Giro Tolak',
        'header_entry' => 'Data Header',
        'detail_info' => 'Detail Informasi'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
