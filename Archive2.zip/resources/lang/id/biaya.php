<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Biaya',
        'tambah' => 'Tambah Biaya',
        'edit' => 'Edit Biaya',
        'show' => 'Detail Biaya',
        'header_entry' => 'Data Header',
        'detail_info' => 'Detail Informasi'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
