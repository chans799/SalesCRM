<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Bank',
        'tambah' => 'Tambah Bank',
        'edit' => 'Edit Bank',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
