<?php
// Language English

return [
    'title' => [
        'index' => 'Pramuniaga',
        'tambah' => 'Tambah Pramuniaga',
        'edit' => 'Edit Pramuniaga',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
