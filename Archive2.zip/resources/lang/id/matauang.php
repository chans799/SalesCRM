<?php
// Language English

return [
    'title' =>[
        'index' =>'Mata Uang',
        'tambah' =>'Tambah Mata Uang',
        'edit' =>'Edit Mata Uang',
    ],
    'button' =>[
        'tambah' =>'Tambah',
    ]

];


