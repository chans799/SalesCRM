<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'POS Terminal',
        'tambah' => 'Tambah POS Terminal',
        'edit' => 'Edit POS Terminal',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
