<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Barang',
        'tambah' => 'Tambah Barang',
        'edit' => 'Edit Barang',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
