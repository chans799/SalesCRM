<?php
// Language Indonesia

return [
    'title' => [
        'index' => 'Retur Pembelian',
        'tambah' => 'Tambah Retur Pembelian',
        'edit' => 'Edit Retur Pembelian',
        'show' => 'Detail Retur Pembelian'
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
