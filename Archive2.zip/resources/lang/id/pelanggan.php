<?php
// Language English

return [
    'title' => [
        'index' => 'Pelanggan',
        'tambah' => 'Tambah Pelanggan',
        'edit' => 'Edit Pelanggan',
    ],
    'button' => [
        'tambah' => 'Tambah',
    ]

];
