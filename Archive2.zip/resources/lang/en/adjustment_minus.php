<?php
// Language English

return [
    'title' => [
        'index' => 'Adjusment Minus',
        'tambah' => 'Add Adjusment Minus',
        'edit' => 'Edit Adjusment Minus',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
