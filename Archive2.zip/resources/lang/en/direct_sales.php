<?php
// Language English

return [
    'title' => [
        'index' => 'Direct Sales',
        'tambah' => 'Add Direct Sales',
        'edit' => 'Edit Direct Sales',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
