<?php
// Language English

return [
    'title' => [
        'index' => 'Cheque Withdraw',
        'tambah' => 'Add Cheque Withdraw',
        'edit' => 'Edit Cheque Withdraw',
        'show' => 'Detail Cheque Withdraw',
        'header_entry' => 'Header Entry',
        'detail_info' => 'Detail Information'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
