<?php
// Language English

return [
    'title' => [
        'index' => 'Bank',
        'tambah' => 'Add Bank',
        'edit' => 'Edit Bank',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
