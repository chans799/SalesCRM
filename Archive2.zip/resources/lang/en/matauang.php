<?php
// Language English

return [
    'title' =>[
        'index' =>'Currency',
        'tambah' =>'Add Currency',
        'edit' =>'Edit Currency',
    ],
    'button' =>[
        'tambah' =>'Create',
    ]

];


