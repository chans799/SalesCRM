<?php
// Language English

return [
    'title' => [
        'index' => 'Profile',
        'tambah' => 'Add Profile',
        'edit' => 'Edit Profile',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
