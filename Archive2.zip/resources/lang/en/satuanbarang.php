<?php
// Language English

return [
    'title' =>[
        'index' =>'Item Unit',
        'tambah' =>'Add Item Unit',
        'edit' =>'Edit Item Unit',
    ],
    'button' =>[
        'tambah' =>'Create',
    ]

];


