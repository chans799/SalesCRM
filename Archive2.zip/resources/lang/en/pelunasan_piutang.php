<?php
// Language English

return [
    'title' => [
        'index' => 'A/R Payment',
        'tambah' => 'Add A/R Payment',
        'edit' => 'Edit A/R Payment',
        'show' => 'Detail A/R Payment',
        'payment' => 'Payment',
        'payment_list' => 'Payment List',
        'item_list' => 'Item List'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
