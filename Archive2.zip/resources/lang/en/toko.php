<?php
// Language English

return [
    'title' => [
        'index' => 'Toko',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
