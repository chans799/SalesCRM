<?php
// Language English

return [
    'title' => [
        'index' => 'Expense',
        'tambah' => 'Add Expense',
        'edit' => 'Edit Expense',
        'show' => 'Detail Expense',
        'header_entry' => 'Header Entry',
        'detail_info' => 'Detail Information'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
