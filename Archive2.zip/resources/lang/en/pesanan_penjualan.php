<?php
// Language English

return [
    'title' => [
        'index' => 'Sales Order',
        'tambah' => 'Add Sales Order',
        'edit' => 'Edit Sales Order',
        'show' => 'Detail Sales Order',
        'payment' => 'Payment',
        'payment_list' => 'Payment List',
        'item_list' => 'Item List'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
