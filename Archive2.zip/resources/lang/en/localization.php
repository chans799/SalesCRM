<?php
// Language English

return [
    'id' =>'Indonesian',
    'en' =>'English'
];


