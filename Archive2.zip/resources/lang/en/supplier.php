<?php
// Language English

return [
    'title' => [
        'index' => 'Supplier',
        'tambah' => 'Add Supplier',
        'edit' => 'Edit Supplier',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
