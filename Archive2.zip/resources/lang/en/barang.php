<?php
// Language English

return [
    'title' => [
        'index' => 'Item',
        'tambah' => 'Add Item',
        'edit' => 'Edit Item',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
