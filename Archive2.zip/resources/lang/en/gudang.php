<?php
// Language English

return [
    'title' => [
        'index' => 'Warehouse',
        'tambah' => 'Add Warehouse',
        'edit' => 'Edit Warehouse',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
