<?php
// Language English

return [
    'title' => [
        'index' => 'Item Category',
        'tambah' => 'Add Item Category',
        'edit' => 'Edit Item Category',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
