<?php
// Language English

return [
    'title' => [
        'index' => 'Customer',
        'tambah' => 'Add Customer',
        'edit' => 'Edit Customer',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
