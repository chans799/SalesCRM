<?php
// Language English

return [
    'title' => [
        'index' => 'Area',
        'tambah' => 'Add Area',
        'edit' => 'Edit Area',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
