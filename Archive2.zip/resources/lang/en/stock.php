<?php
// Language English

return [
    'title' => [
        'index' => 'Stock Table',
        'tambah' => 'Add Stock Table',
        'edit' => 'Edit Stock Table',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
