<?php
// Language English

return [
    'title' => [
        'index' => 'Purchase Return',
        'tambah' => 'Add Purchase Return',
        'edit' => 'Edit Purchase Return',
        'show' => 'Detail Purchase Return',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
