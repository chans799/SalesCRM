<?php
// Language English

return [
    'title' => [
        'index' => 'Sales',
        'tambah' => 'Add Sales',
        'edit' => 'Edit Sales',
        'show' => 'Detail Sales',
        'payment' => 'Payment',
        'payment_list' => 'Payment List',
        'item_list' => 'Item List'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
