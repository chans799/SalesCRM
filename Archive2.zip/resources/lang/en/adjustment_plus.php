<?php
// Language English

return [
    'title' => [
        'index' => 'Adjusment Plus',
        'tambah' => 'Add Adjusment Plus',
        'edit' => 'Edit Adjusment Plus',
        'show' => 'Detail Adjusment Plus'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
