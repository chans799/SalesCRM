<?php
// Language English

return [
    'title' => [
        'index' => 'Package Assembly',
        'tambah' => 'Add Package Assembly',
        'edit' => 'Edit Package Assembly',
        'show' => 'Detail Package Assembly'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
