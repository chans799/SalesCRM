<?php
// Language English

return [
    'title' => [
        'index' => 'Purchase',
        'tambah' => 'Add Purchase',
        'edit' => 'Edit Purchase',
        'show' => 'Detail Purchase',
        'payment' => 'Payment',
        'payment_list' => 'Payment List',
        'item_list' => 'Item List'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
