<?php
// Language English

return [
    'title' => [
        'index' => 'Cheque Rejected',
        'tambah' => 'Add Cheque Rejected',
        'edit' => 'Edit Cheque Rejected',
        'show' => 'Detail Cheque Rejected',
        'header_entry' => 'Header Entry',
        'detail_info' => 'Detail Information'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
