<?php
// Language English

return [
    'title' => [
        'index' => 'A/P Payment',
        'tambah' => 'Add A/P Payment',
        'edit' => 'Edit A/P Payment',
        'show' => 'Detail A/P Payment',
        'payment' => 'Payment',
        'payment_list' => 'Payment',
        'item_list' => 'Purchase List'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
