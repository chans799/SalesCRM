<?php
// Language English

return [
    'title' => [
        'index' => 'Purchase Order',
        'tambah' => 'Add Purchase Order',
        'edit' => 'Edit Purchase Order',
        'show' => 'Detail Purchase Order'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
