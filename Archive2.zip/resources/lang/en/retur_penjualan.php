<?php
// Language English

return [
    'title' => [
        'index' => 'Return Sales',
        'tambah' => 'Add Return Sales',
        'edit' => 'Edit Return Sales',
        'show' => 'Detail Return Sales',
        'payment' => 'Payment',
        'payment_list' => 'Payment List',
        'item_list' => 'Item List'
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
