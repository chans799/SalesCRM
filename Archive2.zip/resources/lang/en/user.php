<?php
// Language English

return [
    'title' => [
        'index' => 'User',
        'tambah' => 'Add User',
        'edit' => 'Edit User',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
