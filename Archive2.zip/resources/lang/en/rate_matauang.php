<?php
// Language English

return [
    'title' => [
        'index' => 'Currency Rate',
        'tambah' => 'Add Currency Rate',
        'edit' => 'Edit Currency Rate',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
