<?php
// Language English

return [
    'title' => [
        'index' => 'Bank Account',
        'tambah' => 'Add Bank Account',
        'edit' => 'Edit Bank Account',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
