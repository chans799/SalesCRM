<?php
// Language English

return [
    'title' => [
        'index' => 'Salesman',
        'tambah' => 'Add Salesman',
        'edit' => 'Edit Salesman',
    ],
    'button' => [
        'tambah' => 'Create',
    ]

];
